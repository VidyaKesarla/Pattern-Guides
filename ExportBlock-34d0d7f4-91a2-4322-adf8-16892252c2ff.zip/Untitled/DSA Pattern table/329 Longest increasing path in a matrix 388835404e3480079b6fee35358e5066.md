# 329. Longest increasing path in a matrix

Difficulty: Difficult
Input Data Structure: 2D Array
Pattern trigger(recognition) / constraints hint / : Grid / graph problem?                        → consider DFS
+ path length / count?                     → DFS over neighbors
+ can different paths reach same node?     → add memoization
+ answer for node depends only on
its neighbors' answers?                  → cache[i][j] is valid
+ no cycles possible (monotone condition)? → safe to memoize directly
Signal / Paraphrase hint: Great meta-question. Here are the patterns that should trigger "this is DFS + memo":
1. "Longest / shortest path" on a grid or graph
Whenever you see longest path, shortest path, or count of paths on a grid, that's a DFS signal. The grid itself is the implicit graph — cells are nodes, valid moves are edges.
2. A local decision that depends on neighbors
The problem says: from this cell, I can move to a neighbor if some condition holds (here: strictly greater value). This "conditional neighbor exploration" is the DFS trigger. You're not BFS-ing level by level — you're diving deep along valid paths.
3. Overlapping subproblems
Ask yourself: "Can two different starting points reach the same cell?"
If yes → the same subproblem gets solved multiple times → memoization pays off.
In this problem, cell (1,0) is reachable from (2,0), (2,1), (2,2) — classic overlap. This is the memo trigger.
4. Optimal substructure
The longest path from a cell = 1 + longest path from its best neighbor. The answer for a cell is fully determined by its neighbors' answers — no global state needed. This is what makes storing cache[i][j] valid.
5. No cycles in the traversal
Here, strictly increasing values guarantee you never revisit a cell in the same path — so DFS won't loop infinitely. If there were cycles, you'd need visited tracking instead, and memoization gets trickier.
The mental checklist:

Grid / graph problem?                        → consider DFS
  + path length / count?                     → DFS over neighbors
  + can different paths reach same node?     → add memoization
  + answer for node depends only on
    its neighbors' answers?                  → cache[i][j] is valid
  + no cycles possible (monotone condition)? → safe to memoize directly

Other problems with the exact same fingerprint:
• Number of islands — DFS on grid, no memo needed (no overlap)
• Unique paths in a grid — DFS + memo (or DP)
• Word search II — DFS on grid with trie
• Cherry pickup — DFS + memo, two simultaneous paths
• Longest increasing subsequence — same idea, 1D array instead of grid
The moment you see grid + path + overlapping subproblems + no cycles, reach for DFS + memoization.
Constraints: Constraints:
• m == matrix.length
• n == matrix[i].length
• 1 <= m, n <= 200
• 0 <= matrix[i][j] <= 231 - 1
Intuition: Approach #2 (DFS + Memoization) [Accepted]
Intuition
Cache the results for the recursion so that any subproblem will be calculated only once.
Algorithm
From previous analysis, we know that there are many duplicate calculations in the naive approach.
One optimization is that we can use a set to prevent the repeat visit in one DFS search. This optimization will reduce the time complexity for each DFS to O(mn) and the total algorithm to O(m2n2).
Here, we will introduce more powerful optimization, Memoization.In computing, memoization is an optimization technique used primarily to speed up computer programs by storing the results of expensive function calls and returning the cached result when the same inputs occur again.
In our problem, we recursively call dfs(x, y) for many times. But if we already know all the results for the four adjacent cells, we only need constant time. During our search if the result for a cell is not calculated, we calculate and cache it; otherwise, we get it from the cache directly.
Algorithm: DFS
Optimisation : DFS, Memoisation - Top down approach
Rationale: Here it is:
How is memoization useful here?
The key insight is that the same cell gets reached from multiple starting points.
Consider this example matrix path exploration:
• Starting from (2,0) value 2: it explores 2 → 6 → 9
• Starting from (1,0) value 6: it would explore 6 → 9 again
Without memoization, dfs(1,0) gets recomputed every time any lower-valued neighbor points to it. With memoization, the second time you reach (1,0), cache[1][0] is already filled — you skip the recursion entirely and return instantly.
The structure that makes this work:
Since we only move to strictly greater values, the paths form a DAG (Directed Acyclic Graph) — no cycles are possible. This means:
(2,0) → (1,0) → (0,0)   ← path length 3
↑
(2,1) ──┘                ← (1,0) reused, no recomputation
Cell (1,0) might be reachable from (2,0), (2,1), (2,2), and more. Each of those would independently re-explore the entire subtree rooted at (1,0) without memoization.
The complexity difference is stark:
Plain DFS (no memo) → Time: O(2^(m×n)) exponential | Space: O(m×n) stack
DFS + memoization   → Time: O(m×n)                 | Space: O(m×n) cache
Without memo, you're re-exploring exponentially branching subtrees. With memo, each cell is computed exactly once — subsequent hits are O(1) lookups. For a 3×3 grid that's already significant; on a 200×200 grid (LeetCode's actual constraint), the difference is the gap between milliseconds and heat-death of the universe.
The cache[i][j] != 0 check is the entire memoization guard — one line that collapses exponential work into linear.
Code: // DFS + Memoization Solution
// Accepted and Recommended
public class Solution {
private static final int[][] dirs = {{0, 1}, {1, 0}, {0, -1}, {-1, 0}};
private int m, n;

public int longestIncreasingPath(int[][] matrix) {
if (matrix.length == 0) return 0;
m = matrix.length; n = matrix[0].length;
int[][] cache = new int[m][n];
int ans = 0;
for (int i = 0; i < m; ++i)
for (int j = 0; j < n; ++j)
ans = Math.max(ans, dfs(matrix, i, j, cache));
return ans;
}

private int dfs(int[][] matrix, int i, int j, int[][] cache) {
if (cache[i][j] != 0) return cache[i][j];
for (int[] d : dirs) {
int x = i + d[0], y = j + d[1];
if (0 <= x && x < m && 0 <= y && y < n && matrix[x][y] > matrix[i][j])
cache[i][j] = Math.max(cache[i][j], dfs(matrix, x, y, cache));
}
return ++cache[i][j];
}
}
Dry run: https://claude.ai/share/8674b9a1-4b87-471b-95ee-940c6ce62563
Complexity: Complexity Analysis
• Time complexity : O(mn). Each vertex/cell will be calculated once and only once, and each edge will be visited once and only once. The total time complexity is then O(V+E). V is the total number of vertices and E is the total number of edges. In our problem, O(V)=O(mn), O(E)=O(4V)=O(mn).
• Space complexity : O(mn). The cache dominates the space complexity.
Visualisation: https://claude.ai/share/8674b9a1-4b87-471b-95ee-940c6ce62563
Claude link: https://claude.ai/share/8674b9a1-4b87-471b-95ee-940c6ce62563

© 2026 Vidya Srinivasa Kesarla. All rights reserved.