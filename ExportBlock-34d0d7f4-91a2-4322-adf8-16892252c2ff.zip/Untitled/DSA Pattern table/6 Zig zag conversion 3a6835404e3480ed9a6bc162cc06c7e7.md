# 6. Zig zag conversion

Difficulty: Medium
Input Data Structure: Integer, String
Pattern trigger(recognition) / constraints hint / : This problem’s signal words/pattern that point to this approach:
Recognizing it as a “simulation” / index-math problem:
• The problem describes a visual/geometric arrangement (zigzag, spiral, diagonal, snake pattern) rather than a comparison or search — that’s a strong hint you’re simulating a shape, not doing DP/greedy/binary search.
• You’re asked to rearrange characters based on position, not filter/count/sum them — signals index manipulation.
• There’s a repeating cycle (down then up, like a zigzag) — signals you should find the period of repetition (here, charsInSection) and use modular/offset arithmetic instead of literally building a grid.
Key phrases that trigger this pattern in general:
• “arrange in rows/columns”, “diagonal”, “zigzag”, “spiral”, “snake order” → simulate movement or find a repeating stride.
• “read row by row” / “read column by column” after some rearrangement → build per-row buffers (like the StringBuilder[] version) or compute direct index formulas.
Two common implementation strategies for this family of problems:
1. Direct simulation (StringBuilder[] + direction flag) — simpler to reason about, mirrors the “go down, bounce, go up” description literally.
2. Math/index-jumping (the original solution) — faster to write once you spot the period, avoids extra space, but requires deriving the jump formula (charsInSection, charsInBetween).
Rule of thumb: if a problem’s transformation is “geometric” (grid, diagonal, spiral, zigzag), look for a repeating unit/cycle length — that’s usually the key relationship to compute (as charsInSection does here).
Constraints: 
• 1 <= s.length <= 1000
• s consists of English letters (lower-case and upper-case), ',' and '.'.
• 1 <= numRows <= 1000
Brute force code and its trade off: class Solution {
public String convert(String s, int numRows) {
if (numRows == 1) {
return s;
}

int n = s.length();
int sections = (int) Math.ceil(n / (2 * numRows - 2.0));
int numCols = sections * (numRows - 1);

char[][] matrix = new char[numRows][numCols];
for (char[] row : matrix) {
Arrays.fill(row, ' ');
}

int currRow = 0, currCol = 0;
int currStringIndex = 0;

// Iterate in zig-zag pattern on matrix and fill it with string characters.
while (currStringIndex < n) {
// Move down.
while (currRow < numRows && currStringIndex < n) {
matrix[currRow][currCol] = s.charAt(currStringIndex);
currRow++;
currStringIndex++;
}

currRow -= 2;
currCol++;

// Move up (with moving right also).
while (currRow > 0 && currCol < numCols && currStringIndex < n) {
matrix[currRow][currCol] = s.charAt(currStringIndex);
currRow--;
currCol++;
currStringIndex++;
}
}

StringBuilder answer = new StringBuilder();
for (char[] row : matrix) {
for (char character : row) {
if (character != ' ') {
answer.append(character);
}
}
}

return answer.toString();
}
}
Intuition: https://leetcode.com/problems/zigzag-conversion/editorial/?envType=company&envId=apple&favoriteSlug=apple-all#approach-2-string-traversal
Algorithm: Simulate Zig zag movement
Optimisation : String Traversal
Code: class Solution {
public String convert(String s, int numRows) {
if(numRows == 1){
return s;
}

StringBuilder answer = new StringBuilder();
int n = s.length();
int charsInSection = (numRows - 1) * 2;

for(int currRow = 0;currRow < numRows;currRow++){
int id = currRow;

while(id < n){
answer.append(s.charAt(id));
//current row is not first or last row
if (currRow != 0 && currRow != numRows - 1){
int charsInBetween = charsInSection - 2 * currRow;
int secondIndex = id + charsInBetween;

if(secondIndex < n) {
answer.append(s.charAt(secondIndex));
}

}

id += charsInSection;
}
}
return answer.toString();
}
}

Dry run: Dry run: s = "PAYPALISHIRING", numRows = 4
Index reference:
0:P 1:A 2:Y 3:P 4:A 5:L 6:I 7:S 8:H 9:I 10:R 11:I 12:N 13:G
n = 14, charsInSection = (4-1)*2 = 6
Row 0 (currRow=0, first row → no middle append)idappendnext id0P66I1212N18 → stop (≥14)
→ "PIN"
Row 1 (currRow=1, middle row → charsInBetween = 6 - 2*1 = 4)idappend s[id]secondIndex = id+4append s[secondIndex]?next id1A5L (5<14 ✓)77S11I (11<14 ✓)1313G17skip (17≥14)19 → stop
→ "ALSIG"
Row 2 (currRow=2, middle row → charsInBetween = 6 - 4 = 2)idappend s[id]secondIndex = id+2append s[secondIndex]?next id2Y4A (4<14 ✓)88H10R (10<14 ✓)14 → stop
→ "YAHR"
Row 3 (currRow=3, last row → no middle append)idappendnext id3P99I15 → stop
→ "PI"
Final concatenation:
"PIN" + "ALSIG" + "YAHR" + "PI" = "PINALSIGYAHRPI"
That matches the expected LeetCode output for this classic test case. ✅
Complexity: Complexity Analysis
Here, n is the length of the input string.
• Time complexity: O(n).
    ◦ We iterate over each index of the input only once and perform constant work at each index.
• Space complexity: O(1).
    ◦ We have not used any additional space other than for building the output, which is not counted.
follow up questions: 1. Walkthrough with s = "PAYPALISHIRING", numRows = 4
Zigzag pattern:
P...I...N
A.L.S.I.G
Y.A.H.R
P...I
charsInSection = (4-1)*2 = 6 (one full up-down cycle).
• Row 0 (first row): only id, id+6, id+12... → indices 0,6,12 → P, I, N
• Row 3 (last row): same pattern, just offset → indices 3,9 → P, I
• Row 1 (middle): between-index = 6 - 2*1 = 4 → for id=1: append s[1]=‘A’, then s[1+4=5]=‘L’; next id=7: s[7]=‘S’, then s[11]=‘I’… etc.
• Row 2 (middle): between-index = 6 - 4 = 2 → id=2: s[2]=‘Y’, then s[4]=‘A’; id=8: s[8]=‘H’, s[10]=‘R’…
Concatenating rows 0-3 gives "PINALSIGYAHRPI".
2. Why charsInSection = (numRows - 1) * 2?
One full zigzag cycle (down the column, then diagonally back up) touches numRows cells going down, but doesn’t repeat the top and bottom row, so the diagonal-up part has numRows - 2 cells. Total distinct steps in one cycle = (numRows - 1) down + (numRows - 1) diagonal = 2 * (numRows - 1). That’s the column-width of one repeating unit — i.e., how far apart two same-row characters (from consecutive “down” passes) are.
3. Time and space complexity
• Time: O(n) — each character is visited once.
• Space: O(n) for the output StringBuilder (not counting output, it’s O(1) extra space since only a few index variables are used).
4. Edge cases
• numRows == 1 → handled explicitly, returns s unchanged (loop would divide by charsInSection=0 otherwise).
• numRows >= s.length() → each row gets at most one character, effectively returns s unchanged (works fine, no crash).
• Empty string s = "" → loop conditions (id < n) never true, returns empty string. Fine.
• numRows == 0 — not valid per constraints, would cause issues (array/loop logic breaks), but LeetCode guarantees numRows ≥ 1.
5. Simpler rewrite using StringBuilder array
public String convert(String s, int numRows) {
    if (numRows == 1) return s;
    StringBuilder[] rows = new StringBuilder[numRows];
    for (int i = 0; i < numRows; i++) rows[i] = new StringBuilder();


    int curRow = 0;
    boolean goingDown = false;


    for (char c : s.toCharArray()) {
        rows[curRow].append(c);
        if (curRow == 0 || curRow == numRows - 1) goingDown = !goingDown;
        curRow += goingDown ? 1 : -1;
    }


    StringBuilder result = new StringBuilder();
    for (StringBuilder row : rows) result.append(row);
    return result.toString();
}
This simulates the zigzag movement directly instead of computing jump distances — easier to read, same O(n) time, but O(n) extra space for the row buffers (vs. the original’s O(1) extra, excluding output).
6. Zigzag intuition
Imagine writing the string in a “N” shape repeated sideways: go straight down filling one column, then move diagonally up-right one step at a time until you hit the top, then straight down again. Reading the result row by row (left to right) recreates the zigzag’s row-major order without needing an actual 2D grid.
7. O(1) extra space (excluding output)?
Yes — the original solution already does this. It computes jump offsets mathematically instead of storing per-row buffers, so aside from the output StringBuilder (which is unavoidable, since you must produce the answer), it only uses a constant number of int variables. The array-based rewrite above trades that for readability at the cost of O(n) extra space.

© 2026 Vidya Srinivasa Kesarla. All rights reserved.