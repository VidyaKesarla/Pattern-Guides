# 86. Partition List (1)

Difficulty: Medium
Input Data Structure: LinkedList
Rationale: https://leetcode.com/problems/partition-list/editorial/

© 2026 Vidya Srinivasa Kesarla. All rights reserved.