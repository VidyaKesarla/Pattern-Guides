# 160. Intersection of Two Linked Lists

Difficulty: Easy
Input Data Structure: LinkedList
Constraints: 
• The number of nodes of listA is in the m.
• The number of nodes of listB is in the n.
• 1 <= m, n <= 3 * 104
• 1 <= Node.val <= 105
• 0 <= skipA <= m
• 0 <= skipB <= n
• intersectVal is 0 if listA and listB do not intersect.
• intersectVal == listA[skipA] == listB[skipB] if listA and listB intersect.
 
Rationale: https://leetcode.com/problems/intersection-of-two-linked-lists/description/

© 2026 Vidya Srinivasa Kesarla. All rights reserved.