# 1514. Path with maximum probability

Difficulty: Medium
Input Data Structure: 2D Array, Array, Integer
Pattern trigger(recognition) / constraints hint / : Pattern signals for Dijkstra (this problem):

•	“Maximize/minimize a value along a path” with edge weights combining multiplicatively or additively and a single source/destination → shortest/longest path problem.
•	All weights are non-negative (probabilities are between 0 and 1, multiplying only shrinks or keeps the value) → Dijkstra is valid; no need for Bellman-Ford.
•	You need the best path to one specific target, not all-pairs → single-source shortest path, which is Dijkstra/Bellman-Ford territory rather than Floyd-Warshall.
•	“Greedy + priority queue” fits because once a node’s optimal value is finalized, it can’t improve later — true here since multiplying by probabilities (≤1) only decreases values, so the heap always pops the best candidate first.

When you’d instead reach for Bellman-Ford:

•	Weights can be negative (e.g., “minimize cost” where costs can be negative, or detecting arbitrage where you take logs of probabilities — log(p) < 0).
•	Need to detect a negative cycle.
•	No reasonable bound on relaxation rounds needed (Bellman-Ford is the fallback “always correct, just slower” choice).


Signal / Paraphrase hint: Quick mental checklist when you see this kind of problem:

1.	Graph + weighted edges + “find best path from A to B”? → shortest-path family.
2.	Are weights non-negative (or can be normalized to be, e.g., by negative log)? → Dijkstra.
3.	Could weights be negative and you can’t avoid that? → Bellman-Ford (or Bellman-Ford + log trick if it’s a “maximize product” → “minimize sum of negative logs” transformation).
4.	Need shortest paths between all pairs? → Floyd-Warshall (or Johnson’s for sparse + negative weights).

For this specific problem: probabilities ∈ [0,1], multiplying them only decreases the value, single source → single target, non-negative effective “weights” — that combination is the strongest signal it’s Dijkstra (max-heap variant).
Constraints: Constraints:
• 2 <= n <= 10^4
• 0 <= start, end < n
• start != end
• 0 <= a, b < n
• a != b
• 0 <= succProb.length == edges.length <= 2*10^4
• 0 <= succProb[i] <= 1
• There is at most one edge between every two nodes.
Brute force code and its trade off: class Solution {

public double maxProbability(
int n,
int[][] edges,
double[] succProb,
int start,
int end
) {
double[] maxProb = new double[n];
maxProb[start] = 1.0;

for (int i = 0; i < n - 1; i++) {
boolean hasUpdate = false;
for (int j = 0; j < edges.length; j++) {
int u = edges[j][0];
int v = edges[j][1];
double pathProb = succProb[j];
if (maxProb[u] * pathProb > maxProb[v]) {
maxProb[v] = maxProb[u] * pathProb;
hasUpdate = true;
}
if (maxProb[v] * pathProb > maxProb[u]) {
maxProb[u] = maxProb[v] * pathProb;
hasUpdate = true;
}
}
if (!hasUpdate) {
break;
}
}

return maxProb[end];
}
}
Intuition: https://leetcode.com/problems/path-with-maximum-probability/editorial/#approach-3-dijkstras-algorithm
Algorithm: Bellman ford
Optimisation : Dijkstra’s algorithm
Why this is better? Optimisation details: Adaptation of dijsktra - Let n be the number of nodes and m be the number of edges.
• Time Complexity: O((n+m)⋅logn)
    ◦ We build an adjacency list graph based on all edges, which takes O(m) time.
    ◦ In the worst case, each node could be pushed into the priority queue exactly once, which results in O(n⋅logn) operations.
    ◦ Each edge is considered exactly once when its corresponding node is dequeued from the priority queue. This takes O(m⋅logn) time in total, due to the priority queue's logn complexity for insertion and deletion operations.You can also refer to our https://leetcode.com/explore/learn/card/graph/622/single-source-shortest-path-algorithm/3862/ for details on the complexity analysis.
• Space Complexity: O(n+m)
    ◦ We build an adjacency list graph based on all edges, which takes O(m) space.
    ◦ The algorithm stores the maxProb array, which uses O(n) space.
    ◦ We use a priority queue to keep track of nodes to be visited, and there are at most n nodes in the queue.
    ◦ To sum up, the overall space complexity is O(n+m).
Rationale: Line-by-line explanation

This is Dijkstra’s algorithm adapted for maximum probability instead of minimum distance — multiply probabilities along a path, and use a max-heap instead of a min-heap.

•	Map<Integer, List<Pair<Integer, Double>>> graph: adjacency list, node → list of (neighbor, edge probability).
•	The for loop builds the graph as undirected — since edges[i] = [u,v] connects both ways, add v to u’s list and u to v’s list, each with weight pathProb.
•	maxProb[n]: array storing best probability found so far to reach each node, initialized to 0 (default), except maxProb[start] = 1 (you start there with certainty 1).
•	pq: a max-heap (note the -Double.compare, which reverses normal min-heap order) of (probability, node), so we always process the most “promising” node next.
•	pq.add(new Pair<>(1.0, start)): seed the queue with the start node at probability 1.

Main loop:

•	cur = pq.poll(): pop the node with highest probability so far.
•	if (curNode == end) return curProb: early exit — since it’s a max-heap, the first time we pop end, that’s guaranteed to be the best probability (greedy property of Dijkstra).
•	if (graph.containsKey(curNode)): check this node hasn’t been “processed/removed” yet — acts as a visited check.
•	Inner loop: for each neighbor nxtNode via edge probability pathProb, compute curProb * pathProb. If it’s better than what we’ve recorded for nxtNode, update maxProb[nxtNode] and push it to the queue.
•	graph.remove(curNode): removes this node’s adjacency list so it won’t be reprocessed — this is the “visited” marker.

Dry run

Example: n=3, edges=[[0,1],[1,2],[0,2]], succProb=[0.5,0.5,0.3], start=0, end=2

Graph:

0: [(1, 0.5), (2, 0.3)]
1: [(0, 0.5), (2, 0.5)]
2: [(1, 0.5), (0, 0.3)]

Step 1: pop (1.0, 0). Not end. Process neighbors of 0:

•	→ 1: 1.0 * 0.5 = 0.5 > maxProbnotion://app.notion.com/p/0 → update maxProb[1]=0.5, push (0.5, 1)
•	→ 2: 1.0 * 0.3 = 0.3 > maxProbnotion://app.notion.com/p/0 → update maxProb[2]=0.3, push (0.3, 2)

Remove node 0 from graph. pq = [(0.5,1), (0.3,2)], maxProb = [1, 0.5, 0.3]

Step 2: pop (0.5, 1) (highest). Not end. Process neighbors of 1:

•	→ 0: graph doesn’t contain 0 anymore… wait, actually graph still has entry for 1 with edges to 0 and 2 — but we check curProb * pathProb > maxProb[nxtNode], not whether node 0 is removed. 0.5 * 0.5 = 0.25, compare to maxProb[0]=1 → not greater, skip.
•	→ 2: 0.5 * 0.5 = 0.25, compare to maxProb[2]=0.3 → not greater, skip.

Remove node 1 from graph. pq = [(0.3, 2)]

Step 3: pop (0.3, 2). curNode == end → return 0.3

Summary

The answer is 0.3, achieved via direct edge 0→2 (probability 0.3), rather than the path 0→1→2 (probability 0.25).

Key insight: because we use a max-heap, the first time we pop the end node, its probability is guaranteed maximal (greedy Dijkstra correctness), so we can return immediately.

Code: class Solution {
public double maxProbability(int n, int[][] edges, double[] succProb, int start_node, int end_node) {
//we are going to use dijkstra's algorithm adapted for maximum probability instead of shortest / minimum distance

//Adjacency list, node - > list of (neighbor, edge probability)
Map<Integer, List<Pair<Integer, Double>>> graph = new HashMap<>();

for(int i =0;i<edges.length;i++){
//source
int u = edges[i][0];
//destination
int v = edges[i][1];

//take the current probability
double edgeProb = succProb[i];

/* Equivalent code for below:
if(!map.containsKey(u)){
map.put(u, new ArrayList<>());
}
map.get(u).add(new Pair<>(v, pathProb));
*/
graph.computeIfAbsent(u, k -> new ArrayList<>()).add(new Pair<>(v, edgeProb));
graph.computeIfAbsent(v, k -> new ArrayList<>()).add(new Pair<>(u, edgeProb));
} // Closed the graph-building loop properly here

//create a max probability array
double [] maxProb = new double[n];
maxProb[start_node] = 1.0;

//Initialize an empty queue queue to store nodes that need to be visited.
//max heap
PriorityQueue<Pair<Double, Integer>> pq = new PriorityQueue<>((a,b) -> -Double.compare(a.getKey(), b.getKey()));

//Add the starting node start and its probability to the priority queue.
pq.add(new Pair<>(1.0,start_node));

while(!pq.isEmpty()){
//remove cur_node, the node with the highest priority from it
Pair<Double, Integer> curr = pq.poll();

double curProb = curr.getKey();
int currNode = curr.getValue();

if(currNode == end_node) {
return curProb;
}


// For each neighbor nxt_node of the current node cur_node, calculate the probability of traveling from the starting node to the nxt_node through the current edge cur_node --- nxt_node, and update the maximum probability of nxt_node if necessary. To update the maximum probability, compare the product of the probability with the current node and the probability of the edge cur_node --- nxt_node, with the current maximum probability to the neighbor node. If the product is larger than the maximum probability stored in max_prob[nxt_node], we update the maximum probability max_prob[nxt_node] as their product.

if(graph.containsKey(currNode)) {
// Check if the node has been processed
for( Pair<Integer, Double> neighbor: graph.getOrDefault(currNode, new ArrayList<>())) {
int nextNode = neighbor.getKey();
double pathProb = neighbor.getValue();
if(curProb * pathProb > maxProb[nextNode]) {
maxProb[nextNode] = curProb * pathProb;
pq.add(new Pair<> (maxProb[nextNode], nextNode));
}
}
graph.remove(currNode); //clear the adjacency list by removing the entry
}
}
return 0.0;
}
}

Dry run: https://claude.ai/share/c00206f6-fedf-422f-97b5-b752509d5e3f
Complexity: Let n be the number of nodes and m be the number of edges.
• Time Complexity: O((n+m)⋅logn)
    ◦ We build an adjacency list graph based on all edges, which takes O(m) time.
    ◦ In the worst case, each node could be pushed into the priority queue exactly once, which results in O(n⋅logn) operations.
    ◦ Each edge is considered exactly once when its corresponding node is dequeued from the priority queue. This takes O(m⋅logn) time in total, due to the priority queue's logn complexity for insertion and deletion operations.You can also refer to our https://leetcode.com/explore/learn/card/graph/622/single-source-shortest-path-algorithm/3862/ for details on the complexity analysis.
• Space Complexity: O(n+m)
    ◦ We build an adjacency list graph based on all edges, which takes O(m) space.
    ◦ The algorithm stores the maxProb array, which uses O(n) space.
    ◦ We use a priority queue to keep track of nodes to be visited, and there are at most n nodes in the queue.
    ◦ To sum up, the overall space complexity is O(n+m).
Visualisation: https://claude.ai/share/c00206f6-fedf-422f-97b5-b752509d5e3f
Claude link: https://claude.ai/share/c00206f6-fedf-422f-97b5-b752509d5e3f
Similar questions: 	•	Network Delay Time — LeetCode 743
•	Word Ladder — LeetCode 127
•	Path With Minimum Effort — LeetCode 1631
•	Cheapest Flights Within K Stops — LeetCode 787
•	Path with Maximum Probability (the one we worked through) — LeetCode 1514
Similar questions (1): Here they are as plain text — copy these directly:  Network Delay Time: https://leetcode.com/problems/network-delay-time/ Word Ladder: https://leetcode.com/problems/word-ladder/ Path With Minimum Effort: https://leetcode.com/problems/path-with-minimum-effort/ Cheapest Flights Within K Stops: https://leetcode.com/problems/cheapest-flights-within-k-stops/ Path with Maximum Probability: https://leetcode.com/problems/path-with-maximum-probability/

© 2026 Vidya Srinivasa Kesarla. All rights reserved.