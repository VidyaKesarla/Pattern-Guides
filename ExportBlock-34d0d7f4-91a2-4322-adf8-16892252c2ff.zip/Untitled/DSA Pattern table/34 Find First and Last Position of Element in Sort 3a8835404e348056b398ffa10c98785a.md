# 34. Find First and Last Position of Element in Sorted Array

Difficulty: Medium
Input Data Structure: Array
Pattern trigger(recognition) / constraints hint / : “sorted array” “find position”
Clarifying questions: //questions i can ask the interviewer?

//can there be negative numbers in the array?
Constraints: Constraints:
• 0 <= nums.length <= 105
• -109 <= nums[i] <= 109
• nums is a non-decreasing array.
• -109 <= target <= 109
Brute force code and its trade off: 2. BRUTE FORCE VS. OPTIMIZED TRADEOFFS
--------------------------------------------------------------------------------
- Brute Force (Linear Scan):
* Approach: Iterate from index 0 to N-1 using a single pointer to find the
start and end of the target window.
* Time Complexity: O(n) worst-case (e.g., if the entire array consists of
the target value).
* Space Complexity: O(1)
* Tradeoff: Highly intuitive and simple to code without boundary mistakes,
but completely wastes the "pre-sorted" property, making it inefficient
for massive datasets.
Intuition: 1. INPUT DATA STRUCTURE & WHAT IT ACHIEVES
--------------------------------------------------------------------------------
- Structure: Contiguous 1D Primitive Array (int[])
- Key Property: Pre-sorted in ascending order.
- Achievement: Sorted arrays grant us random access (O(1) time to read any element
via its index). Combined with the sorted nature, this gives us a predictable
data layout which is the absolute prerequisite for Binary Search. If this
were a Linked List, even if sorted, jumping to the "mid" element would take
O(n) time, making O(log n) impossible.
Edge cases / base cases:  //edge cases to consider are empty array, then the array doesnt contain the target number, or given target is 0
//if its not there anywhere this target in my array - then i will return -1,-1


//questions i can ask the interviewer?

//can there be negative numbers in the array?


//approach i can think of for this is:
//binary search would work its best. why? because given a sorted array, binary search will help me look at the middle element of the given array and based on this value we can decide to discard one hald of the array,  either the left half or the right half.
//At each step, i will reduce the length of the array to search by half and that is what will lead to logarithmic time complexity.
//Usage of binary search algorithm is usually to determine if an element is in a sorted array.
//we can tweak this binary search algorithm to find the first and last position of the element.

//use two variables to keep track of the subarray that we are scanning : begin and end.
//begin will be set to 0. end will be set to the last index of the array


//we will iterate until begin is greater than end

//at each step: calculate: middle element = begin + end / 2


//depending on the value of the middle, we will decide which half of the array we need to search

// if target we are searching for has a value lower than the mid element we will discard the right of the array. end = mid - 1

// if target we are searching for has a value higher than the mid element we will discard the left of the array => begin = mid+ 1

//if nums[mid] == target element then we have found our target and we just need to return from there

//Why linear scan wont work in this case: It wont work because in the worst case: when our entire array is filled with the target then i have to keep doing the search or i have to keep going until i find the first occurrence of this target. thats why this will take more time than the binary search

// two binary searches: to find the first and last position of the target

//so this question is not just trying to compare nums[mid] with target whether they are equal or not. instead of checking for equality, we also need to check if mid is the first or the last index where the target occurs.


//how can we achieve this?

//if mid is the same as begin: mid is the first element in the remaining subarray

//element to the left of this index is not equal to the target that we are searching for. nums[mid-1] != target if this condition is not met, we should keep searching on the left side of the array for the first occurrance of the target.
Optimisation : Binary search, One pass optimisation, Two binary searches
Why this is better? Optimisation details: - Optimized Approach (Modified Dual Binary Search):
* Approach: Run two separate, modified binary searches—one biased to lock
onto the leftmost boundary, and one biased to lock onto the rightmost.
* Time Complexity: O(log n). Dividing the search space in half at each step
means an array of 1,000,000 elements resolves in ~20 operations per search.
* Space Complexity: O(1) as the search is performed iteratively in-place.
* Tradeoff: Slightly more complex implementation logic that requires close
attention to edge conditions (mid - 1 and mid + 1 boundaries) to avoid
IndexOutOfBounds errors.
Rationale: https://leetcode.com/problems/find-first-and-last-position-of-element-in-sorted-array/editorial/?envType=company&envId=apple&favoriteSlug=apple-all#approach-binary-search
Code: class Solution {
public int[] searchRange(int[] nums, int target) {
int firstOccurance = this.findBound(nums, target, true);

if(firstOccurance == -1){
return new int[] {-1,-1};
}

int lastOccurance = this.findBound(nums, target, false);

return new int[] {firstOccurance, lastOccurance};

}
private int findBound(int[] nums, int target, boolean isFirst){
int begin = 0;

int N = nums.length;
int end = N - 1;

while(begin <= end){
int mid = (begin + end)/2;

if(nums[mid] == target){
if(isFirst){
//first occurance of the element
if(mid == begin || nums[mid-1] != target){
return mid;
}
//search on the left side of the bound
end = mid - 1;
} else {
//last occurance of the element
if(mid == end || nums[mid+1] != target){
return mid;
}
//search on the right side of the bound
begin = mid + 1;
}
} else if(nums[mid] > target){
end = mid - 1;
} else {
begin = mid + 1;
}
}
return -1;
}
}


Dry run: 3. ALGORITHM DRY RUN EXPLAINED
--------------------------------------------------------------------------------
Example Input: nums = [5, 7, 7, 8, 8, 10], target = 8

- Finding First Occurrence (isFirst = true):
* Step 1: begin = 0, end = 5. mid = (0 + 5) / 2 = 2. nums[2] is 7.
Since 7 < 8, target must be right. begin becomes mid + 1 = 3.
* Step 2: begin = 3, end = 5. mid = (3 + 5) / 2 = 4. nums[4] is 8.
Match found! But is it the first? nums[mid-1] (nums[3]) is also 8.
So we must look further left. end becomes mid - 1 = 3.
* Step 3: begin = 3, end = 3. mid = (3 + 3) / 2 = 3. nums[3] is 8.
Match found! Since mid == begin (3 == 3), it is verified as the
first occurrence. Returns index 3.

- Finding Last Occurrence (isFirst = false):
* Step 1: Resets search space. Finds nums[4] = 8. Checks boundary:
nums[mid+1] (nums[5]) is 10, which is != target. This confirms
it is the last occurrence. Returns index 4.

Final Output: [3, 4]

Complexity: 
• Time Complexity: O(logN) considering there are N elements in the array. This is because binary search takes logarithmic time to scan an array of N elements. Why? Because at each step we discard half of the array we are scanning and hence, we're done after a logarithmic number of steps. We simply perform binary search twice in this case.
• Space Complexity: O(1) since we only use space for a few variables and our result array, all of which require constant space.
follow up questions: 4. PRODUCTION-GRADE REFINEMENTS (CRITICAL FOLLOW-UPS)
--------------------------------------------------------------------------------
- Integer Overflow Prevention:
Instead of int mid = (begin + end) / 2;, standard production code uses
int mid = begin + (end - begin) / 2;. If begin and end are extremely
large integers, their sum could exceed 2^31 - 1, causing a fatal integer
overflow resulting in an invalid negative index.

- Code De-duplication Trick:
Instead of tracking an isFirst flag with unique branching logic, you can
write a single strict "find left-most insertion point" function.
To find the first position, search for target. To find the last position,
search for target + 1 using the exact same left-bound logic, and look at
the index immediately preceding its result.

© 2026 Vidya Srinivasa Kesarla. All rights reserved.