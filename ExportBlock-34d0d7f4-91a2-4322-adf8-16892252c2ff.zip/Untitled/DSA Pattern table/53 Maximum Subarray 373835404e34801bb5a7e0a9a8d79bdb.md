# 53. Maximum Subarray

Difficulty: Medium
Input Data Structure: Array
Constraints: 
• 1 <= nums.length <= 105
• -104 <= nums[i] <= 104
Algorithm: optimised brute force
Optimisation : DP, Kadane's algorithm
Why this is better? Optimisation details: Whenever you see a question that asks for the maximum or minimum of something, consider Dynamic Programming as a possibility. The difficult part of this problem is figuring out when a negative number is "worth" keeping in a subarray. This question in particular is a popular problem that can be solved using an algorithm called https://leetcode.com/link/?target=https%3A%2F%2Fen.wikipedia.org%2Fwiki%2FMaximum_subarray_problem%23Kadane%27s_algorithm. If you're good at problem solving though, it's quite likely you'll be able to come up with the algorithm on your own. This algorithm also has a very greedy-like intuition behind it.
Rationale: 
1. Initialize 2 integer variables. Set both of them equal to the first value in the array.
    ◦ currentSubarray will keep the running count of the current subarray we are focusing on.
    ◦ maxSubarray will be our final return value. Continuously update it whenever we find a bigger subarray.
2. Iterate through the array, starting with the 2nd element (as we used the first element to initialize our variables). For each number, add it to the currentSubarray we are building. If currentSubarray becomes negative, we know it isn't worth keeping, so throw it away. Remember to update maxSubarray every time we find a new maximum.
3. Return maxSubarray.
Code: https://leetcode.com/problems/maximum-subarray/submissions/1852791558/
Dry run: DRY RUN:
* Input Array: nums = [-2, 1, -3, 4]
* * Initialization:
* currentSubarray = nums[0] -> -2
* maximumSubarray = nums[0] -> -2
* * Loop Iterations:
* 1. i = 1, num = 1:
* currentSubarray = Math.max(-2 + 1, 1) -> Math.max(-1, 1) = 1
* maximumSubarray = Math.max(1, -2) = 1
* * 2. i = 2, num = -3:
* currentSubarray = Math.max(1 + (-3), -3) -> Math.max(-2, -3) = -2
* maximumSubarray = Math.max(-2, 1) = 1
* * 3. i = 3, num = 4:
* currentSubarray = Math.max(-2 + 4, 4) -> Math.max(2, 4) = 4
* maximumSubarray = Math.max(4, 1) = 4
* * Returns maximumSubarray -> 4
* * -—
Complexity: 
• Time complexity: O(N), where N is the length of nums.
We iterate through every element of nums exactly once.
• Space complexity: O(1)
No matter how long the input is, we are only ever using 2 variables: currentSubarray and maxSubarray.
Visualisation: https://leetcode.com/problems/maximum-subarray/editorial/

© 2026 Vidya Srinivasa Kesarla. All rights reserved.