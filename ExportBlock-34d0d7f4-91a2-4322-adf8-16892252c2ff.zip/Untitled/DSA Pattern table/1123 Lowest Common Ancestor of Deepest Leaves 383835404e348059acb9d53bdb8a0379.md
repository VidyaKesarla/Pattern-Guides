# 1123. Lowest Common Ancestor of Deepest Leaves

Difficulty: Medium
Input Data Structure: Array, Binary tree, TreeNode
Pattern trigger(recognition) / constraints hint / :  “Tree traversal” “
• The node of a binary tree is a leaf if and only if it has no children
• The depth of the root of the tree is 0. if the depth of a node is d, the depth of each of its children is d + 1.
• The lowest common ancestor of a set S of nodes, is the node A with the largest depth such that every node in S is in the subtree with root A.”
Clarifying questions: About the input:

•	Can the tree be empty (null root)?
•	Can the tree have duplicate values?
•	How large can the tree be — any constraints on height or node count?

About the output:

•	If there is only one deepest leaf, do we return that leaf itself?
•	If there are multiple deepest leaves, are they guaranteed to have a unique LCA?
Constraints: Constraints:
• The number of nodes in the tree will be in the range [1, 1000].
• 0 <= Node.val <= 1000
• The values of the nodes in the tree are unique.
Intuition: The problem gives a binary tree and requires returning the lowest common ancestor of its deepest leaf node. The depth of the tree's root node is 0. We note that all nodes with the maximum depth are leaf nodes. For convenience, we refer to the lowest common ancestor of the deepest leaf nodes as the lca node.
We use a recursive method to perform a depth-first search, recursively traversing each node in the tree and returning the maximum depth d of the current subtree and the lcanode. If the current node is null, we return depth 0 and an null node. In each search, we recursively search the left and right subtrees, and then compare the depths of the left and right subtrees:
• If the left subtree is deeper, the deepest leaf node is in the left subtree, we return {left subtree depth + 1, the lca node of the left subtree}
• If the right subtree is deeper, the deepest leaf node is in the right subtree, we return {right subtree depth + 1, the lca node of the right subtree}
• If both left and right subtrees have the same depth and both have the deepest leaf nodes, we return {left subtree depth + 1, current node}.
Finally, we return the root node's lca node.
Edge cases / base cases: If (root == null) {
return new Pair<>(null, 0);
}
Algorithm: Recursion
Optimisation : Recursion
Code: class Solution {

public TreeNode lcaDeepestLeaves(TreeNode root) {
return dfs(root).getKey();
}

private Pair<TreeNode, Integer> dfs(TreeNode root) {
if (root == null) {
return new Pair<>(null, 0);
}

Pair<TreeNode, Integer> left = dfs(root.left);
Pair<TreeNode, Integer> right = dfs(root.right);

if (left.getValue() > right.getValue()) {
return new Pair<>(left.getKey(), left.getValue() + 1);
}
if (left.getValue() < right.getValue()) {
return new Pair<>(right.getKey(), right.getValue() + 1);
}
return new Pair<>(root, left.getValue() + 1);
}
}
Complexity: Complexity Analysis
Let n be the number of tree nodes.
• Time complexity: O(n)
We only need to traverse all the nodes in the tree once.
• Space complexity: O(n)
The space complexity is mainly the recursive space, with the worst case being O(n).
follow up questions: Complexity:

•	Should I analyze the time and space complexity of my solution?
•	Is O(n) time acceptable or are you looking for something better?

Optimization:

•	Is there a way to solve this iteratively instead of recursively?
•	Would you prefer I avoid creating Pair objects to reduce memory allocations?

Variants:

•	What if we wanted the LCA of the shallowest leaves instead?
•	What if this were an n-ary tree instead of binary?
Visualisation: https://claude.ai/share/a542676c-8629-4e92-9deb-b1b32c415e38
Claude link: https://claude.ai/share/a542676c-8629-4e92-9deb-b1b32c415e38
Similar questions (1): Same Pattern (postorder DFS)  www.leetcode.com/problems/diameter-of-binary-tree/  www.leetcode.com/problems/balanced-binary-tree/  www.leetcode.com/problems/binary-tree-maximum-path-sum/  www.leetcode.com/problems/longest-zigzag-path-in-a-binary-tree/  Same LCA Pattern  www.leetcode.com/problems/lowest-common-ancestor-of-a-binary-search-tree/  www.leetcode.com/problems/lowest-common-ancestor-of-a-binary-tree/  www.leetcode.com/problems/smallest-subtree-with-all-the-deepest-nodes/  Suggested Practice Order  www.leetcode.com/problems/diameter-of-binary-tree/  www.leetcode.com/problems/balanced-binary-tree/  www.leetcode.com/problems/lowest-common-ancestor-of-a-binary-tree/  www.leetcode.com/problems/lowest-common-ancestor-of-deepest-leaves/  www.leetcode.com/problems/binary-tree-maximum-path-sum/
Reusable template: if base case → return directly
recurse left
recurse right
combine left and right results → return upward

© 2026 Vidya Srinivasa Kesarla. All rights reserved.