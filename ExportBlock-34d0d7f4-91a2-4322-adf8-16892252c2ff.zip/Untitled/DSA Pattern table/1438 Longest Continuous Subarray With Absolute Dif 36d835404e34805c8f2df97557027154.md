# 1438. Longest Continuous Subarray With Absolute Diff Less Than or Equal to Limit

Difficulty: Medium
Input Data Structure: Array
Algorithm: Heap
Optimisation : Deque
Why this is better? Optimisation details: Intuition
While heaps are commonly used to track max and min values, their frequent insertion and removal operations are inefficient (O(logn) time). Deques, or double-ended queues, offer efficient O(1) time complexity for adding and removing elements from both ends and are more suitable for this problem.
We use two deques for this problem. One deque maintains numbers in decreasing order, ensuring the largest number in the window is always at the front. If a new number exceeds those at the deque's end, we remove those elements since they can no longer be the maximum in the current window.
Similarly, the other deque will maintain the numbers in increasing order, ensuring the smallest number in the window is always at the front. If a new number is smaller than those at the deque's end, it replaces them, ensuring accuracy for the current window's minimum.
These deques hold all the potential minimum and maximum values for the current and future windows.
When expanding the window to include a new element, we add it to both deques while preserving their order. If the absolute difference between the maximum and minimum values at the front of the deques exceeds the limit, we shrink the window by moving the left pointer. Removing elements from the front of either deque maintains the correct min and max values in constant time, enabling efficient checks to ensure the window stays within the limit.
Rationale: Algorithm
1. Initialization:
    ◦ Initialize two deques, maxDeque and minDeque.
    ◦ Initialize left to 0 to represent the start of the sliding window.
    ◦ Initialize maxLength to 0 to store the length of the longest valid subarray.
2. Iterate through the array nums from left to right using a variable right:
    ◦ For each element nums[right]:
        ▪ Maintain the maxDeque in decreasing order:
            • While maxDeque is not empty and the last element in maxDeque is less than nums[right]:
                ◦ Remove the last element from maxDeque.
            • Add nums[right] to the back of maxDeque.
        ▪ Maintain the minDeque in increasing order:
            • While minDeque is not empty and the last element in minDeque is greater than nums[right]:
                ◦ Remove the last element from minDeque.
            • Add nums[right] to the back of minDeque.
        ▪ Check if the current window exceeds the limit:
            • While the absolute difference between the first elements of maxDeque and minDeque is greater than limit:
                ◦ If the first element of maxDeque is equal to nums[left]:
                    ▪ Remove the first element from maxDeque.
                ◦ If the first element of minDeque is equal to nums[left]:
                    ▪ Remove the first element from minDeque.
                ◦ Increment left by 1.
        ▪ Update maxLength:
            • Set maxLength to the maximum of maxLength and (right - left + 1).
3. Return maxLength which stores the length of the longest valid subarray.
Code: https://leetcode.com/problems/longest-continuous-subarray-with-absolute-diff-less-than-or-equal-to-limit/submissions/
Complexity: Time Complexity: O(n)
space Complexity: O(n)
Visualisation: https://claude.ai/share/b126e367-5085-4f9b-ad3d-55d2d88b8132

© 2026 Vidya Srinivasa Kesarla. All rights reserved.