# 802. Find eventual safe states

Difficulty: Medium
Input Data Structure: 2D Array
Pattern trigger(recognition) / constraints hint / : “every possible path”

To know if a node is safe, you cannot just look at its immediate neighbors. You have to trace each individual branch out to its ultimate conclusion.
 DFS uses a recursion stack that allows you to say: "Let me drill down to the absolute end of Path 1. Did it hit a terminal node? Yes. Now let me backtrack and drill down to the absolute end of Path 2." * Managing this "go deep, check the result, backtrack, and try the next branch" flow matches the call stack structure of DFS perfectly.
Signal / Paraphrase hint: “Verify if every possible path starting here eventually terminates safely."

The Signal: If a problem asks about the shortest path or minimum steps to reach something, your brain should immediately jump to BFS (Layer-by-layer traversal).
 The DFS Trigger: When a problem asks about the properties of a complete, deep path from start to finish—or requires you to explore a single path completely to see where it ends—that is the classic signature of DFS. DFS naturally explores a single path as deeply as possible until it hits a dead end (a terminal node) before backtracking
Clarifying questions: 1. Constraints & Scale (Crucial for Time/Space Complexity)
Before deciding on your exact approach, you need to know how large the graph can get.
 "What is the maximum number of nodes (n) and edges in the graph?"
 Why ask: If n \le 10^4, an O(V + E) linear time solution (like our DFS or BFS topological sort) is required. If n is tiny (e.g., \le 20), even an inefficient brute-force path exploration might pass, though a linear solution is always preferred.
 "Can the graph contain self-loops (a node pointing directly to itself) or multiple edges between the same two nodes?"
 Why ask: Example 2 shows a self-loop (⁠1 -> 1⁠), but explicitly confirming shows you are thinking about tricky base cases in cycle detection.
2. Graph Characteristics & Edge Cases
These questions show you are evaluating structural anomalies that could break unoptimized code.
 "Is it possible for the graph to be completely disconnected?"
 Why ask: This ensures your solution iterates through every node from 0 to n-1 as a potential starting point in an outer loop, rather than just kicking off a single DFS from node ⁠0⁠.
 "Are there any isolated nodes (nodes with 0 incoming and 0 outgoing edges)?"
 Why ask: An isolated node has no outgoing edges, meaning it fits the definition of a terminal node. It should automatically be considered a "safe node."
3. Output Requirements
Clarifying the output ensures you don't lose points on trivial formatting rules.
 "The problem states the output should be sorted in ascending order. If I iterate through the nodes from 0 to n-1 and collect the safe ones sequentially, will that satisfy the sorting requirement without requiring an explicit sort step at the end?"
 Why ask: It demonstrates optimization awareness. Sorting an array of size V takes O(V \log V). By checking nodes in order from 0 to n-1, you natively collect them in sorted order, keeping that step O(V).
Constraints: 
• n == graph.length
• 1 <= n <= 104
• 0 <= graph[i].length <= n
• 0 <= graph[i][j] <= n - 1
• graph[i] is sorted in a strictly increasing order.
• The graph may contain self-loops.
• The number of edges in the graph will be in the range [1, 4 * 104].
Brute force code and its trade off: https://leetcode.com/problems/find-eventual-safe-states/editorial/#approach-1-topological-sort-using-kahns-algorithm
Intuition: A node is “safe” only if every path from it eventually terminates (reaches a node with no outgoing edges) — meaning no path from it can loop forever in a cycle.

A node is unsafe if it lies on a cycle, or if it can reach some node that’s on a cycle (since that path could then loop forever).

So the problem reduces to: find all nodes that cannot reach any cycle. This requires detecting which nodes are part of, or lead into, a cycle — classic cycle detection via DFS with states (unvisited/visiting/visited), where “visiting” nodes revisited during traversal indicate a cycle.
Edge cases / base cases: Base Cases (Inside DFS)
1. ⁠if (instack[node]) return true;⁠
 Why: This is your core base case. If we encounter a node currently in our recursion stack, we have looped back on ourselves. A cycle exists.
2. ⁠if (visit[node]) return !isSafe[node];⁠
 Why: If we've already fully processed this node in a past DFS traversal, we don't need to re-run it. We just look up our previous answer: if it was safe, return ⁠false⁠ (no cycle); if it wasn't safe, return ⁠true⁠ (cycle).

Terminal Nodes (Out-degree = 0): Nodes with no outgoing edges (e.g., ⁠graph[i] = []⁠). The ⁠for (int nbr : adj[node])⁠ loop won't execute, it skips to ⁠isSafe[node] = true⁠, and correctly marks it safe.
 Self-Loops: A node pointing to itself (e.g., ⁠graph[0] = [0]⁠). On the first neighbor check, ⁠instack[0]⁠ is true, instantly flagging it as a cycle.
 Disconnected Components: A graph with multiple independent sub-graphs. The outer loop ⁠for(int i=0; i<n; i++)⁠ ensures every single node is evaluated, even if they aren't reachable from node ⁠0⁠.
Algorithm: Topological sort
Optimisation : DFS
Why this is better? Optimisation details: 
* Approach: DFS with 3-State Cycle Detection (Colors/Booleans)
* * Why choose DFS over a BFS-based Topological Sort (Kahn's Algorithm) here?
* * 1. NO GRAPH REVERSAL:
* The problem defines safety based on OUT-degrees (where nodes point to).
* Kahn's algorithm natively processes IN-degrees. To use BFS, we would have
* to build an entirely new reversed adjacency list, which wastes time and space.
* DFS traverses the original graph exactly as given.
* * 2. LOWER MEMORY FOOTPRINT:
* Instead of instantiating a new reversed graph structure, queues, and in-degree
* arrays, DFS only requires a few primitive boolean arrays. This drastically
* reduces object overhead and memory allocation.
* * 3. EARLY SHORT-CIRCUIT:
* DFS can immediately stop exploring a path the moment it encounters a known
* cycle. Kahn's algorithm must always process the entire graph layer-by-layer
* via a queue, missing out on localized early-termination.
* * 4. LOGICAL ALIGNMENT:
* The definition "a node is safe if all paths from it lead to a terminal node"
* perfectly maps to a Post-Order DFS traversal. We validate all neighbors
* before marking the current node as safe.
* * Complexity:
* - Time: O(V + E) where V is vertices and E is edges. Each node/edge is visited once.
* - Space: O(V) for the tracking arrays and the recursion stack.
*/

Rationale: https://leetcode.com/problems/find-eventual-safe-states/editorial/#approach-2-depth-first-search
Code: class Solution {

public boolean dfs(int node, int[][] adj, boolean[] visit, boolean[] instack){
//if the node is already in stack we have a cycle
if(instack[node])
return true;

if(visit[node])
return false;

//mark the current node as visited and part of the recursion stack
visit[node] = true;
instack[node] =true;

for(int nbr: adj[node]){
if(dfs(nbr, adj, visit, instack))
return true;
}

//remove node from the stack
instack[node] = false;
return false;
}

public List<Integer> eventualSafeNodes(int[][] graph) {
int n = graph.length;
//create two boolean arrays visited, and instack
boolean[] visit = new boolean[n];

boolean [] instack = new boolean[n];

for(int i =0;i<n;i++){
dfs(i,graph,visit, instack);
}

List<Integer> safeNodes = new ArrayList<>();

for(int i =0;i<n;i++){
if(!instack[i]){
safeNodes.add(i);
}
}
return safeNodes;

}
}

Dry run: * EXECUTION DRY RUN TRACE:
* * Input Graph: graph = [[1, 2], [2, 3], [5], [0], [5], [], []]
* Graph Structure:
* 0 -> 1, 2
* 1 -> 2, 3
* 2 -> 5
* 3 -> 0 (Creates cycle: 0 -> 1 -> 3 -> 0)
* 4 -> 5
* 5 -> [] (Terminal node)
* 6 -> [] (Isolated terminal node)
* * Initial Arrays:
* visit   = [F, F, F, F, F, F, F]
* instack = [F, F, F, F, F, F, F]
* isSafe  = [F, F, F, F, F, F, F]
* * Trace:
* 1. i = 0: visit[0] is false -> calls dfs(0)
* - visit[0] = T, instack[0] = T
* - nbr = 1 -> calls dfs(1)
* - visit[1] = T, instack[1] = T
* - nbr = 2 -> calls dfs(2)
* - visit[2] = T, instack[2] = T
* - nbr = 5 -> calls dfs(5)
* - visit[5] = T, instack[5] = T
* - Node 5 has no neighbors. Loop finishes.
* - Backtrack 5: instack[5] = F, isSafe[5] = T. Returns false.
* - Back to dfs(2): nbr 5 returned false. Loop finishes.
* - Backtrack 2: instack[2] = F, isSafe[2] = T. Returns false.
* - Back to dfs(1): nbr 2 returned false.
* - Next nbr = 3 -> calls dfs(3)
* - visit[3] = T, instack[3] = T
* - nbr = 0 -> calls dfs(0)
* - BASE CASE HIT: instack[0] is true! Returns true (Cycle found).
* - Back to dfs(3): nbr 0 returned true -> Short-circuits and Returns true.
* - Back to dfs(1): nbr 3 returned true -> Short-circuits and Returns true.
* - Back to dfs(0): nbr 1 returned true -> Short-circuits and Returns true.
* * 2. i = 1, 2, 3: Skipped in outer loop because visit[i] is already true.
* * 3. i = 4: visit[4] is false -> calls dfs(4)
* - visit[4] = T, instack[4] = T
* - nbr = 5 -> calls dfs(5)
* - BASE CASE HIT: visit[5] is true. Evaluates !isSafe[5] -> !true -> false.
* - Returns false (Node 5 is confirmed safe).
* - Back to dfs(4): nbr 5 returned false. Loop finishes.
* - Backtrack 4: instack[4] = F, isSafe[4] = T. Returns false.
* * 4. i = 5: Skipped because visit[5] is true.
* * 5. i = 6: visit[6] is false -> calls dfs(6)
* - visit[6] = T, instack[6] = T
* - Node 6 has no neighbors. Loop finishes.
* - Backtrack 6: instack[6] = F, isSafe[6] = T. Returns false.
* * Final State of isSafe: [F, F, T, F, T, T, T]
* Collected Safe Nodes: [2, 4, 5, 6]
Complexity: Complexity Analysis
Here, n is the number of nodes and m is number of edges in the graph.
• Time complexity: O(m+n)
    ◦ Initializing the visit and inStack arrays take O(n) time each.
    ◦ The dfs function handles each node once, which takes O(n) time in total. From each node, we iterate over all the outgoing edges, which further takes O(m) time to iterate over all the edges as there are a total of m edges.
    ◦ Iterating over all the nodes and pushing only safe nodes into safeNodes also takes O(n) time.
• Space complexity: O(n)
    ◦ The visit and inStack arrays take O(n) space each.
    ◦ The recursion call stack used by dfs can have no more than n elements in the worst-case scenario. It would take up O(n) space in that case.
follow up questions: Can you solve this without DFS?
 Answer: Yes, using Kahn's Algorithm (BFS). You reverse the direction of all edges in the graph, calculate the in-degrees (which were originally out-degrees), and queue up nodes with an in-degree of 0 (terminal nodes). You then strip them away layer by layer.
2. What is the Time and Space Complexity?
 Time Complexity: O(V + E) where V is the number of vertices (nodes) and E is the number of edges. We visit every node and edge exactly once.
 Space Complexity: O(V) to store the tracking arrays (⁠visit⁠, ⁠instack⁠, ⁠isSafe⁠) and the recursion stack.
Visualisation: https://claude.ai/share/e6125694-1e81-46fa-9f37-d60fb341d907
Claude link: https://claude.ai/share/e6125694-1e81-46fa-9f37-d60fb341d907
Similar questions: Here are the links to the practice problems:
* Course Schedule (LeetCode 207) (Pure cycle detection)
* Course Schedule II (LeetCode 210) (Topological Sort ordering)
* Loud and Rich (LeetCode 851) (DAG traversal with state caching)
* Number of Islands (LeetCode 200) (Outer loop handling disconnected components)

Similar questions (1): Here are the links formatted precisely as requested:  * **Course Schedule (LeetCode 207):** URL www.leetcode.com/problems/course-schedule/  * **Course Schedule II (LeetCode 210):** URL www.leetcode.com/problems/course-schedule-ii/  * **Loud and Rich (LeetCode 851):** URL www.leetcode.com/problems/loud-and-rich/  * **Number of Islands (LeetCode 200):** URL www.leetcode.com/problems/number-of-islands/

© 2026 Vidya Srinivasa Kesarla. All rights reserved.