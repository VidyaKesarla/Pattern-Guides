# 42. Trapping Rain Water

Difficulty: Difficult
Input Data Structure: Array
Pattern trigger(recognition) / constraints hint / : compute how much water it can trap after raining.
Signal / Paraphrase hint: compute how much water it can trap after raining.
Constraints: Constraints:
• n == height.length
• 1 <= n <= 2 * 104
• 0 <= height[i] <= 105
Brute force code and its trade off: class Solution {
public int trap(int[] height) {
int ans = 0;
int size = height.length;
for (int i = 1; i < size - 1; i++) {
int left_max = 0, right_max = 0;
// Search the left part for max bar size
for (int j = i; j >= 0; j--) {
left_max = Math.max(left_max, height[j]);
}
// Search the right part for max bar size
for (int j = i; j < size; j++) {
right_max = Math.max(right_max, height[j]);
}
ans += Math.min(left_max, right_max) - height[i];
}
return ans;
}
}
Intuition: https://leetcode.com/problems/trapping-rain-water/editorial/?envType=company&envId=apple&favoriteSlug=apple-all#approach-4-using-2-pointers
Algorithm: Brute force, Dynamic Programming, Stack
Optimisation : Two Pointers
Code: class Solution {
public int trap(int[] height) {
//take two pointerS:
int left = 0;
int right = height.length - 1;
int maxLeft = 0;
int maxRight = 0;

//declare sum resultant
int sum = 0;

while (left < right){
if(height[left]<height[right]){
if(height[left] >= maxLeft){
maxLeft = height[left];
} else {
sum += maxLeft - height[left];
}
left++;
} else {
if(height[right] >= maxRight){
maxRight = height[right];
} else {
sum += maxRight - height[right];
}
right--;
}
}
return sum;
}
}

Complexity: Complexity Analysis
• Time complexity: O(n). Single iteration of O(n).
• Space complexity: O(1) extra space. Only constant space required for left, right, left_max and right_max.

© 2026 Vidya Srinivasa Kesarla. All rights reserved.