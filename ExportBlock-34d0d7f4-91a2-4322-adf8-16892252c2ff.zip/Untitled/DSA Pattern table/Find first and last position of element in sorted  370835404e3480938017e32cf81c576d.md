# Find first and last position of element in sorted array (1)

Difficulty: Medium
Input Data Structure: Array

© 2026 Vidya Srinivasa Kesarla. All rights reserved.