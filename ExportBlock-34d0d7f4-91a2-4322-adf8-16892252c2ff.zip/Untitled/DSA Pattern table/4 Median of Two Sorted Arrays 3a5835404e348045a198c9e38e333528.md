# 4. Median of Two Sorted Arrays

Difficulty: Difficult
Input Data Structure: Array
Pattern trigger(recognition) / constraints hint / : constaints, and also sorted arrray
Code: class Solution {
public double findMedianSortedArrays(int[] nums1, int[] nums2) {
if (nums1.length > nums2.length) {
return findMedianSortedArrays(nums2, nums1);
}

int m = nums1.length, n = nums2.length;
int left = 0, right = m;

while (left <= right) {
int partitionA = (left + right) / 2;
int partitionB = (m + n + 1) / 2 - partitionA;

int maxLeftA = (partitionA == 0)
? Integer.MIN_VALUE
: nums1[partitionA - 1];
int minRightA = (partitionA == m)
? Integer.MAX_VALUE
: nums1[partitionA];
int maxLeftB = (partitionB == 0)
? Integer.MIN_VALUE
: nums2[partitionB - 1];
int minRightB = (partitionB == n)
? Integer.MAX_VALUE
: nums2[partitionB];

if (maxLeftA <= minRightB && maxLeftB <= minRightA) {
if ((m + n) % 2 == 0) {
return (
(Math.max(maxLeftA, maxLeftB) +
Math.min(minRightA, minRightB)) /
2.0
);
} else {
return Math.max(maxLeftA, maxLeftB);
}
} else if (maxLeftA > minRightB) {
right = partitionA - 1;
} else {
left = partitionA + 1;
}
}
return 0.0;
}
}
Complexity: Let m be the size of array nums1 and n be the size of array nums2.
• Time complexity: O(log(min(m,n)))
    ◦ We perform a binary search over the smaller array of size min(m,n).
• Space complexity: O(1)
    ◦ The algorithm only requires a constant amount of additional space to store and update a few parameters during the binary search.

#

© 2026 Vidya Srinivasa Kesarla. All rights reserved.