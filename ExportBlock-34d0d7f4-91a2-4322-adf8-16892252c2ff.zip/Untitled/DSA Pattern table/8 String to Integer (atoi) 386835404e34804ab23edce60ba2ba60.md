# 8. String to Integer (atoi)

Difficulty: Medium
Input Data Structure: String
Clarifying questions: Here are good clarifying questions to ask before coding this:
Input format
• Can the string be empty? What should I return then? (0)
• Can it contain only whitespace, or only a sign with no digits? (Return 0)
• What counts as whitespace — just spaces, or also tabs/newlines? (Usually just ' ' per LeetCode spec)
• Is the input guaranteed to be ASCII, or could it have unicode/multi-byte characters?
Sign handling
• If there are multiple signs (e.g. "--1", "+-2"), should I stop and return 0, or is that undefined? (Typically: stop parsing, no digits read → 0)
• Is whitespace allowed between the sign and the digits (e.g. "- 42")? (No — only leading whitespace before the sign)
Digit parsing
• Should I stop at the first non-digit character, even if more digits follow later (e.g. "4193 with words" → 4193, "words and 987" → 0)?
• Are decimal points, commas, or scientific notation ("3.14", "1e10") considered valid, or do they just terminate parsing at the non-digit? (They terminate parsing — only 0-9 are digits)
Overflow / range
• Confirm the range is exactly [-2^31, 2^31 - 1] (i.e., [-2147483648, 2147483647]).
• Should overflow be detected by clamping during parsing (to avoid actual integer overflow in languages like C++/Java), or is it fine to parse as a big integer/string and clamp at the end (easier in Python)?
Output
• Return type: should it strictly be a 32-bit int type, or just a numeric value within that range (matters more in typed languages)?
• Any expectation around throwing exceptions for malformed input, or is “always return a valid int per the rules” sufficient? (Latter — no exceptions, just follow the algorithm)
Once these are confirmed, I’m happy to implement it (and can also write a quick test set covering edge cases like " -42", "4193 with words", "91283472332", "+-12", ""). Want me to go ahead and write the code?
Constraints: Constraints:
• 0 <= s.length <= 200
• s consists of English letters (lower-case and upper-case), digits (0-9), ' ', '+', '-', and '.'.
Intuition: https://leetcode.com/problems/string-to-integer-atoi/editorial/#approach-1-follow-the-rules
Optimisation : Follow the rules
Code: class Solution {
public int myAtoi(String input) {
int sign = 1;
int index = 0;
int result = 0;
int n = input.length();

while(index < n && input.charAt(index) == ' ') {
index++;
}

if (index < n && input.charAt(index) == '+') {
sign = 1;
index++;
} else if(index < n && input.charAt(index) == '-'){
sign = -1;
index++;
}

while(index < n && Character.isDigit(input.charAt(index))){
int digit = input.charAt(index) - '0';

if(result > Integer.MAX_VALUE / 10 || (result == Integer.MAX_VALUE / 10 && digit > Integer.MAX_VALUE % 10)){
return sign == 1 ? Integer.MAX_VALUE : Integer.MIN_VALUE;
}

result = result * 10 + digit;
index++;
}

return sign*result;
}
}
Dry run: /**
* Dry Run Trace: input = " -42"
* * 1. Initial Setup:
* sign = 1, index = 0, result = 0, n = 4
* * 2. Skip Whitespace:
* index 0 is ' ', index increments to 1.
* * 3. Handle Sign:
* input[1] is '-', sign becomes -1, index increments to 2.
* * 4. Process Digits:
* - Iteration 1: char '4' (digit 4)
* Check overflow: (0 > MAX/10) is false.
* result = 0 * 10 + 4 = 4. index = 3.
* - Iteration 2: char '2' (digit 2)
* Check overflow: (4 > MAX/10) is false.
* result = 4 * 10 + 2 = 42. index = 4.
* * 5. Termination:
* index (4) == n, loop ends.
* Return sign * result = -1 * 42 = -42.
*/

Complexity: Complexity Analysis
If N is the number of characters in the input string.
• Time complexity: O(N)
We visit each character in the input at most once and for each character we spend a constant amount of time.
• Space complexity: O(1)
We have used only constant space to store the sign and the result.
Visualisation: https://claude.ai/share/86017b47-cd6b-4bad-97f6-b01d1bdce02b
Claude link: https://claude.ai/share/86017b47-cd6b-4bad-97f6-b01d1bdce02b

© 2026 Vidya Srinivasa Kesarla. All rights reserved.