# 951. Flip Equivalent Binary Trees

Difficulty: Medium
Input Data Structure: Array, TreeNode
Pattern trigger(recognition) / constraints hint / :  “Tree traversal” “choose any node, and swap the left and right child subtrees”
Signal / Paraphrase hint: 
“Binary tree” is the biggest one. Trees are recursive structures — every node is a smaller tree. Whenever the data structure is recursive, the solution almost always is too.

“Choose any node” — this means the flip operation applies at any level, not just the root. That immediately suggests you need to visit every node, which on a tree means recursion.

“Subtrees” — the word itself. The problem literally says “swap the left and right child subtrees.” A subtree is just… a tree. So the problem is defined in terms of itself.

“Make X equal to Y after some number of flip operations” — “some number” means the operation repeats at potentially every node independently. That’s a recursive pattern: solve for the root, then trust the same logic works for children.

The Mental Model

When you see a binary tree problem, ask:

“Can I define the answer for a node purely in terms of the answers for its children?”

Here the answer is yes:

Two trees are flip equivalent at node N if their values match and their subtrees are flip equivalent (either swapped or not).

That self-referential definition is recursion. The base case writes itself — null nodes are trivially equal.

Rule of thumb: If the problem says tree, subtree, or any node — think recursion first.
Clarifying questions: About the input:

•	Can either tree be null / empty?
•	Can node values be negative or duplicate?
•	How large can the trees get? (hints at whether O(n²) is acceptable)

About the problem:

•	Is the tree guaranteed to be binary, or can nodes have more than 2 children?


 INPUT:
*   - Can either root be null?
*   - Can node values be negative or duplicated?
*   - How large can the trees get? (O(n²) vs O(n) matters)
*   - Are the two trees guaranteed to be the same size?
*
* PROBLEM:
*   - Is it always a binary tree, or can nodes have >2 children?
*   - Are two empty trees considered flip equivalent?
*
* DESIGN:
*   - Should I optimize for space, or is recursive stack overhead fine?
Constraints: Constraints:
• The number of nodes in each tree is in the range [0, 100].
• Each tree will have unique node values in the range [0, 99].
Intuition: Since binary trees are inherently recursive structures, a recursive approach is intuitive.
For each node, we have two possible options: either we swap its left and right subtrees, or we leave them as they are. We explore both possibilities for every node, starting from the root. If any sequence of flips results in the two trees becoming equivalent, our function will return true, indicating that the trees are flip equivalent. If no valid sequence leads to equivalence, the function returns false.
Edge cases / base cases: 
• If both root1 and root2 are empty trees, they are considered flip equivalent according to the definition provided; return true.
• If only one of root1 or root2 is empty, they are not flip equivalent, as they do not satisfy the structural property of equivalence; return false.
• If root1 and root2 have different node values, the trees are not flip equivalent, since this means their corresponding nodes differ; return false.
Algorithm: Recursion
Optimisation : Recursion
Rationale: 
• If both root1 and root2 are empty trees, they are considered flip equivalent according to the definition provided; return true.
• If only one of root1 or root2 is empty, they are not flip equivalent, as they do not satisfy the structural property of equivalence; return false.
• If root1 and root2 have different node values, the trees are not flip equivalent, since this means their corresponding nodes differ; return false.
• Recursively check two scenarios for flip equivalence:
    ◦ No Swap: Check if the left subtree of root1 is flip equivalent to the left subtree of root2 and the right subtree of root1 is flip equivalent to the right subtree of root2.
    ◦ Swap: Check if the left subtree of root1 is flip equivalent to the right subtree of root2 and the right subtree of root1 is flip equivalent to the left subtree of root2.
• Return true if either the noSwap or swap conditions are satisfied, as this confirms flip equivalence for the current nodes and their subtrees.
Code: class Solution {

public boolean flipEquiv(TreeNode root1, TreeNode root2) {
// Both trees are empty
if (root1 == null && root2 == null) {
return true;
}
// Just one of the trees is empty
if (root1 == null || root2 == null) {
return false;
}
// Corresponding values differ
if (root1.val != root2.val) {
return false;
}

// Check if corresponding subtrees are flip equivalent
boolean noSwap =
flipEquiv(root1.left, root2.left) &&
flipEquiv(root1.right, root2.right);
// Check if opposite subtrees are flip equivalent
boolean swap =
flipEquiv(root1.left, root2.right) &&
flipEquiv(root1.right, root2.left);

return noSwap || swap;
}
}

Dry run: /*
* FLIP EQUIVALENT BINARY TREES — DRY RUN
*
* Example:
*   Tree 1:       Tree 2:
*       1             1
*      / \           / \
*     2   3         3   2
*
* ─────────────────────────────────────────
* flipEquiv(1, 1)
*   ├── values match: 1 == 1 ✓
*   ├── noSwap = flipEquiv(2,3) && flipEquiv(3,2)
*   │     └── flipEquiv(2,3): 2 ≠ 3 → false  (short-circuits)
*   │         noSwap = FALSE
*   │
*   └── swap = flipEquiv(2,2) && flipEquiv(3,3)
*         ├── flipEquiv(2,2)
*         │     ├── values match: 2 == 2 ✓
*         │     ├── noSwap = flipEquiv(null,null) && flipEquiv(null,null)
*         │     │             → true && true = TRUE
*         │     └── returns TRUE
*         │
*         └── flipEquiv(3,3)
*               ├── values match: 3 == 3 ✓
*               ├── noSwap = flipEquiv(null,null) && flipEquiv(null,null)
*               │             → true && true = TRUE
*               └── returns TRUE
*
*   swap = true && true = TRUE
*
* flipEquiv(1,1) = FALSE || TRUE = TRUE ✓
*
* ─────────────────────────────────────────
* KEY LOGIC:
*   At each node, try BOTH orderings of children:
*   • noSwap: left↔left, right↔right
*   • swap:   left↔right, right↔left
*   Return true if either works.
*/

Complexity: Let N be the number of nodes in the smaller tree.
• Time Complexity: O(N).
This is because the recursion stops at the leaf nodes or when a mismatch occurs. In the worst case, every node in the smaller tree will be visited.
• Space Complexity: O(N).
This is due to the recursion stack. In the worst case, the recursion goes as deep as the tree's height, which can be O(N) in the case of a skewed tree (a tree in which every internal node has only one child). For a balanced tree, the space complexity will be O(logN) because the tree's height would be logarithmic relative to the number of nodes.
follow up questions: Q: Time complexity?
*   A: O(n) average, O(n²) worst case with many duplicate values
*
*   Q: Can you do this iteratively?
*   A: Yes — BFS with a queue of node pairs instead of recursive calls
*
*   Q: What if the tree had millions of nodes?
*   A: Recursion risks stack overflow → need iterative approach
*
*   Q: Can you reduce unnecessary comparisons?
*   A: Sort children by value before comparing, skips redundant checks
Visualisation: https://claude.ai/share/c5180362-c1f3-4251-8cee-b502771c2c9c
Claude link: https://claude.ai/share/c5180362-c1f3-4251-8cee-b502771c2c9c
Similar questions (1): Got it — plain URLs, no markdown linking. Here they are:  Same Core Pattern  	•	www.leetcode.com/problems/invert-binary-tree/ 	•	www.leetcode.com/problems/same-tree/ 	•	www.leetcode.com/problems/subtree-of-another-tree/ 	•	www.leetcode.com/problems/symmetric-tree/  Same Recursion Structure  	•	www.leetcode.com/problems/maximum-depth-of-binary-tree/ 	•	www.leetcode.com/problems/balanced-binary-tree/ 	•	www.leetcode.com/problems/lowest-common-ancestor-of-a-binary-tree/  Recommended order: www.leetcode.com/problems/invert-binary-tree/ www.leetcode.com/problems/same-tree/ www.leetcode.com/problems/symmetric-tree/ www.leetcode.com/problems/subtree-of-another-tree/ www.leetcode.com/problems/flip-equivalent-binary-trees/ www.leetcode.com/problems/lowest-common-ancestor-of-a-binary-tree/

© 2026 Vidya Srinivasa Kesarla. All rights reserved.