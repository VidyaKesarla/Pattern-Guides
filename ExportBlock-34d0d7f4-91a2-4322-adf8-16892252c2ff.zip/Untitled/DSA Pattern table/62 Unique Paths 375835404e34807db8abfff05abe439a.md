# 62. Unique Paths

Difficulty: Easy
Input Data Structure: Array
Constraints: Constraints:
• 1 <= m, n <= 100
Brute force code and its trade off: f you look closely at your transition equation: d[col][row] = d[col - 1][row] + d[col][row - 1].
* d[col - 1][row] is the value from the row above.
* d[col][row - 1] is the value from the left in the current row.

This means to calculate the current row, you only ever need the current row and the row directly above it. We can optimize the Space Complexity from O(m * n) down to O(n) (or O(min(m, n))) by maintaining a single 1D array instead of a full 2D grid!

Intuition: Approach 1: Dynamic Programming
One could rewrite recursive approach into dynamic programming one.
Algorithm
• Initiate 2D array d[m][n] = number of paths. To start, put number of paths
equal to 1 for the first row and the first column.
For the simplicity, one could initiate the whole 2D array by ones.
• Iterate over all "inner" cells: d[col][row] = d[col - 1][row] + d[col][row - 1].
• Return d[m - 1][n - 1]
Algorithm: Recursion
Optimisation : Bottom up DP - Tabulation
Why this is better? Optimisation details:  Brute Force Trade-off
* The Brute Force Approach: We could solve this using pure recursion, branching down and right at every step until we hit the destination or grid boundaries.
* Trade-off:
- Time Complexity: O(2^(m + n)) due to the massive overlapping subproblems. The recursion tree calculates the paths for the same cells thousands of times.
- Why DP wins: By storing results of previously visited cells, we eliminate redundant state calculations entirely, bringing the time complexity down from exponential to polynomial time.
Rationale:  Intuition: Grid Walking & Combinations
The problem asks us to find the number of unique paths from the top-left corner (0, 0) to the bottom-right corner (m - 1, n - 1) of an m x n grid, moving only down or right.

Notice that to arrive at any cell (col, row), you must come from either:
1. The cell directly above it: (col - 1, row)
2. The cell directly to its left: (col, row - 1)

Therefore, the number of unique ways to reach the current cell is the sum of the unique ways to reach those two neighbors:
Paths(col, row) = Paths(col - 1, row) + Paths(col, row - 1)
Code: public int uniquePaths(int m, int n) {
int[][] d = new int[m][n];

for (int[] arr : d) {
Arrays.fill(arr, 1);
}
for (int col = 1; col < m; ++col) {
for (int row = 1; row < n; ++row) {
d[col][row] = d[col - 1][row] + d[col][row - 1];
}
}
return d[m - 1][n - 1];
}

Dry run: Dry Run (Using provided Bottom-Up Code)
Let's trace your code with m = 3 and n = 3.

1. Initialization:
A 2D array d of size 3x3 is created and filled entirely with 1s.
[1, 1, 1]
[1, 1, 1]
[1, 1, 1]
(Note: The outer borders/first rows and columns naturally only have 1 unique path—straight right or straight down, so filling them with 1 is a clever shortcut!)

2. Nested Loops (Processing Inner Cells):
- col = 1, row = 1:
d[1][1] = d[0][1] + d[1][0] -> 1 + 1 = 2
- col = 1, row = 2:
d[1][2] = d[0][2] + d[1][1] -> 1 + 2 = 3
- col = 2, row = 1:
d[2][1] = d[1][1] + d[2][0] -> 2 + 1 = 3
- col = 2, row = 2:
d[2][2] = d[1][2] + d[2][1] -> 3 + 3 = 6

3. Return:d[2][2] which is 6. Correct!
Complexity: Rationale & Optimization Details
Your code uses a Bottom-Up (Tabulation) approach.
The rationale is to solve small subproblems first (base cases where border paths = 1) and iteratively build up to the global solution (d[m-1][n-1]).

#### Further Optimization (Space Compression):
If you look closely at your transition equation: d[col][row] = d[col - 1][row] + d[col][row - 1].
* d[col - 1][row] is the value from the row above.
* d[col][row - 1] is the value from the left in the current row.

© 2026 Vidya Srinivasa Kesarla. All rights reserved.