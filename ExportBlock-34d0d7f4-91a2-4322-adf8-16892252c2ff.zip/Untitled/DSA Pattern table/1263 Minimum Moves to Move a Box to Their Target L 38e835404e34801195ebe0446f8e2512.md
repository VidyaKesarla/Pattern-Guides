# 1263. Minimum Moves to Move a Box to Their Target Location

Difficulty: Difficult
Input Data Structure: 2D Array
Pattern trigger(recognition) / constraints hint / : 
2. Paraphrasing the Trigger
When you read a problem, rephrase it mentally:
 Instead of: "Return the minimum number of pushes..."
 Think: "Can I explore this move-by-move, layer-by-layer, so that the first time I reach the destination, I am guaranteed to have taken the shortest path?"
Signal / Paraphrase hint: 1. The "Signal" Checklist
 Optimization Requirement: The problem asks for the "minimum," "shortest," "fewest," or "quickest" result.
 Uniform Cost: Every edge (step or push) has the same "weight" or cost (e.g., 1 push = 1 unit). If the costs were different, you would need Dijkstra.
 State Exploration: The problem involves moving through a space where your current position (or configuration) determines your future possibilities.
 Layered Progress: You can only reach a goal by passing through intermediate states.
Clarifying questions: 1. Clarifying Questions
 Can the player start on the target? (Usually, no).
 Does the box have to be pushed into the target, or can it be moved through it? (Usually, it must end there).
 Are there multiple boxes? (The prompt specifies one).
Constraints: Constraints:
• m == grid.length
• n == grid[i].length
• 1 <= m, n <= 20
• grid contains only characters '.', '#', 'S', 'T', or 'B'.
• There is only one character 'S', 'B', and 'T' in the grid.
Intuition: The intuition for this problem comes down to recognizing that you are solving for two different types of movement happening at two different speeds.
If you try to treat "moving the player" and "pushing the box" as the same action, you will get lost in the complexity. Here is the mental framework to build the right intuition:
### 1. The "Two-Layer" Movement Intuition
Think of this like a Video Game Layering System:
* The Bottom Layer (The Player's "Free" Movement):
The player is extremely fast. They can move anywhere on the board (up, down, left, right) as long as they don't hit a wall or the box. Because the player's movement cost doesn't matter (we only care about the minimum number of pushes), we can treat the player's movement as a "shortcut."
* Intuition: "Does the player have a path to the required push-spot?" If yes, it costs 0 pushes. It doesn't matter if it takes them 1 step or 50 steps to get there.
* The Top Layer (The Box's "Costly" Movement):
The box is slow and heavy. It only moves when the player pushes it. The box can only move to an adjacent square, and every move costs exactly 1 push.
* Intuition: This is the only movement we are actually counting. We want the shortest sequence of these specific, costly "box moves."
### 2. Why the "4D State" is mandatory
In a standard BFS, a state is just (x, y). But here, (x, y) of the box is insufficient.
* If the box is at (2, 2), but the player is trapped on the other side of a wall, you cannot push the box.
* If the box is at (2, 2) and the player is standing right next to it, you can push the box.
Because the box's future depends entirely on the player's current location, the player's location is "part of the DNA" of the current state. That is why your state must be (boxR, boxC, playerR, playerC).
### 3. The "Key and Lock" Analogy
Imagine the box is a Lock and the player is the Key:
* To move the box (the Lock), the player (the Key) must be in a specific orientation (the needPr, needPc position).
* The Main BFS is searching for the shortest sequence of "Lock Movements."
* The Sub-BFS is the "Key" checking: "Can I reach the position needed to turn this lock?"
### 4. Summary of the "Push" Decision Tree
When you are looking at the grid, your brain should be asking this specific sequence of questions:
1. Can I even reach the other side of this box? (If no, this path is a dead end).
2. If I CAN reach it, what happens if I push it? (This creates a new "State" in the 4D space).
3. Have I been in this exact configuration (Box + Player) before? (If yes, discard it to avoid infinite loops).
4. Is the box at the target? (If yes, you are done; return the pushes count).
### The "Aha!" Moment
The reason this is a BFS problem and not something else is that the "Cost" of moving the box is uniform (always 1). Whenever you have a problem where you want the "minimum of something," and each "step" has a cost of 1, BFS is your best friend. The fact that the player has to move around doesn't change the fact that the Box is the only thing we are tracking for the "minimum" count.
Does this help distinguish between the "costly" movement (pushes) and the "free" movement (player walking), or is there still a part of the logic that feels "hidden"?
Edge cases / base cases: Edge & Base Cases
 Target unreachable: Box is trapped by walls.
 Player unreachable: Player is blocked from getting behind the box.
 Already there: Box is already at 'T' (result = 0).
 Impossible moves: Grid boundaries or walls prevent the player from reaching the necessary side of the box.
Algorithm: BFS
Optimisation : BFS
Code: class Solution {
public int minPushBox(char[][] grid) {
int m = grid.length;
int n = grid[0].length;
int [] box = new int[2];
int [] player = new int[2];
int [] target = new int[2];

for(int i=0;i<m;i++){
for(int j=0;j<n;j++){
if(grid[i][j] == 'B')
box = new int[] {i,j};
if(grid[i][j] == 'S')
player = new int[] {i,j};
if(grid[i][j] == 'T')
target = new int[] {i,j};
}
}

int[][] dirs = {{0,1},{0,-1},{1,0},{-1,0}};

boolean[][][][] visited = new boolean[m][n][m][n];

//set up BFS
Queue <int[]> queue = new LinkedList<>();
queue.offer(new int[]{box[0], box[1], player[0], player[1]});
visited[box[0]][box[1]][player[0]][player[1]] = true;
int pushes = 0;

while(!queue.isEmpty()){
int size = queue.size();
while(size-- > 0){
int[] cur = queue.poll();
int br = cur[0];
int bc = cur[1];
int pr = cur[2];
int pc = cur[3];

if(br == target[0] && bc == target[1]){
return pushes;
}

//try to push the box in all four directions:
for(int[] d: dirs){
//new box position after the push
int nbrR = br + d[0];
int nbrC = bc + d[1];
//player position he must be on the opposite side to push
int needPr = br - d[0];
int needPc = bc - d[1];

//new box position must be in bounds and not a wall
if(!inBounds(nbrR, nbrC, m, n) || grid[nbrR][nbrC] == '#')
continue;
//new player position must be in bounds and not a wall
if(!inBounds(needPr, needPc, m, n) || grid[needPr][needPc] == '#')
continue;

if (canReach(grid, pr, pc, needPr, needPc, br, bc, m, n)){
if(!visited[nbrR][nbrC][br][bc]){
visited[nbrR][nbrC][br][bc] = true;
queue.offer(new int[] { nbrR, nbrC, br, bc});
}
}
}
}
pushes++;
}
return -1;
}

private boolean canReach(char[][] grid, int sr, int sc, int tr, int tc, int br, int bc, int m, int n){
if(sr == tr && sc == tc)
return true;

boolean[][] seen = new boolean[m][n];

seen[sr][sc] = true;

Queue<int[]> q = new LinkedList<>();
q.offer(new int[]{sr, sc});

int[][] dirs = {{0,1},{0,-1},{1,0},{-1,0}};

while(!q.isEmpty()){
int[] cur = q.poll();
for(int[] d: dirs){
int nr = cur[0] + d[0];
int nc = cur[1] + d[1];
if(!inBounds(nr, nc, m, n) || seen[nr][nc] || grid[nr][nc] == '#' || (nr == br && nc == bc))
continue;
seen[nr][nc] = true;
if(nr == tr && nc == tc)
return true;
q.offer(new int[]{nr, nc});
}
}
return false;
}

private boolean inBounds(int r, int c, int m, int n){
return r >= 0 && r < m && c >= 0 && c < n;
}

}
Dry run: To dry run this effectively, let's take a tiny scenario:
Grid (3x3):S B . . # . . . T 
* S = (0,0), B = (0,1), T = (2,2)
* Goal: Move B to (2,2)
### Step 1: Initial State
* Queue: [(0, 1, 0, 0)] (Box: 0,1; Player: 0,0)
* Pushes: 0
### Step 2: Main BFS (1st iteration)
* Pop (0, 1, 0, 0).
* Try moving Box:
* Right: nbr=(0, 2), need=(0, 0). Player is already at (0,0). canReach is true.
* New State: Box=(0,2), Player=(0,1). Push count becomes 1.
* Down: nbr=(1, 1). Wall (#). Skip.
* Queue: [(0, 2, 0, 1)]
### Step 3: Main BFS (2nd iteration)
* Pop (0, 2, 0, 1).
* Try moving Box:
* Down: nbr=(1, 2), need=(0, 2). Player is at (0,1).
* Can the player reach (0,2) from (0,1)?
* canReach starts a sub-BFS.
* It sees that from (0,1), the player can move to (0,2).
* Returns true.
* New State: Box=(1,2), Player=(0,2). Push count becomes 2.
* Queue: [(1, 2, 0, 2)]
### Step 4: Main BFS (3rd iteration)
* Pop (1, 2, 0, 2).
* Try moving Box:
* Down: nbr=(2, 2), need=(1, 2). Player is at (0,2).
* Can the player reach (1,2) from (0,2)?
* canReach starts sub-BFS. Path: (0,2) -> (1,2).
* Returns true.
* New State: Box=(2,2), Player=(1,2).
* Queue: [(2, 2, 1, 2)]
### Step 5: Termination
* Pop (2, 2, 1, 2).
* Check: br == target[0] (2==2) and bc == target[1] (2==2).
* Return: 3
### Why this dry run proves the BFS Pattern:
1. State Uniqueness: Even though the player moved many times during canReach, the main queue only cares about states where a push happened.
2. Layer-by-Layer: If there were a way to get the box to the target in 2 pushes, the BFS would have found it before processing any states requiring 3 pushes.
3. The "Jump": Notice the jump from (0, 1) (player) to (0, 2) (player) inside the canReach logic. The player "teleports" to the other side of the box in one unit of time, but the Push Count only increases when the Box moves.
Does seeing the transition from the "Box movement" (Main BFS) vs the "Player movement" (Sub-BFS) help anchor why we need two distinct BFS structures?
Complexity: TC: O((M \times N)^2). We have M \times N positions for the box and M \times N positions for the player.
 SC: O((M \times N)^2) to store the ⁠visited⁠ states.
follow up questions: Code Review Observations
1. Correct State Logic: Using ⁠visited[boxR][boxC][playerR][playerC]⁠ is exactly right. It prevents re-processing the same configuration.
2. State Transition: Your ⁠nbrR = br + d[0]⁠ logic correctly handles the "push" mechanics (moving the box while the player effectively ends up where the box used to be).
3. Boundary/Wall Handling: The ⁠canReach⁠ logic properly treats the box as a temporary wall (⁠nr == br && nc == bc⁠), which is critical for correctness.
Optimization & Clean-up
If you were to refine this for a technical interview or production, consider these improvements:
 Memory Footprint: The ⁠visited⁠ array ⁠[m][n][m][n]⁠ is quite large. While it is O(N^4), you can save space by using a single ⁠int⁠ or a custom ⁠State⁠ object with a hash code to store visited states in a ⁠HashSet⁠ if memory limits are tight.
 The "Player" State in ⁠visited⁠: In your queue, you store ⁠{nbrR, nbrC, br, bc}⁠. Notice that after a push, the player is always at the old box position (⁠br, bc⁠). This is correct! You don't need to track every possible player location in ⁠visited⁠—only the location where the player lands after a successful push. This keeps your ⁠visited⁠ logic efficient.
 Early Exit: Your ⁠canReach⁠ function is called every time you try a direction. Since ⁠canReach⁠ is itself a BFS (O(MN)), your total complexity is O((MN)^2). This is optimal for this problem
Files & media: 1263%20Minimum%20Moves%20to%20Move%20a%20Box%20to%20Their%20Target%20L/IMG_2164.png

© 2026 Vidya Srinivasa Kesarla. All rights reserved.