# 540. Single element in sorted array

Difficulty: Medium
Input Data Structure: Array
Pattern trigger(recognition) / constraints hint / : Expected tc: O(logn)
Data or answer space is sorted or monotonoic linear search scan feels slow.
Shrink search space each step in O(logn)
single element that appears only once.

Signal / Paraphrase hint: Cuts search space in half using Monotonic structure.
sorted array
search on answer space
Constraints: Constraints:
• 1 <= nums.length <= 105
• 0 <= nums[i] <= 105
Brute force code and its trade off: class Solution {
public int singleNonDuplicate(int[] nums) {
for (int i = 0; i < nums.length - 1; i+=2) {
if (nums[i] != nums[i + 1]) {
return nums[i];
}
}
return nums[nums.length - 1];
}
}

O(n) tc and space- O(1)
Intuition: https://leetcode.com/problems/single-element-in-a-sorted-array/editorial/#approach-2-binary-search
Algorithm: Brute force
Optimisation : Binary search
Rationale: It makes sense to try and convert the linear search into a binary search. In order to use binary search, we need to be able to look at the middle item and then determine whether the solution is the middle item, or to the left, or to the right. The key observation to make is that the starting array must always have an odd number of elements (be odd-lengthed), because it has one element appearing once, and all the other elements appearing twice.
Here is what happens when we remove a pair from the center. We are left with a left subarray and a right subarray.
Like the original array, the subarray containing the single element must be odd-lengthed. The subarray not containing it must be even-lengthed. So by taking a pair out of the middle and then calculating which side is now odd-lengthed, we have the information needed for binary search.
Code: class Solution {
public int singleNonDuplicate(int[] nums) {
int low = 0;
int high = nums.length - 1;
while(low<high){
int mid = low + (high - low) / 2;
boolean halvesAreEven = (high - mid) % 2 == 0;

if(nums[mid+1] == nums[mid]){
if (halvesAreEven){
//Case 1: Mid’s partner is to the right, and the halves were originally even.
low = mid + 2;
} else {
//Case 2: Mid’s partner is to the right, and the halves were originally odd.
high = mid - 1;
}
} else if (nums[mid] == nums[mid -1]){
if (halvesAreEven){
//Case 3: Mid’s partner is to the left, and the halves were originally even.
high = mid - 2;
} else {
//Case 4: Mid’s partner is to the left, and the halves were originally odd.
low = mid + 1;
}
} else {
return nums[mid];
}
}
return nums[low];
}
}
Complexity: Complexity Analysis
• Time complexity : O(logn). On each iteration of the loop, we're halving the number of items we still need to search.
• Space complexity : O(1). We are only using constant space to keep track of where we are in the search.
follow up questions: How would the algorithm change if the array were unsorted?
	•	What if up to two elements could be unpaired — could you still binary search, or does it become O(n)?
	•	Can you solve this without parity logic, using XOR on mid and comparing nums[mid] to nums[mid ^ 1]? (This is the classic slicker version — worth comparing side by side.)
	•	How would you modify it to find the single element when every other element appears three times instead of two?
	•	What’s the time/space complexity here, and how does it compare to the XOR-based or linear-scan approaches?

Why high - mid parity, not mid % 2? The pairing pattern shifts as the search range shrinks — low isn’t always 0. What matters is parity relative to the current segment, not absolute index parity. high - mid measures the length of the right half from mid’s perspective within this shrinking window, so it stays meaningful no matter where low/high currently sit.
Why high - mid, not mid - low? Would the left half work too? Yes, symmetric logic would work using mid - low instead — you’d just flip which case numbers correspond to which. The implementation picked the right half arbitrarily; both halves carry the same parity information since (mid - low) + (high - mid) = high - low, and high - low parity is itself informative (odd-length total range = even count of remaining elements).
Why low < high, not low <= high? Why check both neighbors?
• low < high: once low == high, there’s exactly one element left, which must be the answer — no comparison needed, so the loop stops there.
• Checking both neighbors avoids out-of-bounds errors and handles edge cases where mid sits at the boundary of the range cleanly (mid could equal low or high in odd-sized windows).
What if the input isn’t well-formed (not “every element twice except one”)? The algorithm assumes the invariant strictly. With malformed input it will still terminate and return some index, but that index is meaningless — no validation is performed. Garbage in, garbage out.


Unsorted array? Binary search relies entirely on sortedness to know which half is “broken.” Unsorted → no way to discard half the array → falls back to O(n) (e.g., XOR-fold the whole array, since duplicates cancel out: a ^ a = 0).
Up to two unpaired elements? Then there isn’t one clean alignment boundary — parity can break in two places, so you can’t always tell from one mid check which side the target anomaly is on. This is the classic “two missing/single numbers” problem, and it generally needs O(n) with XOR-and-bit-trick separation, not binary search.
XOR trick (nums[mid] == nums[mid ^ 1])? Elegant alternative: mid ^ 1 flips the last bit — giving mid+1 if mid is even, mid-1 if mid is odd. So it automatically looks at the “expected pair partner” without separate even/odd branches:
int low = 0, high = nums.length - 1;
while (low < high) {
    int mid = low + (high - low) / 2;
    if (nums[mid] == nums[mid ^ 1]) low = mid + 1;
    else high = mid;
}
return nums[low];
Same O(log n), but no halvesAreEven bookkeeping — the XOR absorbs the parity logic. Worth comparing in the visualizer side by side.
Every other element appears three times, find the single one? Binary search no longer directly applies (no simple left/right pairing check), but bit manipulation generalizes: count bits across all numbers mod 3 — bits not divisible by 3 belong to the single element. That’s O(n) time, O(1) space, unrelated to the binary-search approach here.
Complexity comparison
• This algorithm: O(log n) time, O(1) space
• XOR-trick version: same O(log n) / O(1), just cleaner code
• Linear XOR-fold (works even unsorted): O(n) time, O(1) space — simpler but loses the log-n advantage that sortedness buys you


Want me to add the XOR version as a second mode in the visualizer for side-by-side comparison?
Visualisation: https://claude.ai/share/4e9f8f55-2781-4e65-a11f-c606788ba46f
Claude link: https://claude.ai/share/4e9f8f55-2781-4e65-a11f-c606788ba46f

© 2026 Vidya Srinivasa Kesarla. All rights reserved.