# 21. Merge two sorted lists

Difficulty: Easy
Input Data Structure: LinkedList
Constraints: Constraints:
• The number of nodes in both lists is in the range [0, 50].
• -100 <= Node.val <= 100
• Both list1 and list2 are sorted in non-decreasing order.
Brute force code and its trade off: class Solution {
public ListNode mergeTwoLists(ListNode l1, ListNode l2) {
if (l1 == null) {
return l2;
} else if (l2 == null) {
return l1;
} else if (l1.val < l2.val) {
l1.next = mergeTwoLists(l1.next, l2);
return l1;
} else {
l2.next = mergeTwoLists(l1, l2.next);
return l2;
}
}
}
Intuition: Approach 2: Iteration
Intuition
We can achieve the same idea via iteration by assuming that l1 is entirely
less than l2 and processing the elements one-by-one, inserting elements of
l2 in the necessary places in l1.
Algorithm
First, we set up a false "prehead" node that allows us to easily return the
head of the merged list later. We also maintain a prev pointer, which
points to the current node for which we are considering adjusting its next
pointer. Then, we do the following until at least one of l1 and l2 points
to null: if the value at l1 is less than or equal to the value at l2,
then we connect l1 to the previous node and increment l1. Otherwise, we
do the same, but for l2. Then, regardless of which list we connected, we
increment prev to keep it one step behind one of our list heads.
After the loop terminates, at most one of l1 and l2 is non-null.
Therefore (because the input lists were in sorted order), if either list is
non-null, it contains only elements greater than all of the
previously-merged elements. This means that we can simply connect the
non-null list to the merged list and return it.
Algorithm: Recursion
Optimisation : Iteration
Code: class Solution {
public ListNode mergeTwoLists(ListNode l1, ListNode l2) {
// maintain an unchanging reference to node ahead of the return node.
ListNode prehead = new ListNode(-1);

ListNode prev = prehead;
while (l1 != null && l2 != null) {
if (l1.val <= l2.val) {
prev.next = l1;
l1 = l1.next;
} else {
prev.next = l2;
l2 = l2.next;
}
prev = prev.next;
}

// At least one of l1 and l2 can still have nodes at this point, so connect
// the non-null list to the end of the merged list.
prev.next = l1 == null ? l2 : l1;

return prehead.next;
}
}
Dry run: https://leetcode.com/problems/merge-two-sorted-lists/editorial/#approach-2-iteration
Complexity: Complexity Analysis
• Time complexity : O(n+m)
Because exactly one of l1 and l2 is incremented on each loop
iteration, the while loop runs for a number of iterations equal to the
sum of the lengths of the two lists. All other work is constant, so the
overall complexity is linear.
• Space complexity : O(1)
The iterative approach only allocates a few pointers, so it has a
constant overall memory footprint.
Visualisation: https://leetcode.com/problems/merge-two-sorted-lists/editorial/#approach-2-iteration
Claude link: https://leetcode.com/problems/merge-two-sorted-lists/editorial/#approach-2-iteration

© 2026 Vidya Srinivasa Kesarla. All rights reserved.