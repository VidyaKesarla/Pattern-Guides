# 300. Longest Increasing Subsequence

Difficulty: Medium
Input Data Structure: Array
Constraints: Constraints:
• 1 <= nums.length <= 2500
• -104 <= nums[i] <= 104
Algorithm: DP
Optimisation : Binary search, Patience sort
Why this is better? Optimisation details: * * BRUTE FORCE APPROACH: Dynamic Programming
* -------------------------------------------------------------------------
* LOGIC AND INTUITION:
* 1. Concept: Define dp[i] as the length of the LIS ending at index 'i'.
* 2. Base Case: Every element is a subsequence of length 1 (dp[i] = 1).
* 3. Look-back: For each element 'i', scan all previous elements 'j' (0 to i-1).
* 4. Update: If nums[i] > nums[j], then dp[i] = Math.max(dp[i], dp[j] + 1).
* * WHY THIS IS SLOW (O(n^2)):
* - It uses nested loops. For every single element, we re-scan the entire
* prefix of the array.
* - If n = 10^5, n^2 = 10,000,000,000 (10 billion) operations.
* Standard competitive programming limits are ~10^8 operations per second.
* - This approach will result in a "Time Limit Exceeded" (TLE) on LeetCode.
* * CODE STRUCTURE (O(n^2)):
* for (int i = 0; i < n; i++) {
* for (int j = 0; j < i; j++) {
* if (nums[i] > nums[j]) dp[i] = Math.max(dp[i], dp[j] + 1);
* }
* }
Rationale: https://leetcode.com/problems/longest-increasing-subsequence/submissions/1942815592/
Code: https://claude.ai/share/02794b52-bbd5-41df-a6a3-930cac00ac86
Dry run: https://leetcode.com/problems/longest-increasing-subsequence/submissions/1942815592/
Complexity:  * - Space Complexity: O(n) to store the tails array. * problem within the time limit. Doll Envelopes"  * - Scalability: This is the only way to solve the "Russian  ~1.7M operations. * a log n binary search for each. For n = 10^5, this is only  and perform  * 
Visualisation: https://claude.ai/share/7237dd8f-9ea7-4a91-97a7-ff068c10df46

© 2026 Vidya Srinivasa Kesarla. All rights reserved.