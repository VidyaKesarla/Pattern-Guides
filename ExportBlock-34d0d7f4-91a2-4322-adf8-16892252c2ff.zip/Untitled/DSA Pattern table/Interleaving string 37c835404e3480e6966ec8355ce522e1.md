# Interleaving string

Difficulty: Medium
Input Data Structure: String
Pattern trigger(recognition) / constraints hint / : When a problem says:

Overlapping Subproblems,  Optimal Substructure, State transition and you must maximise/minimise or count ways: think of Dynamic Programming 
Trigger: Count number of ways / Max or min value / 
Use DP with memoisation(Top down) or tabulation(Bottom up)
Signal / Paraphrase hint: Given strings s1, s2, and s3, find whether s3 is formed by an interleaving of s1 and s2.
Clarifying questions: 1. "Can words from the dictionary be reused multiple times?" (Yes, implicitly).
2. "Are all characters lowercase English letters, or do we handle special symbols?"
3. "Is it guaranteed that the dictionary contains no empty strings?”

1. Clarifying Questions & Constraints
• Character Set: According to the problem constraints, $s_1$, $s_2$, and $s_3$ consist only of lowercase English letters. In a real interview, it is always excellent to verify if spaces, symbols, or Unicode characters are possible, as it might affect how you index an array (if building a frequency map, for example).
• Expected Complexities: * Time: $O(m \times n)$ is the expected optimal time complexity.
    ◦ Space: A standard 2D DP table takes $O(m \times n)$ space. However, a follow-up optimization can bring the space complexity down to $O(n)$ (where $n$ is the length of $s_2$) by only keeping track of the previous row.
Constraints: 
• 0 <= s1.length, s2.length <= 100
• 0 <= s3.length <= 200
• s1, s2, and s3 consist of lowercase English letters.
Brute force code and its trade off: 3. Brute Force Approach (Naive Recursion)
At each step, you compare the current character of $s_3$ with the current characters of $s_1$ and $s_2$.
Recurrence Logic
• If $s_1[i] == s_3[k]$, you can choose to move forward in $s_1$ and $s_3$.
• If $s_2[j] == s_3[k]$, you can choose to move forward in $s_2$ and $s_3$.
The Bottleneck
When $s_1$ and $s_2$ contain repeated characters, both conditions match. The recursion tree branches out at every single step, recalculating the same $(i, j)$ states multiple times.
• Time Complexity: $O(2^{m+n})$ due to the exponential growth of the decision tree.
• Space Complexity: $O(m+n)$ due to the maximum depth of the recursion call stack.


Intuition: INTUITION:
* Imagine a grid where rows represent characters of s1 and columns represent s2.
* Finding an interleaving is like finding a path from the top-left (0,0) to the
* bottom-right (m,n).
* - Moving DOWN means using a character from s1.
* - Moving RIGHT means using a character from s2.
* We can only move to a cell if the character in s3 matches the source string char.
Edge cases / base cases: EDGE CASES:
* - Length Mismatch: If s1.len + s2.len != s3.len, return false immediately.
* - Empty Strings: s1="", s2="", s3="" is true.
* - Single Source: If s1 is empty, s3 must exactly match s2.. 
Key Insights & Edge Cases
Because the expected output is a boolean, your intuition is entirely correct: you only need to find one valid path to return true. You do not need to count or track multiple valid paths.
Critical Edge Cases
• Length Mismatch: If $\text{length}(s_3) \neq \text{length}(s_1) + \text{length}(s_2)$, return false immediately.
• All Empty Strings: If $s_1 = ""$, $s_2 = ""$, and $s_3 = ""$, return true.
• One Empty Source String: If $s_1 = ""$, $s_2 = \text{"abc"}$, and $s_3 = \text{"abc"}$, it should smoothly evaluate to true.
• Alternating Order: $s_1$ does not have to be the starting string. For example, $s_1 = \text{"a"}$, $s_2 = \text{"b"}$, $s_3 = \text{"ba"}$ is valid.
• Overlapping/Ambiguous Characters: When both $s_1[i]$ and $s_2[j]$ match $s_3[k]$ (e.g., $s_1 = \text{"aab"}$, $s_2 = \text{"aac"}$, $s_3 = \text{"aaaabc"}$), a simple greedy two-pointer approach fails because it cannot foresee which choice is correct. This choice branches the logic, creating the need for Decision Making / Dynamic Programming.


Algorithm: Recursion
Optimisation : Bottom up DP - Tabulation
Code: class Solution {
public boolean isInterleave(String s1, String s2, String s3) {
int m = s1.length();
int n = s2.length();

if(m + n != s3.length()){
return false;
}

boolean[] dp = new boolean[n+1];

for(int i =0;i<= s1.length(); i++){
for(int j =0;j<= s2.length(); j++){
if(i==0 && j==0){
dp[j] = true;
} else if(i==0){
dp[j] = dp[j-1] && s2.charAt(j-1) == s3.charAt(i+j-1);
} else if(j==0){
dp[j] = dp[j] && s1.charAt(i-1) == s3.charAt(i+j-1);
} else {
dp[j] = (dp[j-1] && s2.charAt(j-1) == s3.charAt(i+j-1)) || (dp[j] && s1.charAt(i-1) == s3.charAt(i+j-1)) ;
}
}
}
return dp[s2.length()];
}
}

Dry run: DRY RUN (Optimized 1D):
* s1="ab", s2="cd", s3="acbd"
* 1. Initial: dp = [T, F, F] (Empty strings match)
* 2. i=0 (s1=""): dp[1] checks if s2https://app.notion.com/p/'c' == s3https://app.notion.com/p/'a' -> F. dp remains [T, F, F].
* 3. i=1 (s1="a"):
*    - dp[0] checks s1https://app.notion.com/p/'a' == s3https://app.notion.com/p/'a' -> T.
*    - dp[1] checks if s1 char matches OR s2 char matches s3https://app.notion.com/p/'c' -> T.
*    - Row becomes [T, T, F].
* 4. i=2 (s1="ab"):
*    - dp[2] eventually becomes T when matching s2https://app.notion.com/p/'d' == s3https://app.notion.com/p/'d'.
* Final Result: dp[2] == true.
Complexity: . Optimal Approach (Dynamic Programming)
To eliminate redundant work, you can use a 2D grid/table (dp[i][j]) or memoization.
Why It Works
Instead of tracking $i, j,$ and $k$ independently, we know that at any valid state, $k = i + j$. Thus, a state can be uniquely identified purely by the pair $(i, j)$. We compute the validity of each state exactly once.
• State Definition: dp[i][j] represents whether the first $i$ characters of $s_1$ and the first $j$ characters of $s_2$ can successfully form the first $i+j$ characters of $s_3$.
• Time Complexity: $O(m \times n)$ because there are only $(m+1) \times (n+1)$ unique states to visit.
• Space Complexity: $O(m \times n)$ for a standard 2D grid, which can be further optimized to $O(n)$ by using a single 1D array (since computing the current row only requires data from the current and previous elements of the row).
Visualisation: https://claude.ai/share/fae76c49-7a09-4ef3-8092-bb8ee5d76cd8
Claude link: https://claude.ai/chat/e2122a6a-e290-4d68-91b8-1260029115db

© 2026 Vidya Srinivasa Kesarla. All rights reserved.