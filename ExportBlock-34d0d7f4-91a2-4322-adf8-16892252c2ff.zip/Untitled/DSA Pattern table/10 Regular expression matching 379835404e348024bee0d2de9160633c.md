# 10. Regular expression matching

Difficulty: Difficult
Input Data Structure: String
Constraints: 1 ≤ s.length ≤ 20
1≤ p.length ≤ 20
Intuition: Core logic:
Does the suffix of the text starting at index i match the suffix of the pattern starting at index j?

Base case intuition:

whenever we match a regular expression:
Hardest part is dealing with the wildcard * because it can match 0, 1 or many characters.

if we start from the beginning of the strings top down you have to look ahead constantly to see if a * is coming up. 
However if we work backward from the end:
  • you already know exactly what the rest of the pattern or text looks like
  • Your absolute base case: an empty text “” perfectly matches an empty pattern “” 
  • 
  • So we set dp[text.length()][pattern.length()] as true
  • 
  • 
  • Code separates the matching logic into 2 distinct phases:
  • Character matching - first_match ⇒ do the individual characters at the current pointers match right now? Or is the pattern character . ?
  • Structural matching: How do we handle the structural rules of a pattern?
  • 
  • Multi choice intuition of * :
  • How to deal with *. When the code encounters a * 
  • 
  • 
Algorithm: DFS, Recursion
Optimisation : Bottom up DP - Tabulation, Memoisation - Top down approach
Why this is better? Optimisation details: Intuition
As the problem has an optimal substructure, it is natural to cache intermediate results. We ask the question dp(i, j): does text[i:] and pattern[j:] match? We can describe our answer in terms of answers to questions involving smaller strings.
Algorithm
We proceed with the same recursion as in https://leetcode.com/problems/regular-expression-matching/editorial/#approach-1-recursion, except because calls will only ever be made to match(text[i:], pattern[j:]), we use dp(i, j) to handle those calls instead, saving us expensive string-building operations and allowing us to cache the intermediate results.
Code: class Solution {
public boolean isMatch(String text, String pattern) {
boolean[][] dp = new boolean[text.length() + 1][pattern.length() + 1];
dp[text.length()][pattern.length()] = true;

for (int i = text.length(); i >= 0; i--) {
for (int j = pattern.length() - 1; j >= 0; j--) {
boolean first_match =
(i < text.length() &&
(pattern.charAt(j) == text.charAt(i) ||
pattern.charAt(j) == '.'));
if (j + 1 < pattern.length() && pattern.charAt(j + 1) == '*') {
dp[i][j] = dp[i][j + 2] || (first_match && dp[i + 1][j]);
} else {
dp[i][j] = first_match && dp[i + 1][j + 1];
}
}
}
return dp[0][0];
}
}
Dry run: ======================================================================
BOTTOM-UP DP GRID DRY RUN
Text: "xa" (len = 2)    |  Pattern: "xa" (len = 3)
Grid Size: [3][4]       |  Target: dp[0][0]
======================================================================

Initial State (Base Case):
- dp[2][3] = TRUE  (Empty text "" matches empty pattern "")
- All other cells initialized to FALSE.

----------------------------------------------------------------------
ROW i = 2 (Evaluating empty text "")
----------------------------------------------------------------------
* j = 2 ('a'): No star next. first_match = FALSE.
dp[2][2] = first_match && dp[3][3] -> FALSE

* j = 1 (''): Invalid state standalone (evaluated by j=0).
dp[2][1] = FALSE

* j = 0 ('x'): Lookahead pattern[1] is ''.
We check Option 1 (Skip 'x'): dp[2][2] (which is FALSE)
dp[2][0] = dp[2][2] || (first_match && dp[3][0]) -> FALSE

----------------------------------------------------------------------
ROW i = 1 (Evaluating text substring "a")
----------------------------------------------------------------------
* j = 2 ('a'): No star next.
first_match = (text[1] == pattern[2]) -> ('a' == 'a') -> TRUE
dp[1][2] = first_match && dp[2][3] -> TRUE && TRUE -> TRUE

* j = 1 (''): No star next. first_match = ('a' == '') -> FALSE.
dp[1][1] = FALSE

* j = 0 ('x'): Lookahead pattern[1] is ''.
first_match = (text[1] == pattern[0]) -> ('a' == 'x') -> FALSE
Option 1 (Skip 'x'): dp[1][2] (which is TRUE)
dp[1][0] = dp[1][2] || (FALSE) -> TRUE || FALSE -> TRUE

----------------------------------------------------------------------
ROW i = 0 (Evaluating full text "xa")
----------------------------------------------------------------------
* j = 2 ('a'): No star next.
first_match = (text[0] == pattern[2]) -> ('x' == 'a') -> FALSE
dp[0][2] = FALSE

* j = 1 (''): No star next. first_match = ('x' == '') -> FALSE.
dp[0][1] = FALSE

* j = 0 ('x'): Lookahead pattern[1] is ''.
first_match = (text[0] == pattern[0]) -> ('x' == 'x') -> TRUE
Option 1 (Skip 'x'): dp[0][2] (which is FALSE)
Option 2 (Consume 'x'): first_match && dp[1][0] -> TRUE && TRUE -> TRUE
dp[0][0] = Option 1 || Option 2 -> FALSE || TRUE -> TRUE

----------------------------------------------------------------------
FINAL VISUALIZED GRID State:
----------------------------------------------------------------------
j = 0    1    2    3
x    * a   ""
i = 0  x [ T ][ F ][ F ][ F ]
i = 1  a [ T ][ F ][ T ][ F ]
i = 2 "" [ F ][ F ][ F ][ T ]

Target dp[0][0] is TRUE.
======================================================================

Complexity: Complexity Analysis
• Time Complexity: Let T,P be the lengths of the text and the pattern respectively. The work for every call to dp(i, j) for i=0,...,T; j=0,...,P is done once, and it is O(1)work. Hence, the time complexity is O(TP).
• Space Complexity: The only memory we use is the O(TP) boolean entries in our cache. Hence, the space complexity is O(TP).
Claude link: https://g.co/gemini/share/eb9b585e0a8b

© 2026 Vidya Srinivasa Kesarla. All rights reserved.