# 136. Single Number

Difficulty: Easy
Input Data Structure: Array
Constraints: Constraints:
• 1 <= nums.length <= 3 * 104
• -3 * 104 <= nums[i] <= 3 * 104
• Each element in the array appears twice except for one element which appears only once.
Intuition:  * Intuition:
* Uses the XOR (^) bitwise operator properties:
* 1. x ^ 0 = x
* 2. x ^ x = 0
* 3. Associative & Commutative (Order of operations does not matter)
Algorithm: Hashtable, Linear search
Optimisation : Bit manipulation
Code: class Solution {
public int singleNumber(int[] nums) {


/**
* XOR Properties:
* 1. Identity: Any number XORed with zero is the number itself: a ^ 0 = a
* 2. Self-Inverse: Any number XORed with itself is zero: a ^ a = 0
* 3. Commutative and Associative: The order of operations does not matter

*/
int xorr = 0;

// XOR all elements — duplicates cancel each other out
for (int num : nums) {
xorr ^= num;
}

return xorr;
}
}

Dry run: * * Dry Run for nums = [4, 1, 2, 1, 2]:
* Initial: xorr = 0
* - num = 4: xorr = 0 ^ 4 = 4
* - num = 1: xorr = 4 ^ 1 = 5
* - num = 2: xorr = 5 ^ 2 = 7
* - num = 1: xorr = 7 ^ 1 = 6  (1s cancel out)
* - num = 2: xorr = 6 ^ 2 = 4  (2s cancel out)
* * Conceptually: 4 ^ (1 ^ 1) ^ (2 ^ 2) -> 4 ^ 0 ^ 0 -> 4
Complexity: * * Time Complexity: O(n)
* Space Complexity: O(1)

- Intuition:
    - Uses the XOR (^) bitwise operator properties:
    - 
        1. x ^ 0 = x
    - 
        1. x ^ x = 0
    - 
        1. Associative & Commutative (Order of operations does not matter)
- Intuition:
    - Uses the XOR (^) bitwise operator properties:
    - 
        1. x ^ 0 = x
    - 
        1. x ^ x = 0
    - 
        1. Associative & Commutative (Order of operations does not matter)

© 2026 Vidya Srinivasa Kesarla. All rights reserved.