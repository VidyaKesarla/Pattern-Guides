# 721. Accounts Merge

Difficulty: Medium
Input Data Structure: ArrayList of List of Strings
Constraints: Constraints:
• 1 <= accounts.length <= 1000
• 2 <= accounts[i].length <= 10
• 1 <= accounts[i][j].length <= 30
• accounts[i][0] consists of English letters.
• accounts[i][j] (for j > 0) is a valid email.
Intuition: INTUITION:
* Think of emails as nodes in a graph. If two emails appear in the same account,
* they belong to the same person → draw an edge between them.
* After building this graph, each CONNECTED COMPONENT = one real person.
* We just need to find all connected components using DFS.
*
* WHY GRAPH?
* The same email can appear in multiple accounts, acting as a BRIDGE.
* Example: mailto:johnsmith@mail.com appears in Account 0 and Account 1
* → those two accounts belong to the same person
* → DFS will naturally collect all connected emails together
*
* APPROACH:
* Step 1 → Build adjacency list (email ↔ email if they share an account)
* Step 2 → DFS over every unvisited first-email to collect components
* Step 3 → Sort emails within each component, prepend name, add to result
Algorithm: DFS
Optimisation : DFS
Code: class Solution {
Map<String, List<String>> adjacent = new HashMap<String, List<String>>();
HashSet<String> visited = new HashSet<>();

private void DFS(List<String> mergedAccount, String email){
visited.add(email);
//also add this mail to the merged account that contains the current component's emails
mergedAccount.add(email);

if(!adjacent.containsKey(email))
return;

//do dfs for its neighbors as well
for(String neighbor: adjacent.get(email)){
if(!visited.contains(neighbor)){
DFS(mergedAccount, neighbor);
}
}
}


public List<List<String>> accountsMerge(List<List<String>> accountList) {
//1 rule i am seeing is that even if 2 accounts they have same name: they may belong to different people.
//2nd rule: after merging the accounts, the emails are in sorted order.
//3rd rule: the accounts themselves can be returned in any order

//first get the length of the accounts list
int accountListSize = accountList.size();


for(List<String> account: accountList){
int accountSize = account.size();

//build an adjacency list or a graph
//add edges between first email to all other emails in the account
//get the first email
//we are connecting first email to all the other emails for that account thus creating a connected network
String accountFirstEmail = account.get(1);
//every oteher mail should alwyas be connected to first email
for(int j=2;j<accountSize;j++){
//get other emails
String accountEmail = account.get(j);
if(!adjacent.containsKey(accountFirstEmail)){
adjacent.put(accountFirstEmail, new ArrayList<String>());
}
adjacent.get(accountFirstEmail).add(accountEmail);
if(!adjacent.containsKey(accountEmail)){
adjacent.put(accountEmail, new ArrayList<String>());
}
adjacent.get(accountEmail).add(accountFirstEmail);

}
}

//traverse all the other accounts to store components
//merged accounts will also be of type the same as input because we need to create a list of lists.
List<List<String>> mergedAccounts = new ArrayList<>();

for(List<String>account: accountList){
String accountName = account.get(0);
String accountFirstEmail = account.get(1);

//if email is visited then its part of different component
//hence perform DFS only if email is not visited yet
if(!visited.contains(accountFirstEmail)){
List<String> mergedAccount = new ArrayList<>();
mergedAccount.add(accountName);
DFS(mergedAccount, accountFirstEmail);

Collections.sort(mergedAccount.subList(1, mergedAccount.size()));

mergedAccounts.add(mergedAccount);
}

}

return mergedAccounts;



}
}
Dry run: DRY RUN:
*
* Input:
* accounts = [
*   ["John", "mailto:johnsmith@mail.com", "mailto:john_newyork@mail.com"],   <- Account 0
*   ["John", "mailto:johnsmith@mail.com", "mailto:john00@mail.com"],          <- Account 1
*   ["Mary", "mailto:mary@mail.com"],                                   <- Account 2
*   ["John", "mailto:johnnybravo@mail.com"]                             <- Account 3
* ]
*
* ---- STEP 1: BUILD ADJACENCY LIST ----
*
* Account 0: firstEmail = johnsmith
*   j=2: johnsmith ↔ john_newyork
*
* Account 1: firstEmail = johnsmith
*   j=2: johnsmith ↔ john00
*
* Account 2: only 1 email → loop doesn't run → nothing added
* Account 3: only 1 email → loop doesn't run → nothing added
*
* Final adjacency list:
*   johnsmith    → [john_newyork, john00]
*   john_newyork → [johnsmith]
*   john00       → [johnsmith]
*   (mary and johnnybravo not present in map)
*
* Graph:
*   john_newyork
*        |
*   johnsmith          mary        johnnybravo
*        |
*     john00
*
* ---- STEP 2: DFS TRAVERSAL ----
*
* Iterate over accountList:
*
* Account 0 → firstEmail = johnsmith → NOT visited → DFS!
*   DFS(johnsmith)
*     visited = {johnsmith}, mergedAccount = ["John", "johnsmith"]
*     neighbors of johnsmith = [john_newyork, john00]
*       DFS(john_newyork)
*         visited = {johnsmith, john_newyork}, mergedAccount = [..., "john_newyork"]
*         neighbors of john_newyork = [johnsmith] → already visited, skip
*       DFS(john00)
*         visited = {johnsmith, john_newyork, john00}, mergedAccount = [..., "john00"]
*         neighbors of john00 = [johnsmith] → already visited, skip
*   after sort → ["John", "john00", "john_newyork", "johnsmith"]
*   mergedAccounts = [["John", "john00", "john_newyork", "johnsmith"]]
*
* Account 1 → firstEmail = johnsmith → ALREADY visited → SKIP
*
* Account 2 → firstEmail = mary → NOT visited → DFS!
*   DFS(mary)
*     visited = {..., mary}, mergedAccount = ["Mary", "mary"]
*     mary not in adjacent map → return immediately
*   after sort → ["Mary", "mailto:mary@mail.com"]
*   mergedAccounts = [["John", ...], ["Mary", "mailto:mary@mail.com"]]
*
* Account 3 → firstEmail = johnnybravo → NOT visited → DFS!
*   DFS(johnnybravo)
*     visited = {..., johnnybravo}, mergedAccount = ["John", "johnnybravo"]
*     johnnybravo not in adjacent map → return immediately
*   after sort → ["John", "mailto:johnnybravo@mail.com"]
*   mergedAccounts = [["John", ...], ["Mary", ...], ["John", "johnnybravo"]]
*
* ---- STEP 3: FINAL OUTPUT ----
*
* [
*   ["John",  "mailto:john00@mail.com", "mailto:john_newyork@mail.com", "mailto:johnsmith@mail.com"],
*   ["Mary",  "mailto:mary@mail.com"],
*   ["John",  "mailto:johnnybravo@mail.com"]
* ]
Complexity: KEY OBSERVATIONS:
* 1. We connect firstEmail ↔ everyOtherEmail (not every pair directly).
*    This is enough because DFS traverses transitively.
*
* 2. We iterate over accountList (not adjacent.keySet()) because:
*    a) Single-email accounts never enter the adjacency map → would be missed
*    b) Account name is only available in accountList, not in the graph
*
* 3. visited set ensures each connected component is processed EXACTLY once.
*    When Account 1's johnsmith is seen again → already visited → skip.
*    This prevents duplicate merged accounts.
*
* 4. DFS early return handles single-email accounts gracefully:
*    if (!adjacent.containsKey(email)) return;
*
* TIME COMPLEXITY:  O(NKlog(NK))
*   N = number of accounts, K = max emails per account
*   Building graph  → O(NK)
*   DFS traversal   → O(NK)
*   Sorting emails  → O(NKlog(NK))  ← dominates
*
* SPACE COMPLEXITY: O(NK)
*   Adjacency list + visited set store at most NK emails total
*/
/*
* TIME COMPLEXITY: O(NKlog(NK))
* N = number of accounts, K = max emails per account
*
* STEP 1: Building Adjacency List
* --------------------------------
* for each account (N accounts):
*     for each email in account (K emails):
*         add to adjacency list
*
* Total emails processed = NK
* Each email added at most twice (bidirectional edge)
* TC = O(NK)
*
* STEP 2: DFS Traversal
* ----------------------
* Every email is visited EXACTLY once (visited set prevents revisits)
* Every edge is traversed EXACTLY once
* Total emails across all accounts = NK
* TC = O(NK)
*
* STEP 3: Sorting (DOMINANT TERM)
* ---------------------------------
* This is the tricky part. We don't sort each account independently.
* After merging, one component can contain emails from MULTIPLE accounts.
*
* WORST CASE: all accounts belong to one person
*   Account 0: johnsmith, a1, a2
*   Account 1: johnsmith, a3, a4
*   Account 2: johnsmith, a5, a6
*   → One giant merged list with NK emails
*   → Sorting NK elements = O(NK * log(NK))
*
* BEST CASE: all accounts are separate (no shared emails)
*   N components, each with K emails
*   Each sort = Klog(K)
*   Total = N * Klog(K) = O(NKlog(K))
*
* Since log(NK) = log(N) + log(K), worst case is O(NK * log(NK))
*
* WHY STEP 3 DOMINATES:
* ----------------------
* Step 1 → O(NK)
* Step 2 → O(NK)
* Step 3 → O(NK * log(NK))   <- log(NK) > 1 always, so this wins
*
* SPACE COMPLEXITY: O(NK)
* -------------------------
* Adjacency list → O(NK)  each email stored as a node + edges
* Visited set    → O(NK)  at most NK emails tracked
* Result list    → O(NK)  all emails appear exactly once in output
*
* SIMPLE MENTAL MODEL:
* ---------------------
* You are ultimately sorting up to NK emails in total.
* Sorting M elements always costs Mlog(M).
* Here M = NK → O(NK * log(N*K))
*/

© 2026 Vidya Srinivasa Kesarla. All rights reserved.