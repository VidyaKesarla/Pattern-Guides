# 1752. Check if array is sorted and rotated

Difficulty: Easy
Input Data Structure: Array
Pattern trigger(recognition) / constraints hint / : Recognizing that we need to count "inversions" (or drops) comes from looking at the core property of a sorted array and seeing how rotation alters it.
Here is the mental pipeline that gets you to that realization:
### 1. Define the "Perfect" State
First, look at a standard sorted array: [1, 2, 3, 4, 5].
If you check every adjacent pair (nums[i] < nums[i-1]), the condition is never true. There are 0 drops. Every element is greater than or equal to the last.
### 2. Observe the Effect of Rotation
Now, rotate that perfect array: [3, 4, 5, 1, 2].
Notice the relationships between adjacent elements:
* 3 -> 4 (Rising)
* 4 -> 5 (Rising)
* 5 -> 1 (Dropped! This is an inversion)
* 1 -> 2 (Rising)
By rotating the array, we didn't destroy the sorting; we just cut it in half and swapped the pieces. Because we only made one cut, we created exactly one drop (from 5 to 1).
### 3. Connect the Ends (The "Circular" Realization)
What happens if an array is already sorted and not rotated, like [1, 2, 3, 4, 5]?
If we connect the last element (5) back to the first element (1), we get a virtual pair: 5 -> 1. That is one drop.
So, if we treat the array as a circle:
* A perfectly sorted array has 1 drop (at the boundary connecting the end to the start).
* A rotated sorted array has 1 drop (at the pivot point where it was cut).
### 4. The "Aha!" Moment
If a valid array can only ever have 0 drops (if all elements are identical, like [1, 1, 1]) or 1 drop (either at the pivot or at the boundary), then the entire problem reduces to a simple counting exercise:
> "Count how many times a number is smaller than the one before it. If that count ever exceeds 1, the structural integrity of a 'single rotation' is broken."
>
That is how you bridge the gap between the problem description and the "inversion count" solution. You are looking for the minimum number of rule-breaks allowed to satisfy the condition.

Constraints: Constraints:
• 1 <= nums.length <= 100
• 1 <= nums[i] <= 100
Brute force code and its trade off: class Solution {

public boolean check(int[] nums) {
int n = nums.length;

// Construct the rotated array
int[] checkSorted = new int[n];

// Iterate through all possible rotation offsets
for (int rotationOffset = 0; rotationOffset < n; ++rotationOffset) {
int currIndex = 0;
for (int index = rotationOffset; index < n; ++index) {
checkSorted[currIndex++] = nums[index];
}
for (int index = 0; index < rotationOffset; ++index) {
checkSorted[currIndex++] = nums[index];
}

// Check if the constructed array is sorted
boolean isSorted = true;
for (int index = 0; index < n - 1; ++index) {
if (checkSorted[index] > checkSorted[index + 1]) {
isSorted = false;
break;
}
}

// If sorted, return true
if (isSorted) {
return true;
}
}

// If no rotation makes the array sorted, return false
return false;
}
}
Algorithm: array
Optimisation : Circular array, Inversion counting, One pass optimisation
Rationale: A sorted array can be cyclically rotated iff it has at most one index where nums[i] > nums[i+1] (wrapping around)
Code: class Solution {

public boolean check(int[] nums) {
int n = nums.length;
if (n <= 1) return true;

int inversionCount = 0;

// For every pair, count the number of inversions.
for (int i = 1; i < n; ++i) {
if (nums[i] < nums[i - 1]) {
++inversionCount;
if (inversionCount > 1) return false;
}
}

// Also check between the last and the first element due to rotation
if (nums[0] < nums[n - 1]) {
++inversionCount;
}

return inversionCount <= 1;
}
}
Dry run: ### 🚀 Simple $O(n)$ One-Pass Intuition with Dry Run

The core idea is to think of the array as a circular loop. For a valid sorted and rotated array, there can be at most 1 "drop" (where an element is strictly smaller than the previous one) across the entire loop.

* If there are 0 drops, the array is already sorted (e.g., [1, 2, 3]).
* If there is 1 drop, it's a valid rotated sorted array (e.g., [3, 4, 5, 1, 2]).
* If there are > 1 drops, it's invalid (e.g., [2, 1, 3, 4, 2]).

---

### 🔍 Dry Runs

#### Scenario 1: Valid Rotated Array
* Input: nums = [3, 4, 5, 1, 2]

| Step / Index | Condition | Result | inversionCount |
| :--- | :--- | :--- | :--- |
| i = 1 | 4 < 3 | False | 0 |
| i = 2 | 5 < 4 | False | 0 |
| i = 3 | 1 < 5 | True (Drop) | 1 |
| i = 4 | 2 < 1 | False | 1 |
| End Check | nums[0] < nums[4] (3 < 2) | False | 1 |

* Final Check: inversionCount <= 1 $\rightarrow$ Returns true ✅

---

#### Scenario 2: Invalid Array (Early Exit)
* Input: nums = [2, 1, 3, 4, 2]

| Step / Index | Condition | Result | inversionCount |
| :--- | :--- | :--- | :--- |
| i = 1 | 1 < 2 | True (Drop) | 1 |
| i = 2 | 3 < 1 | False | 1 |
| i = 3 | 4 < 3 | False | 1 |
| i = 4 | 2 < 4 | True (Drop) | 2 $\rightarrow$ Triggers early exit! |

* Final Check: Immediately returns false ✅

---

#### Scenario 3: Sorted Array (No rotation)
* Input: nums = [1, 2, 3]

| Step / Index | Condition | Result | inversionCount |
| :--- | :--- | :--- | :--- |
| i = 1 | 2 < 1 | False | 0 |
| i = 2 | 3 < 2 | False | 0 |
| End Check | nums[0] < nums[2] (1 < 3) | True (Boundary Drop) | 1 |

* Final Check: inversionCount <= 1 $\rightarrow$ Returns true ✅

---

### 📊 Complexity
* Time Complexity: $O(n)$ — Single pass through the array. The early exit condition (inversionCount > 1) helps optimize for messy arrays.
* Space Complexity: $O(1)$ — Only tracking a single counter.

Complexity: Complexity Analysis
Let n be the size of the nums array.
• Time Complexity: O(n)
The algorithm counts inversions by iterating through the array once, which takes O(n). Additionally, it checks if there's an inversion between the last and the first element due to rotation, also taking O(1) operations. Thus, the overall time complexity is O(n).
• Space Complexity: O(1)
The algorithm uses a constant amount of extra space, primarily for counting inversions and simple comparisons. No additional data structures are required, so the overall space complexity is O(1).
Visualisation: https://claude.ai/share/9144b18e-f83d-40d5-ba0f-f8b8aaabc618
Claude link: https://claude.ai/share/9144b18e-f83d-40d5-ba0f-f8b8aaabc618

© 2026 Vidya Srinivasa Kesarla. All rights reserved.