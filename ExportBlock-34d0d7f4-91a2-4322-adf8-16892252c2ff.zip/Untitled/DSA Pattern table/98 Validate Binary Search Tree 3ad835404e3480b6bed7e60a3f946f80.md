# 98. Validate Binary Search Tree

Difficulty: Medium
Input Data Structure: Array
Pattern trigger(recognition) / constraints hint / : Inorder traversal → left→ root→ right

For a BST, this produces nodes in sorted ascending order

Why inorder is special because for a plain binary tree inorder is just another traversal , but for a BST, its a sorted sequence generator


Used when: you need sorted order from BST or need to process nodes such that everything smaller comes before everything bigger

”Validate if its a binary search tree”
Signal / Paraphrase hint: BST + order⇒ inorder gives sorted sequence for free


Constrainsts are also hinting at inorder because 

Number of nodes in the tree is in the range [1,10^4]
-2^31 ≤ Node.val ≤ 2^31-1

Node count up to 10^4 and 10^5 values distinct BST mentioned 
strongly suggest inorder based solution is intended 
Algorithm: Recursive traversal with valid range
Optimisation : Iterative inorder traversal
Why this is better? Optimisation details: Recursion takes around O(N) And O(N) tc & SC
Rationale: Both recursion and iterative inorder traversal leads us to the same tc + sc
Code: class Solution {
public boolean isValidBST(TreeNode root) {
Deque<TreeNode> stack = new ArrayDeque<>();
Integer prev = null;

while (!stack.isEmpty() || root != null) {
while (root != null) {
stack.push(root);
root = root.left;
}
root = stack.pop();

// If next element in inorder traversal
// is smaller than the previous one
// that's not BST.
if (prev != null && root.val <= prev) {
return false;
}
prev = root.val;
root = root.right;
}
return true;
}
}
Complexity: Complexity Analysis
• Time complexity: O(N) in the worst case when the tree is BST or the "bad" element is the rightmost leaf.
• Space complexity: O(N) to keep stack.

© 2026 Vidya Srinivasa Kesarla. All rights reserved.