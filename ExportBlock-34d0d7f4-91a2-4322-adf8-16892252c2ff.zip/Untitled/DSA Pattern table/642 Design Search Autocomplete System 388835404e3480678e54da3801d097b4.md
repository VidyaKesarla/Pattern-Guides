# 642. Design Search Autocomplete System

Difficulty: Medium
Input Data Structure: Array of strings
Pattern trigger(recognition) / constraints hint / : Here are the signals that should trigger recognizing this as a Trie + Autocomplete problem:
Explicit keywords
• "autocomplete", "search suggestions", "typeahead"
• "top-k results as you type"
• "hot" or "frequency" ranked results
• "historical queries" / "previously searched sentences"
Structural signals
• Input arrives one character at a time (not as a full string)
• Results must update after every single character
• A special terminator character (#, \n, Enter) saves the current input
• Results are ranked by frequency first, then lexicographic order as a tiebreaker
Constraint signals
• You need prefix matching — "all strings that start with X"
• The dataset is pre-loaded (constructor receives sentences + counts), then queried incrementally
• Top k results only (usually k = 3)
• New entries must be added dynamically during runtime
The dead-end tell
• Once a prefix has no match, all subsequent characters for that session also return empty — this screams "route to a dummy node" rather than re-querying from root each time
Paraphrase patterns that all mean the same thingWhat the problem saysWhat it actually means"return the 3 most searched sentences"top-k by frequency"that have the same prefix as the typed part"trie prefix traversal"if there is a tie, return in lexicographic order"secondary sort on string"input('#') means the sentence is finished"reset currNode to root, persist the sentence"the system should learn from new inputs"addToTrie on '#' with count +1
The single clearest trigger: "character-by-character input that filters a ranked list of past strings by prefix." Any problem with that shape is this exact problem, regardless of the domain (search engine, emoji picker, command palette, GPS address bar).
Constraints: Constraints:
• n == sentences.length
• n == times.length
• 1 <= n <= 100
• 1 <= sentences[i].length <= 100
• 1 <= times[i] <= 50
• c is a lowercase English letter, a hash '#', or space ' '.
• Each tested sentence will be a sequence of characters c that end with the character '#'.
• Each tested sentence will have a length in the range [1, 200].
• The words in each input sentence are separated by single spaces.
• At most 5000 calls will be made to input.
Intuition: https://leetcode.com/problems/design-search-autocomplete-system/editorial/#approach-1-trie
Optimisation : Trie
Code: /*
What is a trie?
It is a data structure that can be used to efficiently search for strings
we can also call it as a prefix tree used to efficiently store and retrieve keys in a dataset of strings
If we are not familiar with tries: there is some link which we can use to understand it

TRIE => TREE where each node is labeled.
We label each node with a character
Path from root to any node represents the string that is build by the nodes on the path
What it is=> complete tree management object
Main job => track single root node and expose public function
methods => insert(), search() and startsWith()
Quantity => only one instance is initialised to manage a dictionary

TRIENODE:
What it is=> A trienode is a single block/unit within the tree
Main job => it is to store links to children and an end-of-word flag
Quantity => thousands can exist inside a single tree
Root => empty string

/

class TrieNode {
Map<Character, TrieNode> children;
//sentences map will be used to count the number of times each sentence was typed
Map<String, Integer> sentences;

//initialise it
public TrieNode(){
children = new HashMap<>();
sentences = new HashMap<>();
}
}

// The goal is to build an autocomplete system (like what you see in a search bar) that:

// 1. Learns from historical searches — sentences you've typed before, with how many times you've typed them.

// 2. As you type each character, returns the top 3 suggestions that:
//    - Start with whatever you've typed so far
//    - Are ranked by frequency (most typed = shown first)
//    - Ties broken by alphabetical order

// 3. When you hit # (end of input), it saves that new sentence to the system so future searches can suggest it.

// Real world analogy: Google's search bar — as you type "i love", it suggests your most searched phrases starting with those characters.

class AutocompleteSystem {
//trie ds is a very great option whenever we want to search in a collection of strings=> that is especialy if you are searching one character at a time

//if we put all sentences in a trie => we can walk through every sentence simultaneously with each ccall to input

TrieNode root;
TrieNode currNode;
TrieNode dead;
StringBuilder currSentence;

//Calling addToTrie(sentence, count) means that sentence was typed count times and we will update our trie to reflect it
private void addToTrie(String sentence, int count){
TrieNode node = root;
for(char c: sentence.toCharArray()){
if(!node.children.containsKey(c)){
node.children.put(c, new TrieNode());
}
node = node.children.get(c);
//each trie node has a hashmap which holds all sentences that have the current path as a prefix. As we need to return the sentences that have been typed the most, we need to map each sentence to its count
node.sentences.put(sentence, node.sentences.getOrDefault(sentence, 0) + count);
}
}

public AutocompleteSystem(String[] sentences, int[] times) {
root = new TrieNode();
for(int i =0;i<sentences.length;i++){
addToTrie(sentences[i], times[i]);
}
currSentence = new StringBuilder();
currNode = root;
dead = new TrieNode();
}
//calling this input function means we are typing some character, calling it repeatedly means we are typing out a sentence. currSentence is a class attribute which represents the current sentence we are typing. along with this let us also keep a class attribute currNode that represents the current node in trie we are located at.
//whenever we start typing a new sentence we set currNode = root
public List<String> input(char c) {
//3 possibilities for input func:

//1. we have finished typing current sentence.
/
Add currSentence as a string to trie using addToTrie func and reset our class variables.
empty currSentence
set currNode = root, return an empty List
/
if(c == '#'){
addToTrie(currSentence.toString(), 1);
currSentence.setLength(0);
currNode = root;
return new ArrayList<String>();
}

//3. if current char c is not #, c is not a child of currNode.
//there are no existing sentences that have the current sentence we aRE typing as a prefix. we just need to add c to currSentence and return an empty list
currSentence.append(c);
if(!currNode.children.containsKey(c)){
currNode = dead;
return new ArrayList<String>();
}


//2. if current char c is not #, c is a child of currNode.
//there are some existing sentences that have the current sentence we are typing as a prefix. first lets add this current char c to currSentence. next walk to the childnode by doing currNode = currNode.children[c]. fetch the sentences that have the current sentence as a prefix. we store them in hashmap currNode.sentences with the mapping sentence: count. finally sort these sentences according to their count and return the top 3 sentences according to the criteria

//as sorting is expensive, we can use heap for the same

currNode = currNode.children.get(c);
//initialise heap with a custom comparator -> worse sentences need to be removed first.
//we iterate over sentences and push each one onto the heap
//when heap size exceeds 3 we pop from it
//after handling all sentences the 3 best sentences will remain in the heap.

//     The comparator logic:
// 1.	Primary sort — by frequency (ascending): hotA - hotB means lower frequency = higher priority to be removed. So the least-frequent sentence sits at the top of the min-heap and gets evicted first when heap.size() > 3.
// 2.	Tiebreaker — by reverse alphabetical order: b.compareTo(a) (instead of a.compareTo(b)) means lexicographically larger strings bubble to the top when frequencies are equal — so they get evicted first, keeping the alphabetically earlier ones.

//      Say two sentences have the same frequency, e.g.:
// "i love leetcode" → frequency 3
// "island"          → frequency 3


// The comparator hits the tiebreaker: b.compareTo(a).
// "island".compareTo("i love leetcode") — comparing character by character:
// - 'i' == 'i' → tie
// - ' ' (space, ASCII 32) vs 's' (ASCII 115) → space comes first
// So "island" > "i love leetcode" lexicographically, meaning b.compareTo(a) returns positive, putting "island" at the top of the min-heap — so it gets evicted first.
// Result: "i love leetcode" survives over "island" because it comes earlier alphabetically, which is the desired behavior.
PriorityQueue<String> heap = new PriorityQueue<>((a,b) -> {
//first hot sentence
int hotA = currNode.sentences.get(a);
int hotB = currNode.sentences.get(b);
//
if(hotA == hotB){
return b.compareTo(a);
}
return hotA - hotB;
});



for(String sentence: currNode.sentences.keySet()){
heap.add(sentence);
if(heap.size() > 3){
heap.remove();
}
}

List<String> ans = new ArrayList<>();
while(!heap.isEmpty()){
ans.add(heap.remove());
}

// Because the heap is a min-heap, when you drain it with heap.remove(), elements come out in worst → best order (lowest frequency first).

// Example — heap contains:
//         // "i love leetcode" (3)  ← top of min-heap (lowest freq)         // "i love you"      (5)         //

// Draining gives: ["i love leetcode", "i love you"]

// But we want best first: ["i love you", "i love leetcode"]

// So Collections.reverse() flips it to the correct order.

// In short: min-heap gives you ascending order, but the result needs to be descending (highest frequency first).
Collections.reverse(ans);
return ans;
}
}

/*
* Your AutocompleteSystem object will be instantiated and called as such:
* AutocompleteSystem obj = new AutocompleteSystem(sentences, times);
* List<String> param_1 = obj.input(c);
*/
Dry run: https://claude.ai/share/4441653e-c519-41bd-a156-a659b1c46be7
Complexity: Complexity Analysis
Given n as the length of sentences, k as the average length of all sentences, and m as the number of times input is called,This analysis will assume that you have access to a linear time heapify method, like in the Python implementation.
• Time complexity: O(n⋅k+m⋅(n+km))
constructor:
    ◦ We initialize the trie, which costs O(n⋅k) as we iterate over each character in each sentence.
input:
    ◦ We add a character to currSentence and the trie, both cost O(1). Next, we fetch the sentences in the current node. Initially, a node could hold O(n) sentences. After we call input m times, we could add km new sentences. Overall, there could be up to O(n+km) sentences. We heapify these sentences and find the best 3 in linear time, which costs O(n+km).
    ◦ The work done in the other cases (like adding a new sentence to the trie) will be dominated by this.
    ◦ input is called m times, which gives us a total of O(m⋅(n+km)).
• Space complexity: O(k⋅(n⋅k+m))
The worst-case scenario for the trie size is when no two sentences share any prefix. The trie will initially have a size of n⋅k. Then, each call to input would create a new node.
Each of these trie nodes has children and sentences hash maps. The size of children is limited to 26, so we will ignore it. The size of sentences is variable, but in the case described, each node will only have 1 entry (because no two sentences share any prefix, so no trie node is visited by more than one sentence). This 1 entry will have a size of O(k).
Visualisation: https://claude.ai/share/4441653e-c519-41bd-a156-a659b1c46be7
Claude link: https://claude.ai/share/4441653e-c519-41bd-a156-a659b1c46be7

© 2026 Vidya Srinivasa Kesarla. All rights reserved.