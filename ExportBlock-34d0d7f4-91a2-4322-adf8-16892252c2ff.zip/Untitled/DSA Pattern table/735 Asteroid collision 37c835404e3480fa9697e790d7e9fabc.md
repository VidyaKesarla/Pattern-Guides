# 735. Asteroid collision

Difficulty: Medium
Input Data Structure: Array
Pattern trigger(recognition) / constraints hint / : When we simulate the process mentally → we notice a specific chain reaction → if a right moving asteroid + meets a left moving asteroid - they collide. 
Signal / Paraphrase hint: If the negative asteroid wins → it doesn’t just stop there. It keeps moving left and must now face the immediate next asteroid to its left. Most recently processed right moving asteroid is the first one to face the incoming left moving threat. This  - “Last In, first destroyed” is classic signature of a stack.

I need to maintain a history of elements that are currently stable.""When a conflicting element appears, it needs to repeatedly interact with the most recent elements of that history until a condition is met.""A collision only happens at the boundary between the processed history and the current element."
Constraints: Looking at the constraints provided on the page:
• 2 <= asteroids.length <= 10^4
An $O(N^2)$ brute-force approach (like repeatedly scanning the array to find a collision, removing elements, and shifting the array) might pass under tight limits, but it is highly inefficient because shifting items in an array takes linear time.
A stack gives you an $O(N)$ time complexity solution. Even though there is a while loop inside the iteration to resolve multiple collisions, each asteroid is pushed onto the stack at most once and popped from the stack at most once.
Intuition: Visual shift: Thinking of the problem not as elements moving simultaneously in space, but as a linear timeline where you process elements from left to right. 1. We try to keep track of a stable surviving line of asteroids. 2. A new asteroid enters from the right. 3. If it’s moving right it safely joins the back of the line.4. If its moving left, it must continuously battle the top of your surviving stack until it either explodes or destroys everything in its way. 
Edge cases / base cases: /**
* 🎯 CRITICAL EDGE & BASE CASES TO TEST
* Make sure your solution handles these scenarios before clicking Submit!
/

/ 1. Base Cases (Minimal Inputs) /
// Empty Input: [] -> Returns [] (Safely skips loop)
// Single Asteroid: [10] or [-5] -> Returns [10] or [-5] (No opposing forces)

/ 2. No-Collision Scenarios /
// All Same Direction: [2, 5, 10] -> Returns [2, 5, 10] (Never cross paths)
// Moving Apart: [-5, 5] -> Returns [-5, 5]
// (The left moves <-, the right moves ->. They never meet!)

/ 3. Extreme Collisions */
// Complete Annihilation: [5, 10, -10, -5] -> Returns []
// (Symmetrical matching sizes destroy the entire stack step-by-step)

// The "Pac-Man" Dominator: [1, 2, 3, 4, -5] -> Returns [-5]
// (Tests the while loop's ability to clear a continuous chain of smaller elements)

// The "Shield" Asteroid: [10, 2, 1, -5] -> Returns [10]
// (Tests if the loop correctly stops. -5 eats 1 and 2, but dies when hitting 10)

Algorithm: Brute force
Optimisation : stack
Code:     class Solution {
func asteroidCollision(_ asteroids: [Int]) -> [Int] {
// Use an array as a stack to store the surviving asteroids.
var stack: [Int] = []

// Iterate through each asteroid.
for newAsteroid in asteroids {
// A flag to determine if the new asteroid survives and should be added to the stack.
var newAsteroidSurvived = true

// A collision can only happen if the new asteroid is moving left (< 0)
// and the asteroid on top of the stack is moving right (> 0).
while !stack.isEmpty && newAsteroid < 0 && stack.last! > 0 {
let topAsteroid = stack.last!

// Case 1: The asteroid on the stack is larger.
// The new asteroid explodes.
if topAsteroid > -newAsteroid {
newAsteroidSurvived = false
break
}
// Case 2: Both asteroids are the same size.
// Both explode.
else if topAsteroid == -newAsteroid {
stack.removeLast()
newAsteroidSurvived = false
break
}
// Case 3: The new asteroid is larger.
// The asteroid on the stack explodes.
else {
stack.removeLast()
// Continue the loop to check the new asteroid against the next one on the stack.
}
}

// If the new asteroid survived all its encounters, add it to the stack.
if newAsteroidSurvived {
stack.append(newAsteroid)
}
}

// The stack contains the final state of the asteroids.
return stack
}
}
Dry run: /**
* 🚀 DETAILED DRY RUN STEP-BY-STEP
* * Input: asteroids = [5, 10, -10, -5, 8, -12]
* * Notation:
* - Positive numbers (e.g., 5) move RIGHT (->)
* - Negative numbers (e.g., -10) move LEFT (<-)
* - Collision only happens if top of stack is (->) and newAsteroid is (<-)
/

| Step | New Asteroid | Condition / Collision Check | Action Taken & Logic | Stack State (End of Step) |
| :--- | :---: | :--- | :--- | :--- |
| 1 | 5 | Stack is empty | No collision possible. Pushed to stack. | [5] |
| 2 | 10 | Top 5 (->), New 10 (->) | Same direction. No collision. Pushed to stack. | [5, 10] |
| 3 | -10 | Top 10 (->), New -10 (<-) | 💥 Collision! Sizes equal (10 == 10). Top popped, new one destroyed. | [5] |
| 4 | -5 | Top 5 (->), New -5 (<-) | 💥 Collision! Sizes equal (5 == 5). Top popped, new one destroyed. | [] |
| 5 | 8 | Stack is empty | No collision possible. Pushed to stack. | [8] |
| 6a | -12 | Top 8 (->), New -12 (<-) | 💥 Collision! New is bigger (12 > 8). Top 8 explodes (popped). | [] |
| 6b | -12 | Stack is now empty | Loop terminates. New -12 survives and is pushed. | [-12] |

/*
* Final Returned Stack: [-12]
* * Complexity:
* - Time Complexity: O(N) -> Each asteroid is pushed and popped at most once.
* - Space Complexity: O(N) -> To store the stack.
*/

Complexity: * * Complexity:
* - Time Complexity: O(N) -> Each asteroid is pushed and popped at most once.
* - Space Complexity: O(N) -> To store the stack.
Visualisation: https://claude.ai/share/8ca55ded-5e63-4c75-8bd9-d5abcdb25d7a
Claude link: https://claude.ai/share/8ca55ded-5e63-4c75-8bd9-d5abcdb25d7a

© 2026 Vidya Srinivasa Kesarla. All rights reserved.