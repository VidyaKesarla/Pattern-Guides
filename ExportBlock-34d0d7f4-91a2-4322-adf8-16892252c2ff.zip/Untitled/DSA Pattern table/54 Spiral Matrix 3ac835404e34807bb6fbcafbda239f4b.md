# 54. Spiral Matrix

Difficulty: Medium
Input Data Structure: 2D Array
Constraints: 
• m == matrix.length
• n == matrix[i].length
• 1 <= m, n <= 10
• -100 <= matrix[i][j] <= 100
Intuition: Approach 1: Set Up Boundaries
Optimisation : Set up boundaries
Rationale: Algorithm
1. Initialize the top, right, bottom, and left boundaries as up, right, down, and left.
2. Initialize the output array result.
3. Traverse the elements in spiral order and add each element to result:
    ◦ Traverse from left boundary to right boundary.
    ◦ Traverse from up boundary to down boundary.
    ◦ Before we traverse from right to left, we need to make sure that we are not on a row that has already been traversed. If we are not, then we can traverse from right to left.
    ◦ Similarly, before we traverse from top to bottom, we need to make sure that we are not on a column that has already been traversed. Then we can traverse from down to up.
    ◦ Remember to move the boundaries by updating left, right, up, and downaccordingly.
4. Return result.
Code: class Solution {
public List<Integer> spiralOrder(int[][] matrix) {
List<Integer> result = new ArrayList<>();
int rows = matrix.length;
int columns = matrix[0].length;
int up = 0;
int left = 0;
int right = columns - 1;
int down = rows - 1;

while (result.size() < rows * columns) {
// Traverse from left to right.
for (int col = left; col <= right; col++) {
result.add(matrix[up][col]);
}
// Traverse downwards.
for (int row = up + 1; row <= down; row++) {
result.add(matrix[row][right]);
}
// Make sure we are now on a different row.
if (up != down) {
// Traverse from right to left.
for (int col = right - 1; col >= left; col--) {
result.add(matrix[down][col]);
}
}
// Make sure we are now on a different column.
if (left != right) {
// Traverse upwards.
for (int row = down - 1; row > up; row--) {
result.add(matrix[row][left]);
}
}
left++;
right--;
up++;
down--;
}

return result;
}
}
Complexity: // Let M be the number of rows and N be the number of columns.// Time complexity: O(M⋅N). This is because we visit each element once.// Space complexity: O(1). This is because we don't use other data structures. Remember that we don't include the output array in the space complexity.

© 2026 Vidya Srinivasa Kesarla. All rights reserved.