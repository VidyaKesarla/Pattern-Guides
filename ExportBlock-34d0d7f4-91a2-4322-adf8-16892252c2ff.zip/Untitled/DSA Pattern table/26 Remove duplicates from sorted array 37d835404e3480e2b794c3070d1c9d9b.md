# 26. Remove duplicates from sorted array

Difficulty: Easy
Input Data Structure: Array
Pattern trigger(recognition) / constraints hint / : Pattern Trigger & Signal
How do you recognize this problem pattern in the future?
 The Trigger: You are asked to modify a linear data structure (array/linked list) in-place based on a conditional comparison, usually involving sorted data.
 The Signal: Two-Pointer Approach (Fast & Slow Pointer).
 Whenever you need to filter or re-arrange an array without extra space, one pointer (⁠j⁠) scans the data (fast pointer), while another pointer (⁠i⁠) writes the valid data (slow pointer).
Clarifying questions: Clarifying Questions
Before writing code, ask these questions to show the interviewer you think about constraints and data integrity:
 "Is the input array guaranteed to be sorted? (If not, we would need to sort it first, changing the time complexity)."
 "Should we modify the array in-place, or is it acceptable to allocate new memory?" (The problem specifies in-place, but asking validates constraints).
 "What should we return if the array is empty or has a length of 1?"
 "What are the constraints on the values inside the array? Can they be negative?"
 "Does the remaining data beyond the unique elements matter?”
Constraints: Constraints:
• 1 <= nums.length <= 3 * 104
• -100 <= nums[i] <= 100
• nums is sorted in non-decreasing order.
Brute force code and its trade off: 📊 Brute Force vs. Optimal Trade-off

When explaining your solution in an interview or post, it's great to contrast it with the naive approach to showcase why the two-pointer method is chosen.

• Brute Force Approach (Using a Set):
- Mechanism: Iterate through the array, insert elements into a HashSet to eliminate duplicates, and then copy the unique elements back into the original array.
- Time Complexity: O(N) [One pass to populate the Set, another pass to write back into the array].
- Space Complexity: O(N) ❌ [Requires extra memory proportional to the number of unique elements].
- Prerequisite: Works on any array (sorted or unsorted).
- Verdict: Fails Constraints. Though intuitive, it explicitly violates the problem's strict constraint of using O(1) auxiliary space.

• Optimal Approach (Two-Pointer Technique):
- Mechanism: Use a fast pointer (j) to scan the array and a slow pointer (i) to overwrite duplicates with unique elements in-place.
- Time Complexity: O(N) [A single, linear scan through the array].
- Space Complexity: O(1) ✅ [Uses zero extra heap memory; modifies the array entirely in-place].
- Prerequisite: Requires the array to be sorted so that duplicates are always adjacent.
- Verdict: Optimal Solution. Achieves maximum space efficiency and satisfies all follow-up criteria perfectly.

Intuition: Problem would have been simpler : if we were allowed to use some extra space like a hashmap. We can create a map which stores all unique elements as the key and element frequency as the value.

After populating our map → we get all the unique elements from our array.
we then iterate our map and push all the keys in our input array.

however, without using extra space → makes it a bit tricky as we have to modify the existing input array.

Guaranteed: 
  1. that the given array is a sorted array.
  2. k be the count of unique elements in our input array.
  3. one observation we can make is: since the array that we have is sorted → all duplicate values will be one after the other.
  4. We need to update the first k elements in array with unique values and return the value of k
  5. for doing this → we modify the input array in place so that use dont use extra space.
  6. in order to perform in place operations we use the two indices approach. 
  7. first index updates the value in our input array while reading the data from the second index.

Edge cases / base cases: Edge Cases
Your solution handles edge cases gracefully, but you should explicitly state them:
 Empty Array (⁠nums = []⁠): Handled by ⁠if (nums.length == 0) return 0;⁠.
 Single Element (⁠nums = [1]⁠): The loop condition ⁠j < nums.length⁠ (1 < 1) immediately fails. It returns ⁠i = 1⁠, which is correct.
 All Duplicates (⁠nums = [1, 1, 1, 1]⁠): The condition ⁠nums[j] != nums[j-1]⁠ is always false. The loop completes without writing, and returns ⁠1⁠. The array becomes ⁠[1, 1, 1, 1]⁠, and the first 1 element is read.
 All Unique Elements (⁠nums = [1, 2, 3, 4]⁠): The condition is always true. It overwrites elements with themselves (⁠nums[i] = nums[j]⁠), moving ⁠i⁠ smoothly to the end, returning ⁠4⁠.
Algorithm: Two indexes approach
Optimisation : Two indexes approach
Code: class Solution {
public int removeDuplicates(int[] nums) {
if (nums.length == 0) {
return 0;
}

int i = 1; // Initialized 'i' to track the next unique element position

for (int j = 1; j < nums.length; j++) {
// Compare current element with the previous one to find uniques
if (nums[j] != nums[j - 1]) {
nums[i] = nums[j];
i++;
}
}

return i; // 'i' now represents the total count of unique elements
}
}

Dry run: ### 🚀 Detailed Step-by-Step Dry Run

To understand how this two-pointer approach works, let's trace it using a standard testcase.

Input: nums = [1, 1, 2, 2, 3]

---

#### 🔹 Initial State
* nums.length = 5 (skips the base case)
* i = 1 (tracks the index where the next unique element should go)

---

#### 🔹 Loop Trace

| Step | j | nums[j] | nums[j-1] | Condition: nums[j] != nums[j-1] | Action Taken | Modified Array | i Value |
| :--- | :---: | :---: | :---: | :---: | :--- | :--- | :---: |
| Start| - | - | - | - | Initial Setup | [1, 1, 2, 2, 3] | 1 |
| Iter 1| 1 | 1 | 1 | 1 != 1 ❌ False | Duplicate found. Skip. | [1, 1, 2, 2, 3] | 1 |
| Iter 2| 2 | 2 | 1 | 2 != 1  True | nums[1] = nums[2], i++ | [1, 2, 2, 2, 3] | 2 |
| Iter 3| 3 | 2 | 2 | 2 != 2 ❌ False | Duplicate found. Skip. | [1, 2, 2, 2, 3] | 2 |
| Iter 4| 4 | 3 | 2 | 3 != 2  True | nums[2] = nums[4], i++ | [1, 2, 3, 2, 3] | 3 |

---

#### 🔹 Final Result
* Loop ends because j reaches the end of the array.
* Returned Value: i = 3
* Final Array State: [1, 2, 3, 2, 3]

> Note: The judge will read the first i elements (first 3 elements), which correctly gives [1, 2, 3]. Elements beyond index i-1 do not matter!

Complexity: Complexity Analysis
Let N be the size of the input array.
• Time Complexity: O(N), since we only have 2 pointers, and both the pointers will traverse the array at most once.
• Space Complexity: O(1), since we are not using any extra space.
Visualisation: Initial: [ 1,  1,  2,  2,  3 ]   |   |   i   j   --> nums[j] == nums[j-1] (1 == 1). Skip!  Step 1: [ 1,  1,  2,  2,  3 ]   |       |   i       j   --> nums[j] != nums[j-1] (2 != 1). New number found!                   Write 2 at index i, then move i forward.  Step 2 (After Write): [ 1,  2,  2,  2,  3 ]       |   |       i   j   --> Move j forward. nums[j] == nums[j-1] (2 == 2). Skip!  Step 3: [ 1,  2,  2,  2,  3 ]       |           |       i           j   --> nums[j] != nums[j-1] (3 != 2). New number found!                   Write 3 at index i, then move i forward.  Final State: [ 1,  2,  3,  2,  3 ]           |           |           i           j (Out of bounds)  Result: Return i (3). The valid prefix is nums[0...2] -> [1, 2, 3]
Files & media: 26%20Remove%20duplicates%20from%20sorted%20array/IMG_2010.jpeg

© 2026 Vidya Srinivasa Kesarla. All rights reserved.