# 99. Recover Binary Search Tree (BST)

Difficulty: Medium
Input Data Structure: Array, Binary tree, TreeNode
Pattern trigger(recognition) / constraints hint / : 1. The Dead Giveaway (The Constraint)
 "Design an algorithm using O(1) extra space / constant memory."
 Any problem asking for an inorder, preorder, or postorder traversal where a standard recursive stack or standard iterative collection (O(H) or O(N) auxiliary space) is explicitly barred or heavily optimized against.

3. The Core Concept Blueprint
 If you need to visit a node, dive deep into its left subtree, and somehow remember how to get back up to that node without spending any memory allocations, you are looking at Morris Traversal. It relies entirely on temporarily "borrowing" the ⁠null⁠ right pointers of leaf nodes.
Signal / Paraphrase hint: “Tree Traversal”

2. Behavioral Signals & Paraphrases
 "Recover / Validate / Flatten a Binary Tree in-place without altering its structural reference allocations permanently."
 "Process a Binary Search Tree as a stream of sorted elements without copying the elements to an intermediate array or utilizing a tracking stack."
Clarifying questions: 1. "Can I assume the input tree will always contain exactly two swapped nodes, or is it possible that the tree is already valid?"
 Why: Prevents unnecessary swaps at the end if ⁠x⁠ and ⁠y⁠ remain ⁠null⁠.
2. "Are we allowed to temporarily mutate the pointers of the tree during processing, as long as the original structure is fully restored before the function returns?"
 Why: Morris Traversal temporarily alters right pointers. Some strict immutability contexts might forbid this, forcing a different trade-off.
3. "Could the swapped nodes include the root node or leaf nodes?"
 Why: Confirms that your tree-edge pointer logic handles extremes smoothly (which your current Morris logic does perfectly).
Constraints: Constraints:
• The number of nodes in the tree is in the range [2, 1000].
• -231 <= Node.val <= 231 - 1
Brute force code and its trade off: class Solution {
TreeNode x = null, y = null, pred = null;

public void swap(TreeNode a, TreeNode b) {
int tmp = a.val;
a.val = b.val;
b.val = tmp;
}

public void findTwoSwapped(TreeNode root) {
if (root == null) return;
findTwoSwapped(root.left);
if (pred != null && root.val < pred.val) {
y = root;
if (x == null) x = pred;
else return;
}
pred = root;
findTwoSwapped(root.right);
}

public void recoverTree(TreeNode root) {
findTwoSwapped(root);
swap(x, y);
}
}
Intuition: We discussed already iterative and recursive inorder traversals, which both have great time complexity though use up to O(N) to keep stack. We could trade in performance to save space.
The idea of Morris inorder traversal is simple: to use no space but to traverse the tree.How that could be even possible? At each node one has to decide where to go: left or right, traverse left subtree or traverse right subtree. How one could know that the left subtree is already done if no additional memory is allowed?
The idea of https://leetcode.com/link/?target=https%3A%2F%2Fwww.sciencedirect.com%2Fscience%2Farticle%2Fpii%2F0020019079900681 algorithm is to set the temporary link between the node and its
https://leetcode.com/articles/delete-node-in-a-bst/: predecessor.right = root. So one starts from the node, computes its predecessor and verifies if the link is present.
• There is no link? Set it and go to the left subtree.
• There is a link? Break it and go to the right subtree.
There is one small issue to deal with : what if there is no left child, i.e. there is no left subtree? Then go straightforward to the right subtree.
Edge cases / base cases: When handling tree recovery with Morris Traversal, edge cases usually don't break the code with crashes (like a NullPointerException), but they can break the tracking logic if it isn't robust enough.
Here are the critical edge and base cases you should check, along with how your specific code handles them:
### 1. Minimal Trees (Base Cases)
* Empty Tree (root == null): * Behavior: The while (root != null) loop never runs. swap(x, y) receives null, null, and the function terminates cleanly without an execution error.
* Single Node Tree: * Behavior: The outer loop runs once, falls into the outer else block because root.left == null. pred becomes the single node, root becomes null, and the loop safely exits without triggering a violation.
### 2. Structural Linearity (Degenerate Trees / Skewed Trees)
* All-Left Skewed Tree (Looks like a Linked List moving left):
* Behavior: The code handles this perfectly. For each node, it enters root.left != null, finds that the predecessor has no right child, establishes a link, and moves left. When it hits the bottom leaf, it bounces all the way back up processing nodes sequentially.
* All-Right Skewed Tree (Looks like a Linked List moving right):
* Behavior: For every single node, root.left != null is false. The code consistently falls into the outer else block, processing nodes sequentially as it marches down root = root.right.
### 3. Swapped Node Proximity & Positions
This is where standard solutions often fail, but your implementation handles them correctly because of the conditional logic if (x == null) x = pred;.
* Adjacent Swapped Nodes (e.g., [1, 2, 4, 3, 5]):
* The Trap: There is only one sequence violation drop in the entire traversal (when passing from 4 to 3).
* How your code passes: When 3 < 4, y is set to root (3), and because x is still null, x is set to pred (4). Both nodes are caught instantly.
* Non-Adjacent Swapped Nodes (e.g., [1, 5, 3, 4, 2, 6]):
* The Trap: There are two distinct sequence drops (5 \rightarrow 3 and 4 \rightarrow 2).
* How your code passes: On the first drop (3 < 5), x becomes 5 and y becomes 3. On the second drop (2 < 4), x is already assigned, so it remains 5, while y gets updated to the lower boundary 2. The final swap smoothly targets 5 and 2.
### 4. Extreme Boundaries
* The Root Node is Swapped with a Leaf Node:
* Behavior: This was exactly the case in your dry-run image (where the root 3 was swapped with leaf 4). Because Morris Traversal maps out the entire tree layout linearly in memory, it doesn't matter if a node is at the top of the hierarchy or the absolute bottom; the chronological violation tracker (pred vs root) catches it exactly when it appears in the sequence.
### 💡 Code Adjustment for Safety
To make this code completely bulletproof against edge cases where the input tree might already be valid (no nodes swapped), you should wrap the final swap call in a quick null check:
java // Prevents an accidental NullPointerException or unnecessary execution if the tree is already correct if (x != null && y != null) {     swap(x, y); }  
Algorithm: Iterative inorder traversal, Recursion
Optimisation : Morris Inorder Traversal
Code: public void recoverTree(TreeNode root) {
// -------------------------------------------------------------------------
// INITIALIZATION PHASE
// -------------------------------------------------------------------------
// 'x' and 'y' will store references to the two swapped nodes.
// 'pred' acts as our chronological memory, saving the node visited right before 'root'.
// 'predecessor' is our structural scout used to look ahead and link subtrees.
TreeNode x = null, y = null, pred = null, predecessor = null;

while (root != null) {

// =========================================================================
// STRUCTURAL CASE 1: THE CURRENT NODE HAS A LEFT SUBTREE
// =========================================================================
// If a left child exists, we cannot process 'root' yet. We must process
// the left subtree first. But before moving left, we need to build a path back.
if (root.left != null) {

// Step A: Find the Morris Predecessor
// Move one step left into the subtree...
predecessor = root.left;
// ...then run completely down the right side of this subtree.
// The loop stops if it hits a dead end (null) OR if it encounters a link
// we already created in a past iteration (predecessor.right == root).
while (predecessor.right != null && predecessor.right != root) {
predecessor = predecessor.right;
}

// Step B: TIMELINE 1 - Setting up the Morris Link (First Time Here)
// If the right pointer of the scout is null, we have never linked this node.
// This is our first time seeing 'root'.
if (predecessor.right == null) {
predecessor.right = root; // Create the temporary Morris Link (bridge back up)
root = root.left;         // Structural Move: Dive deeper into the left subtree
}

// Step C: TIMELINE 2 - Breaking the Morris Link (Second Time Here)
// If predecessor.right == root, it means we already explored the left subtree,
// hit a leaf node, and used our temporary link to climb back up to this 'root'.
else {
// -----------------------------------------------------------------
// [TRACKING PHASE: VISIT THE NODE]
// -----------------------------------------------------------------
// The left side is done. We are standing on 'Root' (Left -> ROOT -> Right).
// Check if the true sorted order is broken:
if (pred != null && root.val < pred.val) {
y = root;            // 'y' captures the lower value (the dip in sequence)
if (x == null) x = pred; // 'x' captures the higher value (the peak)
}
pred = root;             // Chronological Move: 'root' becomes the 'true predecessor' for the next step

// -----------------------------------------------------------------
// [CLEANUP PHASE & STRUCTURAL MOVE]
// -----------------------------------------------------------------
predecessor.right = null; // Destroy the Morris Link to keep the tree pure and unmodified
root = root.right;        // Structural Move: Left and Root are done; now explore right
}
}

// =========================================================================
// STRUCTURAL CASE 2: THE CURRENT NODE HAS NO LEFT SUBTREE
// =========================================================================
// If there is no left child, there is nothing to explore on the left.
// According to inorder rules, we process the node immediately (ROOT -> Right).
else {
// ---------------------------------------------------------------------
// [TRACKING PHASE: VISIT THE NODE]
// ---------------------------------------------------------------------
// Check if the current node value violates the sorted order compared to 'pred'.
if (pred != null && root.val < pred.val) {
y = root;
if (x == null) x = pred;
}
pred = root;                 // Chronological Move: Update 'true predecessor' history

// ---------------------------------------------------------------------
// [STRUCTURAL MOVE]
// ---------------------------------------------------------------------
// Move right. If this node is a leaf, 'root.right' might actually be a
// temporary Morris Link we made earlier, pulling us automatically up to a parent.
root = root.right;
}
}

// =========================================================================
// POST-TRAVERSAL RESOLUTION
// =========================================================================
// The loop completely terminates once 'root' hits null.
// The Morris traversal guarantees that all temporary threads have been broken,
// meaning the tree's architecture is perfectly intact. Now, fix the error:
swap(x, y);
}

Dry run: /*
================================================================================
DRY RUN ANALYSIS
================================================================================
Input Swapped Tree Structure:
3  <-- root
/ \
2   6
/ \ / \
1  4 5  7
^
(should be 3)

Expected Sorted Order: [1, 2, 3, 4, 5, 6, 7]
Actual Visited Order:  [1, 2, 4, 3, 5, 6, 7]  --> Violation at 4 -> 3!

Pointers tracked below:
- root: The active node explorer
- pred: The "true predecessor" (the node processed immediately before root)
- predecessor: The "Morris predecessor" (scout used to map paths and threads)
================================================================================

Iteration 1:
• State: root = node(3), pred = null, x = null, y = null
• Branch: Outer 'if (root.left != null)'
-> Morris Predecessor scout starts at node(2), walks right to node(4).
-> Inner 'if (predecessor.right == null)' triggers:
- Sets Morris Link: node(4).right = node(3)
- Moves root left: root = node(2)

Iteration 2:
• State: root = node(2), pred = null
• Branch: Outer 'if (root.left != null)'
-> Morris Predecessor scout starts at node(1). Stops immediately.
-> Inner 'if (predecessor.right == null)' triggers:
- Sets Morris Link: node(1).right = node(2)
- Moves root left: root = node(1)

Iteration 3:
• State: root = node(1), pred = null
• Branch: Outer 'else' (No left child)
-> [VISIT NODE]: pred is null, violation skipped.
-> Updates history: pred = node(1)
-> Moves right via Morris Link: root = node(2)

Iteration 4:
• State: root = node(2), pred = node(1)
• Branch: Outer 'if (root.left != null)'
-> Scout finds existing Morris Link (predecessor.right == root).
-> Inner 'else' (Break link) triggers:
- [VISIT NODE]: Checks (2 < 1) -> False.
- Updates history: pred = node(2)
- Cleans up: node(1).right = null
- Moves right: root = node(4)

Iteration 5:
• State: root = node(4), pred = node(2)
• Branch: Outer 'else' (node 4 has no left child)
-> [VISIT NODE]: Checks (4 < 2) -> False.
-> Updates history: pred = node(4)
-> Moves right via Morris Link: root = node(3)

Iteration 6:
• State: root = node(3), pred = node(4)
• Branch: Outer 'if (root.left != null)'
-> Scout finds existing Morris Link (node(4).right == node(3)).
-> Inner 'else' (Break link) triggers:
- [VISIT NODE]: Checks (3 < 4) -> 🚨 TRUE! Violation found!
* y = root -> node(3)
* x is null -> x = pred -> node(4)
- Updates history: pred = node(3)
- Cleans up: node(4).right = null
- Moves right: root = node(6)

Iteration 7:
• State: root = node(6), pred = node(3)
• Branch: Outer 'if (root.left != null)'
-> Morris Predecessor scout starts at node(5). Stops immediately.
-> Inner 'if (predecessor.right == null)' triggers:
- Sets Morris Link: node(5).right = node(6)
- Moves root left: root = node(5)

Iteration 8:
• State: root = node(5), pred = node(3)
• Branch: Outer 'else' (No left child)
-> [VISIT NODE]: Checks (5 < 3) -> False.
-> Updates history: pred = node(5)
-> Moves right via Morris Link: root = node(6)

Iteration 9:
• State: root = node(6), pred = node(5)
• Branch: Outer 'if (root.left != null)'
-> Scout finds existing Morris Link (node(5).right == node(6)).
-> Inner 'else' (Break link) triggers:
- [VISIT NODE]: Checks (6 < 5) -> False.
- Updates history: pred = node(6)
- Cleans up: node(5).right = null
- Moves right: root = node(7)

Iteration 10:
• State: root = node(7), pred = node(6)
• Branch: Outer 'else' (No left child)
-> [VISIT NODE]: Checks (7 < 6) -> False.
-> Updates history: pred = node(7)
-> Moves right: root = null

Termination & Swap:
• Loop

Complexity: Complexity Analysis
• Time complexity : O(N) since we visit each node up to two times.
• Space complexity : O(1).
follow up questions: "What happens if the Binary Search Tree contains duplicate values?"
 Answer: The strict inequality check ⁠root.val < pred.val⁠ would need to be carefully updated to ⁠root.val <= pred.val⁠ depending on how duplicates are defined structural-wise (e.g., left vs. right placement).
2. "How does the time complexity change compared to a standard recursion approach?"
 Answer: Both are O(N) time. However, Morris Traversal visits nodes with left subtrees exactly twice (once to build the link, once to break it). While it technically takes more instruction cycles, its asymptotic time complexity remains perfectly linear (O(N)), while dropping memory down to O(1).
3. "How would you adapt this exact code to print the nodes in Preorder instead of Inorder?"
 Answer: You would move the [VISIT NODE PHASE] block out of the inner ⁠else⁠ and place it directly inside the ⁠if (predecessor.right == null)⁠ block, right before you move ⁠root = root.left⁠. That way, you process the root before diving into the left subtree.
Visualisation: https://claude.ai/share/f5c1677c-2cbb-474d-9028-16d28bdb04c0
Claude link: https://claude.ai/share/f5c1677c-2cbb-474d-9028-16d28bdb04c0
Similar questions (1): Here are the direct LeetCode links to practice these problems:  * **Binary Tree Inorder Traversal:** leetcode.com/problems/binary-tree-inorder-traversal/  * **Validate Binary Search Tree:** leetcode.com/problems/validate-binary-search-tree/  * **Convert Binary Search Tree to Sorted Doubly Linked List:** leetcode.com/problems/convert-binary-search-tree-to-sorted-doubly-linked-list/ *(Note: This is a Premium/Company-tagged track problem, but a highly requested senior engineering pattern.)*
Reusable template: ACTUAL MORRIS INORDER TRAVERSAL

public List<Integer> morrisInorderTraversal(TreeNode root) {
List<Integer> result = new ArrayList<>();
TreeNode current = root;

while (current != null) {

// CASE 1: Left child exists
if (current.left != null) {
// Find the inorder predecessor (rightmost node in left subtree)
TreeNode predecessor = current.left;
while (predecessor.right != null && predecessor.right != current) {
predecessor = predecessor.right;
}

// Timeline A: First time visiting 'current'. Build the temporary link.
if (predecessor.right == null) {
predecessor.right = current;
current = current.left; // Keep diving left
}
// Timeline B: Second time here. The link already exists!
else {
predecessor.right = null; // Clean up the bridge
result.add(current.val);  // [VISIT THE ROOT]
current = current.right;  // Now safe to move right
}
}

// CASE 2: No left child exists
else {
result.add(current.val);      // [VISIT THE ROOT]
current = current.right;      // Move right (might follow a bridge up)
}
}

return result;
}

© 2026 Vidya Srinivasa Kesarla. All rights reserved.