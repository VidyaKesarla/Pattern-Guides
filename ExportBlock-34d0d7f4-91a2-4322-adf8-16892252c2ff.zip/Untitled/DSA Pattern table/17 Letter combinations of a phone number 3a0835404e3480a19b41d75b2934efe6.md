# 17. Letter combinations of a phone number

Difficulty: Medium
Input Data Structure: String
Pattern trigger(recognition) / constraints hint / : return all possible letter combinations 
Signal / Paraphrase hint: return all possible letter combinations 
Constraints: Constraints:
• 1 <= digits.length <= 4
• digits[i] is a digit in the range ['2', '9'].
Intuition: https://leetcode.com/problems/letter-combinations-of-a-phone-number/editorial/#approach-1-backtracking

* ============================================================
*  INTUITION
* ============================================================
*
* Think of the phone keypad as a decision tree. At each level
* of the tree you pick one letter for one digit. After picking
* a letter you move to the next digit (go deeper). Once you
* have picked a letter for every digit, you have a complete
* combination — save it and come back (backtrack) to try the
* next letter.
*
* The pattern at every node is:
*   1. Append a letter  → make a choice
*   2. Recurse          → explore that choice fully
*   3. DeleteCharAt     → undo the choice (backtrack)
*
* A single shared StringBuilder acts as a scratchpad. Undo is
* O(1) via deleteCharAt, which is why StringBuilder is
* preferred over String concatenation here.
Algorithm: Brute force
Optimisation : Backtracking
Code: class Solution {
private List<String> combinations = new ArrayList<>();
private Map<Character, String> letters = Map.of(
'2', "abc", '3', "def", '4', "ghi", '5', "jkl",
'6', "mno", '7', "pqrs", '8', "tuv", '9', "wxyz"
);
private String phoneDigits;

public List<String> letterCombinations(String digits) {
if (digits.length() == 0) return combinations;
phoneDigits = digits;
backtrack(0, new StringBuilder());
return combinations;
}

private void backtrack(int index, StringBuilder path) {
if (path.length() == phoneDigits.length()) {
combinations.add(path.toString());
return;
}
String possibleLetters = letters.get(phoneDigits.charAt(index));
for (char letter : possibleLetters.toCharArray()) {
path.append(letter);
backtrack(index + 1, path);
path.deleteCharAt(path.length() - 1);
}
}
}

Dry run: ============================================================
*  DRY RUN  (digits = "23")
* ============================================================
*
*  Mapping:  '2' → "abc"   '3' → "def"
*
*  letterCombinations("23")
*  └─ backtrack(0, "")          charAt(0)='2' → "abc"
*     ├─ append 'a' → path="a"
*     │  backtrack(1, "a")      charAt(1)='3' → "def"
*     │  ├─ append 'd' → "ad"
*     │  │  backtrack(2,"ad")   length(2)==length(2) ✓ → add "ad"
*     │  │  return; deleteCharAt → "a"
*     │  ├─ append 'e' → "ae"
*     │  │  backtrack(2,"ae")   → add "ae"
*     │  │  return; deleteCharAt → "a"
*     │  └─ append 'f' → "af"
*     │     backtrack(2,"af")   → add "af"
*     │     return; deleteCharAt → "a"
*     │  ← return (all of "def" exhausted)
*     │  deleteCharAt → ""
*     │
*     ├─ append 'b' → path="b"
*     │  backtrack(1, "b")      charAt(1)='3' → "def"
*     │  ├─ "bd" → add "bd"
*     │  ├─ "be" → add "be"
*     │  └─ "bf" → add "bf"
*     │  deleteCharAt → ""
*     │
*     └─ append 'c' → path="c"
*        backtrack(1, "c")      charAt(1)='3' → "def"
*        ├─ "cd" → add "cd"
*        ├─ "ce" → add "ce"
*        └─ "cf" → add "cf"
*        deleteCharAt → ""
*
*  Final combinations: ["ad","ae","af","bd","be","bf","cd","ce","cf"]
*
*  Key observations in the trace:
*   - index acts as a pointer: index=0 → process digit '2',
*                                        index=1 → process digit '3'
*   - The base case fires when index reaches digits.length()
*   - Every path.deleteCharAt() call undoes exactly one append,
*     resetting the scratchpad for the next sibling branch
*
Complexity: ============================================================
*  COMPLEXITY ANALYSIS
* ============================================================
*
*  Let N = number of digits, M = max letters per digit (M = 4
*  for digits '7' and '9', M = 3 for all others).
*
*  Time:  O(M^N × N)
*    - The recursion tree has M^N leaf nodes (one per combination).
*    - At each leaf, path.toString() copies N characters → O(N).
*    - Internal append/deleteCharAt calls are O(1) each and are
*      dominated by the leaf work.
*    - Total: O(M^N × N)
*
*  Space: O(M^N × N)  [total]  /  O(N)  [auxiliary only]
*    - Output list stores M^N strings of length N → O(M^N × N).
*    - The StringBuilder holds at most N characters at any time.
*    - The call stack goes at most N frames deep.
*    - Auxiliary (excluding output): O(N)
*
*  This exponential complexity is unavoidable — you must
*  generate all M^N combinations, so no algorithm can do better.
*
follow up questions: ============================================================
*  TRADE-OFFS
* ============================================================
*
*  StringBuilder vs String concatenation
*    Using a StringBuilder with deleteCharAt gives O(1) undo at
*    each backtrack step. Concatenating immutable Strings would
*    allocate a new object at every recursive call → more GC
*    pressure and slightly worse constant factors, though the
*    asymptotic class stays the same.
*
*  Instance fields vs passing state as parameters
*    phoneDigits, letters, and combinations are stored as fields
*    rather than passed through every recursive call. This is
*    clean for a LeetCode-style class but makes the solution
*    non-thread-safe. In production you would pass them as
*    parameters or wrap in a local context object.
*
*  Recursion vs iteration
*    The recursive approach maps directly to the problem's
*    tree structure and is easy to reason about. An iterative
*    BFS approach (start with [""], then for each digit expand
*    every existing string by appending each mapped letter)
*    produces the same output with no call-stack overhead, but
*    requires storing all intermediate strings in a queue,
*    trading stack space for heap space.
*
*
* ============================================================
*  FOLLOW-UP QUESTIONS
* ============================================================
*
*  1. What if the input contains '0' or '1'?
*     Neither maps to any letters on a standard keypad. The
*     current solution would throw a NullPointerException because
*     letters.get('0') returns null. Guard by skipping unmapped
*     digits or returning an empty list early.
*
*  2. What if digits can be empty?
*     Already handled — the early return at the top of
*     letterCombinations returns an empty list immediately.
*
*  3. Can you solve this iteratively?
*     Yes. BFS / queue-based approach:
*
*       Queue<String> q = new LinkedList<>(List.of(""));
*       for (char d : digits.toCharArray()) {
*           int size = q.size();
*           while (size-- > 0) {
*               String curr = q.poll();
*               for (char c : letters.get(d).toCharArray())
*                   q.add(curr + c);
*           }
*       }
*       return new ArrayList<>(q);
*
*     Same time complexity. Avoids recursion overhead but stores
*     all partial strings in the queue simultaneously.
*
*  4. How would you return combinations in lexicographic order?
*     The current solution already produces lexicographic order
*     because the letter strings ("abc", "def", …) are defined
*     in sorted order and processed left to right.
*
*  5. How does this scale with longer inputs?
*     For N=4 digits all mapping to 3 letters: 3^4 = 81 combos.
*     For N=10: 3^10 ≈ 59,000. For N=20: ~3.5 billion — the
*     exponential blowup makes large N impractical to enumerate.
*     In such cases you would lazily generate combinations on
*     demand (using an iterator or generator pattern) rather than
*     collecting them all upfront.
Reusable template: class Solution {
public List<List<Integer>> solve(int[] input) {
List<List<Integer>> result = new ArrayList<>();
backtrack(new ArrayList<>(), input, 0, result);
return result;
}
private void backtrack(List<Integer> path, int[] input, int start,
List<List<Integer>> result) {
if (isSolution(path, input)) {
result.add(new ArrayList<>(path)); // save a COPY
// return; // omit if you want to keep exploring past a
// valid state (e.g. subsets)
}
for (int i = start; i < input.length; i++) {
if (!isValid(input[i], path)) continue; // pruning
path.add(input[i]); // choose
// mark_used(input[i]); // update state if needed
backtrack(path, input, i + 1, result); // explore
path.remove(path.size() - 1); // un-choose (undo)
// unmark_used(input[i]); // revert state if needed
}
}
private boolean isSolution(List<Integer> path, int[] input) { return false; }
private boolean isValid(int candidate, List<Integer> path) { return true; }
}

© 2026 Vidya Srinivasa Kesarla. All rights reserved.