# 958. Check Completeness of a Binary Tree

Difficulty: Medium
Input Data Structure: Array
Constraints: Constraints:
• The number of nodes in the tree is in the range [1, 100].
• 1 <= Node.val <= 1000
Algorithm: DFS
Optimisation : BFS
Why this is better? Optimisation details: https://leetcode.com/problems/check-completeness-of-a-binary-tree/
Rationale: Algorithm
1. There is no node in the given tree if the root node is null. We return true.
2. Create a boolean variable nullNodeFound to track whether or not a null node has been visited yet. We initialize it to false.
3. Intiailize a TreeNode queue q and push root into it.
4. While the queue is not empty:
    ◦ Dequeue the first element node from the queue.
    ◦ If node == null, mark nullNodeFound = true.
    ◦ Otherwise, if node is not null, we check to see if we have previously visited a null node. If nullNodeFound == true, it means we have node which is not null after visiting a null node. As a result, we return false in such a case. Otherwise, if we have not visited a null node yet, we push node.left and then node.right into the queue.
5. We are able to traverse the entire tree without seeing a non-null node after a null node, we return true.
Code: https://leetcode.com/problems/check-completeness-of-a-binary-tree/submissions/2016373251/
Dry run: /*
--------------------------------------------------------------------------------
STANDARD BFS (LEVEL-ORDER) DRY RUN
--------------------------------------------------------------------------------
The standard BFS approach processes nodes level-by-level from left to right using a
Queue. The fundamental rule for a complete binary tree in BFS is:
Once a NULL node is encountered, we must NOT see any valid non-null nodes after it.

Let's dry run this approach using the same valid complete binary tree:
1
/ \
2   3
/
4

Initialization:
- Queue = [1]
- seenNull = false

Iteration 1:
- Dequeue node: 1
- Node 1 is not null.
- Have we seen a null before? No (seenNull is false). Valid.
- Push children to Queue (including nulls): Queue = [2, 3]

Iteration 2:
- Dequeue node: 2
- Node 2 is not null.
- Have we seen a null before? No. Valid.
- Push children to Queue: Queue = [3, 4, null]

Iteration 3:
- Dequeue node: 3
- Node 3 is not null.
- Have we seen a null before? No. Valid.
- Push children to Queue: Queue = [4, null, null, null]

Iteration 4:
- Dequeue node: 4
- Node 4 is not null.
- Have we seen a null before? No. Valid.
- Push children to Queue: Queue = [null, null, null, null, null]

Iteration 5:
- Dequeue node: null
- Node is null! We flip our flag: seenNull = true.
- Queue = [null, null, null, null]

Remaining Iterations:
- The queue only contains null elements now.
- As each null is popped, the loop continues safely without triggering a failure because
no non-null node ever appears after seenNull became true.

The loop terminates cleanly, returning True. The tree is complete!

--------------------------------------------------------------------------------
WHY BFS IS BETTER FOR PRODUCTION
--------------------------------------------------------------------------------
1. Single Pass: It checks completeness on the fly without needing to calculate the
total node count beforehand.
2. Memory Safety: It completely eliminates the integer overflow risk present in the
$2 \cdot index + 1$ formula, making it safe for trees of any depth or skewness.
*/
Complexity: Here n is the number of nodes.
• Time complexity: O(n).
    ◦ Each queue operation in the BFS algorithm takes O(1) time, and a single node can only be pushed once, leading to O(n) operations for n nodes. Since we have directed edges, each edge can only be iterated once, resulting in O(e) operations total while visiting all nodes, where e is the number of edges. Because the given graph is a tree, there are n−1 edges, so O(n+e)=O(n).
• Space complexity: O(n).
    ◦ The last or second last level would have the most nodes (the last level can have multiple null nodes) in a complete binary tree. Because we are iterating by level, the BFS queue will be most crowded when all of the nodes from the last level (or second last level) are in the queue.
    ◦ Assume we have a complete binary tree with height h and a fully filled last level having 2h nodes. All the nodes at each level add up to 1+2+4+8+...+2h=n. This implies that 2h+1−1=n, and thus 2h=(n+1)/2. Because the last level h has 2h nodes, the BFS queue will have (n+1)/2=O(n) elements in the worst-case scenario.

© 2026 Vidya Srinivasa Kesarla. All rights reserved.