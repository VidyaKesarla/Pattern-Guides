# 35. Search insert position

Difficulty: Easy
Input Data Structure: Sorted array
Pattern trigger(recognition) / constraints hint / : “Sorted”
”Search” in question 
Expected time complexity is Ologn 
Signal / Paraphrase hint: “Sorted”
”Search” in question 
Expected time complexity is Ologn 
Clarifying questions: Sure it’s sorted?
Do we have negative elements?
Does it contain duplicate elements?
Can the array be empty?
Is it guaranteed that the elements are integers not floats/double?

Constraints: Constraints:
• 1 <= nums.length <= 104
• -104 <= nums[i] <= 104
• nums contains distinct values sorted in ascending order.
• -104 <= target <= 104
Brute force code and its trade off: Linear search
Intuition: https://leetcode.com/problems/search-insert-position/editorial/#approach-1-binary-search
Edge cases / base cases: Here’s how an interviewer would typically answer these for this classic problem (LeetCode 35 - Search Insert Position):
About the input:
• Sorted? Yes, nums is guaranteed to be sorted in ascending order.
• Duplicates? No, all elements in nums are distinct (unique values only). So you don’t need to worry about “leftmost occurrence” — there’s only one occurrence.
• Empty array? Yes, it’s possible (though rare in this problem’s constraints, usually nums.length >= 1). If empty, return 0 since that’s the only valid insert position.
• Data type? Integers only.
• Negative numbers? Yes, allowed. Standard constraint is something like -10^4 <= nums[i] <= 10^4.
About the target:
• Target smaller/larger than all elements? Yes, both are valid cases — expect insert position 0 (smaller than everything) or nums.length (larger than everything). Your code handles both correctly already.
• Overflow? Not a concern in Java with the given constraints (int range is sufficient, and using left + (right-left)/2 already avoids overflow issues that (left+right)/2 could cause with large arrays).
About constraints/performance:
• Array size? Typically up to 10^4 elements.
• Time/space complexity? O(log n) time is expected — that’s why binary search is required over a simple linear scan (O(n)), which would technically work but wouldn’t meet the expected efficiency bar in an interview setting.
About output:
• Target exists in array? Return its exact index (since no duplicates, this is unambiguous).


Bottom line: since duplicates aren’t allowed and the array is always sorted, your original solution is already fully correct and optimal — no changes needed. This is actually one of the cleaner “vanilla” binary search problems, which is likely why it’s often used as a warm-up interview question before moving to trickier variants (like “Find First and Last Position of Element in Sorted Array”, which does involve duplicates and requires modified binary search logic).
Algorithm: Linear search
Optimisation : Binary search
Code: class Solution {
public int searchInsert(int[] nums, int target) {
int left = 0;
int right = nums.length - 1;
while(left <= right){
int mid = left + (right - left)/2;
if(nums[mid] == target){
return mid;
} else if (nums[mid] > target) {
right = mid - 1;
} else {
left = mid + 1;
}
}
return left;
}
}

Dry run: Here’s a dry run using nums = [1, 3, 5, 6], target = 5:
Initial: left = 0, right = 3
Iteration 1:
• mid = 0 + (3-0)/2 = 1
• nums[1] = 3, target = 5 → 3 < 5 → go right
• left = mid + 1 = 2
Iteration 2:
• left = 2, right = 3
• mid = 2 + (3-2)/2 = 2
• nums[2] = 5 → matches target!
• return 2


Now let’s dry run a case where the target isn’t found, nums = [1, 3, 5, 6], target = 2:
Initial: left = 0, right = 3
Iteration 1:
• mid = 1, nums[1] = 3, target = 2 → 3 > 2 → go left
• right = mid - 1 = 0
Iteration 2:
• left = 0, right = 0
• mid = 0, nums[0] = 1, target = 2 → 1 < 2 → go right
• left = mid + 1 = 1
Loop ends: left (1) > right (0), so exit while loop
• return left = 1 (correct insert position — 2 would go between index 0 and 1)


Summary of logic:
• Standard binary search.
• If target is found, return its index directly.
• If not found, the loop ends when left > right. At that point, left naturally lands exactly at the index where target should be inserted to keep the array sorted, because:
    ◦ right ends up pointing to the last element smaller than target
    ◦ left ends up pointing to the first element greater than target

Complexity: - Time Complexity: O(log n)
- Space Complexity: O(1)

© 2026 Vidya Srinivasa Kesarla. All rights reserved.