# 886. Possible bipartition

Difficulty: Medium
Input Data Structure: 2D Array
Pattern trigger(recognition) / constraints hint / : Two Distinct Groups: The core objective is to divide a set of elements (people, objects, nodes) into exactly two independent groups.
 Mutual Exclusivity / Constraints: Elements that have a relationship (e.g., "dislike each other," "cannot work together," "are enemies") cannot be in the same group.
 Graph Structure: The relationships can be modeled as pairs (an edge list like ⁠dislikes = [[1, 2], [2, 3]]⁠).
 No Odd Length Cycles: Mathematically, a graph is bipartite if and only if it does not contain an odd-length cycle (e.g., A dislikes B, B dislikes C, C dislikes A \rightarrow impossible to split into 2 groups)
Signal / Paraphrase hint: "Possible Bipartition" / "Is Graph Bipartite?" (Direct graph phrasing)
Clarifying questions: 1. Graph Characteristics & Constraints
 Are there isolated nodes? * Context: The problem states we have N people, but some might not be mentioned in the ⁠dislikes⁠ list at all.
 Code Handling: The code handles this perfectly via the ⁠for (int i = 1; i <= n; i++)⁠ loop and the ⁠if (!adj.containsKey(node)) continue;⁠ check inside the BFS. Isolated nodes are safely ignored or treated as their own valid component.
 Can there be self-dislikes or duplicate edges?
 Context: If a person dislikes themselves (⁠[1, 1]⁠), a bipartition is impossible. If duplicate edges exist (⁠[1, 2]⁠ and ⁠[1, 2]⁠), it shouldn't break the logic but might add redundant processing.
 Is the graph guaranteed to be connected?
 Context: No. This is why the external ⁠for⁠ loop in ⁠possibleBipartition⁠ is mandatory. Running BFS just once from node ⁠1⁠ would fail to check other disconnected groups of people.
2. Input / Data Structure Bounds
 Is the input 0-indexed or 1-indexed?
 Context: In this specific problem, people are labeled from ⁠1⁠ to ⁠n⁠. That is why the color array is initialized to size ⁠n + 1⁠ (⁠int[] color = new int[n + 1]⁠), and the loop starts at ⁠i = 1⁠. If the interviewer shifts the problem to 0-indexed, your array sizing and loop boundaries must shift accordingly.
 What are the maximum values for N and ⁠dislikes.length⁠?
 Context: If N is up to 2 \times 10^3 and dislikes are up to 10^4, this O(V + E) BFS approach is highly optimal. However, if space is at an extreme premium, an iterative DFS or a Disjoint Set Union (DSU) / Union-Find approach might be discussed as memory-optimized alternatives.
Constraints: Constraints:
• 1 <= n <= 2000
• 0 <= dislikes.length <= 104
• dislikes[i].length == 2
• 1 <= ai < bi <= n
• All the pairs of dislikes are unique.
Intuition: Our task is to figure out whether we can divide the nodes (i.e., people) into two sets such that there aren't any edges between nodes in the same set. Intuitively, we can think of starting a traversal over such a graph. We can put the first node into the first set and all the neighbors of the node into the second set. Now, we can move one step further to the neighbours and put their neighbours in the first set. We can perform the same process to keep alternating sets between neighbors. We can use a breadth-first search traversal to assign the set to each of the nodes.
A breadth-first search (BFS) is an algorithm for traversing or searching a graph. It traverses in a level-wise manner, i.e., all the nodes at the present level (say l) are explored before moving on to the nodes at the next level (l + 1), where a level's number is the distance from a starting node. BFS is implemented with a queue.
If you are not familiar with BFS traversal, we suggest you read our https://leetcode.com/explore/featured/card/graph/620/breadth-first-search-in-graph/.
Our task is to split the nodes into two sets such that there aren't any edges between the nodes of the same set. Let's start by giving a unique identification/color to both groups. To distinguish them, we can use two colors, say, RED and BLUE. We need to assign a color to each node in such a way that all its neighbors (nodes that share an edge) do not have that color. Otherwise, it would result in a conflict.
To solve this problem, we can start a BFS traversal over the graph of people and start assigning the colors. We can assign RED to the starting node (it doesn't matter which color we choose for the first node). The color BLUE should then be assigned to all of the neighbors. Neighbors of BLUE nodes should have the color RED, and so on (keep alternating colors between neighbors). In the implementation, we can use a number to identify each color. Let's use 0 for RED and 1 for BLUE.
To flip the colors, we can use the formula 1 - color. If we are at a RED node, then 1 - color = 1 - 0 = 1 = BLUE. If we are at a BLUE node, then 1 - color = 1 - 1 = 0 = RED.
There can be multiple connected components in the graph. We need to visit all of them to make sure we visit every node. In a single BFS traversal, we will visit all the nodes present in one connected component and color each of them accordingly. Here's an example of a successful split and an unsuccessful split of a graph having three components each:
Edge cases / base cases: When designing or testing code for the Possible Bipartition / Graph Bipartiteness pattern, you must consider several edge cases and base cases. These scenarios test the resilience of your graph construction, traversal logic, and array indexing.
### 1. Base Cases (Minimum Inputs)
* N = 1 (A single vertex, no dislikes):
* Scenario: n = 1, dislikes = []
* Expectation: true. A single person can easily be placed into one of the two groups.
* Code Evaluation: The code allocates a color array of size 2, skips the BFS loop because adj is empty, and correctly returns true.
* No Constraints / Dislikes array is empty:
* Scenario: n = 5, dislikes = []
* Expectation: true. Everyone can be put into the same group (or split arbitrarily), as there are no conflicts.
* Code Evaluation: The adjacency map stays empty. The loop visits 1 to N, finds no neighbors, and returns true.
### 2. Graph Topology Edge Cases
* Disconnected Graph (Multiple Components):
* Scenario: Group A has conflicts [[1, 2]], and Group B has conflicts [[3, 4], [4, 5], [5, 3]]. Group B contains an odd cycle, while Group A is fine.
* Expectation: false. Even if part of the graph is valid, a conflict anywhere makes the whole configuration invalid.
* Code Evaluation: Handled. The outer for (int i = 1; i <= n; i++) loop ensures that every independent island/component gets evaluated. When it hits node 3, the BFS will uncover the odd cycle and return false.
* Isolated Nodes (Nodes with 0 degree):
* Scenario: n = 4, dislikes = [[1, 2], [2, 3]]. Node 4 has no connections.
* Expectation: true. Node 4 can belong to either group safely.
* Code Evaluation: Handled. When i = 4, color[4] is -1. It enters bfs(4). Inside BFS, !adj.containsKey(4) triggers, the queue empties, and it returns true.
### 3. Structural & Cycle Edge Cases
* Odd-Length Cycles (The Core Failure Condition):
* Scenario: A triangle relationship: [[1, 2], [2, 3], [3, 1]].
* Expectation: false. It is mathematically impossible to separate 3 mutually conflicting nodes into 2 groups.
* Code Evaluation: Handled. Node 1 is colored 0. Node 2 becomes 1. Node 3 becomes 0. When checking Node 3's neighbors, it sees Node 1 also has color 0. The trigger color[neighbor] == color[node] matches, returning false.
* Even-Length Cycles:
* Scenario: A square relationship: [[1, 2], [2, 3], [3, 4], [4, 1]].
* Expectation: true. Group 1: {1, 3}, Group 2: {2, 4}.
* Code Evaluation: Handled. Colors will alternate cleanly: 1(0) -> 2(1) -> 3(0) -> 4(1). When checking back to 1, 4 (color 1) and 1 (color 0) do not conflict.
### 4. Input Anomalies (Interview "Gotchas")
* Self-Loops (A person dislikes themselves):
* Scenario: dislikes = [[1, 1]]
* Expectation: false. A node cannot be in a different group than itself.
* Code Evaluation: Handled. Node 1 will be added as its own neighbor. During BFS, it will process neighbor 1, see that color[1] == color[1], and immediately return false.
* Parallel/Duplicate Edges:
* Scenario: dislikes = [[1, 2], [1, 2]] (The same dislike is reported twice).
* Expectation: true (assuming no other conflicts exist).
* Code Evaluation: Handled, but inefficient. Node 2 will be added to Node 1's neighbor list twice. The first time, it gets colored. The second time, the code checks if (color[neighbor] == -1), which skips it because it's already colored. It doesn't break, but wasting space/time on duplicate edges is a great thing to point out to an interviewer.

Optimisation : BFS
Code: class Solution {
public boolean bfs(int source, Map<Integer, List<Integer>> adj, int[] color) {
Queue<Integer> q = new LinkedList<>();
q.offer(source);
color[source] = 0; // Start with marking source as RED.

while (!q.isEmpty()) {
int node = q.poll();
if (!adj.containsKey(node))
continue;
for (int neighbor : adj.get(node)) {
if (color[neighbor] == color[node])
return false;
if (color[neighbor] == -1) {
color[neighbor] = 1 - color[node];
q.add(neighbor);
}
}
}
return true;
}

public boolean possibleBipartition(int n, int[][] dislikes) {
Map<Integer, List<Integer>> adj = new HashMap<>();
for (int[] edge : dislikes) {
int a = edge[0], b = edge[1];
adj.computeIfAbsent(a, value -> new ArrayList<Integer>()).add(b);
adj.computeIfAbsent(b, value -> new ArrayList<Integer>()).add(a);
}

int[] color = new int[n + 1];
Arrays.fill(color, -1); // 0 stands for red and 1 stands for blue.

for (int i = 1; i <= n; i++) {
if (color[i] == -1) {
// For each pending component, run BFS.
if (!bfs(i, adj, color))
// Return false, if there is conflict in the component.
return false;
}
}
return true;
}
}
Dry run: /*
======================================================================
DRY RUN / WALKTHROUGH
======================================================================
Input Example:
n = 3
dislikes = [[1, 2], [2, 3], [3, 1]] (An odd-length cycle / Triangle)

----------------------------------------------------------------------
STEP 1: Graph Construction (Adjacency List)
----------------------------------------------------------------------
Map adj becomes:
1 -> [2, 3]
2 -> [1, 3]
3 -> [2, 1]

----------------------------------------------------------------------
STEP 2: Variable Initialization
----------------------------------------------------------------------
color array (size 4, 1-indexed):
idx:    0   1   2   3
color: [-1, -1, -1, -1]  (-1 means uncolored)

----------------------------------------------------------------------
STEP 3: Component Loop Execution
----------------------------------------------------------------------
Loop starts at i = 1:
color[1] == -1, so we trigger bfs(1, adj, color)

Inside bfs(1):
- Queue q initialized: []
- Push source: q = [1]
- Color source RED (0): color = [-1, 0, -1, -1]

--- BFS Iteration 1 ---
- Poll node = 1. q = []
- Fetch neighbors of 1: [2, 3]

Neighbor 2:
- color[2] is -1 (uncolored).
- Color it BLUE (1 - color[1] = 1 - 0 = 1).
- color = [-1, 0, 1, -1]
- Push to queue: q = [2]

Neighbor 3:
- color[3] is -1 (uncolored).
- Color it BLUE (1 - color[1] = 1 - 0 = 1).
- color = [-1, 0, 1, 1]
- Push to queue: q = [2, 3]

--- BFS Iteration 2 ---
- Poll node = 2. q = [3]
- Fetch neighbors of 2: [1, 3]

Neighbor 1:
- color[1] is 0, color[2] is 1. They are different. Skip.

Neighbor 3:
- color[3] is 1, color[2] is 1.
- CRITICAL TRIGGER! color[neighbor] == color[node] (1 == 1)
- CONFLICT FOUND: Two adjacent nodes have the exact same color!
- Returns false immediately.

----------------------------------------------------------------------
STEP 4: Termination
----------------------------------------------------------------------
- The possibleBipartition loop catches the false returned from BFS.
- Final Return Value: false (Correct, a triangle cannot be 2-colored).
======================================================================
*/

Complexity: Complexity Analysis
Let E be the size of dislikes and N be the number of people.
• Time complexity: O(N+E)
    ◦ Each node is only queued once, which takes O(1) time for each node. We also iterate over the edges of every node once (since we only visit each node once, we won't iterate over a node's edges multiple times), which adds O(E) time.
    ◦ We also need O(E) to initialize the adjacency list and O(N) to initialize the color array.
• Space complexity: O(N+E)
    ◦ In the worst case, the queue can grow to a size linear with N.
    ◦ We also require O(E) and O(N) space for the adjacency list and the color array respectively.
follow up questions: Here are the standard follow-up questions an interviewer will likely ask after you present this BFS solution, along with guidance on how to answer them.
### 1. Complexity Analysis
* Question: "What is the Time and Space complexity of your solution?"
* Answer:
* Time Complexity: \mathcal{O}(V + E), where V is the number of vertices (n) and E is the number of edges (dislikes.length). We visit every vertex and traverse every edge exactly once.
* Space Complexity: \mathcal{O}(V + E). The color array takes \mathcal{O}(V), the BFS queue takes at most \mathcal{O}(V), and building the explicit adjacency list map takes \mathcal{O}(V + E) space.
### 2. Can you optimize the Space Complexity?
* Question: "Building the explicit Adjacency List map takes up a lot of extra object overhead in Java. Can we do this without a Map or even without the graph construction step?"
* Answer: * Yes. Instead of a Map<Integer, List<Integer>>, you can use an array of lists: List<Integer>[] adj = new ArrayList[n + 1]. This eliminates object overhead and drastically speeds up runtime.
* Alternatively, you can completely avoid building a graph by using Union-Find (Disjoint Set Union). For every pair [u, v], you union u with all previous enemies of v, and v with all previous enemies of u. If u and v ever share the same parent, a conflict is detected.
### 3. Deep-Dive on Alternative Traversal (DFS)
* Question: "How would you change this code to use Depth-First Search (DFS) instead of BFS? What are the structural tradeoffs?"
* Answer:
* Instead of a queue, you would use a recursive function. You pass the current node and its assigned color down the call stack. If a recursive call detects a neighbor with an identical color, it bubbles false all the way back up.
* Tradeoff: DFS removes the memory allocation for a Queue object, but it introduces danger of a StackOverflowError if the graph is extremely deep (e.g., a straight line of 10^5 nodes), whereas BFS handles deep graphs safely.
### 4. Generalizing to K Groups
* Question: "What if instead of splitting people into 2 groups, I ask you to split them into K groups (where K > 2)? Does this logic still work?"
* Answer:
* No, the alternating state logic (1 - color[node]) only works for 2-coloring.
* Checking if a graph can be split into K groups is known as the Graph Coloring Problem (or K-Coloring). For K = 2, it is solvable in linear time using this exact BFS/DFS pattern. For K \ge 3, the problem becomes NP-Complete, meaning no linear-time solution exists, and you would have to resort to backtracking with pruning or greedy approximation algorithms.
Would you like to explore the implementation for one of these follow-ups, such as the Union-Find optimization or the DFS approach?

Visualisation: https://claude.ai/share/61b490cb-5196-46a1-adbe-93635e45ce8b
Claude link: https://claude.ai/share/61b490cb-5196-46a1-adbe-93635e45ce8b

© 2026 Vidya Srinivasa Kesarla. All rights reserved.