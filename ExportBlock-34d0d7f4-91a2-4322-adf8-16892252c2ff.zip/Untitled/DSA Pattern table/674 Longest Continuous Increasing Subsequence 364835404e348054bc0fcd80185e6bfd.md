# 674. Longest Continuous Increasing Subsequence

Difficulty: Easy
Input Data Structure: Array
Constraints: 
• 1 <= nums.length <= 104
• -109 <= nums[i] <= 109
Algorithm: loop
Optimisation : loop

© 2026 Vidya Srinivasa Kesarla. All rights reserved.