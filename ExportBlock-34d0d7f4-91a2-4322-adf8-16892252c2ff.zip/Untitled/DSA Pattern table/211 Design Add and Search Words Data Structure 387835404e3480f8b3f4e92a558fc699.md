# 211. Design Add and Search Words Data Structure

Difficulty: Medium
Input Data Structure: Array of strings
Pattern trigger(recognition) / constraints hint / : Two levels to this — recognising the data structure and recognising the problem type.
The problem screams trie
- store a dictionary of words        → trie is built for this
- search with '.' wildcard           → need to traverse character by character
- match letter by letter             → trie's depth = characters matched
Any time you see “dictionary + character-by-character matching”, trie is the go-to instinct.
The constraints hint at it too
• Words are strings → natural fit for character-edge trees
• Wildcard needs flexibility at each character position → you need to branch per character, not per word
• If it were just exact search, a HashSet would do. The wildcard forces you deeper.
The “why not something else” checkStructureWhy it falls short hereHashSetCan’t handle . wildcardHashMap<len, words>Has to scan every word of that lengthTrieBranches at each character — wildcard just means “take all branches”

Signal / Paraphrase hint: The general trigger pattern
Trie problems usually mention one or more of:
- prefix matching (startsWith)
- wildcard / pattern matching
- autocomplete
- dictionary of words + search

When you see those — think trie first.
Constraints: Constraints:
• 1 <= word.length <= 25
• word in addWord consists of lowercase English letters.
• word in search consist of '.' or lowercase English letters.
• There will be at most 2 dots in word for search queries.
• At most 104 calls will be made to addWord and search.
Intuition: https://leetcode.com/problems/design-add-and-search-words-data-structure/editorial/#approach-1-trie
Algorithm: HashMap
Optimisation : Trie
Code: class TrieNode {
//children is a hashmap which contains character mapped to the node
Map<Character, TrieNode> children = new HashMap<>();
//a boolean variable which tells me that the word when searched exists in my trie
boolean word = false;

public TrieNode() {}
}

class WordDictionary {
TrieNode trie;
//initialised my data structure
public WordDictionary() {
trie = new TrieNode();
}

public void addWord(String word) {
//create a local reference of trie
TrieNode node = trie;

for(char ch: word.toCharArray()){
if(!node.children.containsKey(ch)){
node.children.put(ch, new TrieNode());
}
node = node.children.get(ch);
}
node.word = true;
}

public boolean searchInNode(String word, TrieNode node){
// i have to iteratte throughout the word
for(int i =0;i<word.length();i++){
char ch = word.charAt(i);
if(!node.children.containsKey(ch)){
if(ch == '.'){
for(char x: node.children.keySet()){
TrieNode child = node.children.get(x);
if(searchInNode(word.substring(i+1), child))
return true;
}
}
return false;
}
else {
node = node.children.get(ch);
}
}
return node.word;
}

public boolean search(String word) {
return searchInNode(word, trie);
}


}

/**
* Your WordDictionary object will be instantiated and called as such:
* WordDictionary obj = new WordDictionary();
* obj.addWord(word);
* boolean param_2 = obj.search(word);
*/
Dry run: https://claude.ai/share/b657069e-12fb-47cf-b3d2-20abab080b8c
Complexity: Complexity Analysis
• Time complexity: O(M), where M is the key length. At each step, we either examine or create a node in the trie. That takes only M operations.
• Space complexity: O(M). In the worst-case newly inserted key doesn't share a prefix with the keys already inserted in the trie. We have to add M new nodes, which takes O(M) space.

Complexity Analysis
• Time complexity: O(M) for the "well-defined" words without dots, where M is the key length, and N is a number of keys, and O(N⋅26M) for the "undefined" words. That corresponds to the worst-case situation of searching an undefined word M times.........which is one character longer than all inserted keys.
• Space complexity: O(1) for the search of "well-defined" words without dots, and up to O(M) for the "undefined" words, to keep the recursion stack.
Visualisation: https://claude.ai/share/b657069e-12fb-47cf-b3d2-20abab080b8c
Claude link: https://claude.ai/share/b657069e-12fb-47cf-b3d2-20abab080b8c

© 2026 Vidya Srinivasa Kesarla. All rights reserved.