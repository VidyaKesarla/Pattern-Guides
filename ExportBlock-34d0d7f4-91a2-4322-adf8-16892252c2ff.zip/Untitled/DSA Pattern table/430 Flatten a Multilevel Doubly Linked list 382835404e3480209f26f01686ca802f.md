# 430. Flatten a Multilevel Doubly Linked list

Difficulty: Medium
Input Data Structure: Array
Signal / Paraphrase hint: Here’s the underlying signal/pattern in one paraphrase:

The pattern: Whenever you flatten a nested structure into a single sequence by always going deeper before going sideways, you need somewhere to park the “sideways” step you’re postponing. A stack is the natural place, because the most recently postponed sideways move is exactly the first one you should resume once the current depth dead-ends. That’s just LIFO matching the natural order of recursive backtracking.

Restated abstractly: this is preorder DFS over a tree-shaped structure (child = go down a level, next = stay at the same level), flattened into a list. The recursive version gets this LIFO behavior for free from the call stack. The iterative version has to simulate that call stack explicitly — which is why you push next right before diving into child, and pop it back only when you hit a node with no next and no child of its own.

The reusable signal to recognize this pattern elsewhere: any time a problem says “traverse this, but some nodes branch off into a sub-structure you must fully consume before continuing,” and you’re asked to do it without recursion — that’s your cue to reach for an explicit stack holding “where to resume.” Same shape shows up in: flattening nested arrays/JSON, iterative tree preorder traversal, DOM traversal, parsing nested brackets, or even directory tree walks (when you enter a subdirectory, you push “where to come back to” and pop when the subdirectory is exhausted).
Clarifying questions: 
Worth asking (shows real signal):

1.	“Can I modify the existing nodes in place, or do I need to create new ones?” — changes whether you’re just relinking pointers (as in this solution) versus building a fresh structure.
2.	“Should the prev pointers also be correctly updated in the final flattened list, or only next?” — some interviewers only check the forward traversal; confirming this affects whether you bother with prev at all.
3.	“After flattening, should child pointers be set back to null, or is that not checked?” — relevant if there’s a validator that walks child afterward.
4.	“Can a node have a child but next == null?” — this is the one edge case that actually changes your code (whether you guard the push with a null check), so it’s worth surfacing explicitly rather than assuming.
5.	“Is recursion acceptable, or do you specifically want an iterative solution (e.g. because of stack depth concerns on deeply nested lists)?” — worth asking up front since it changes your whole approach, not just a tweak.

Skip these — they don’t change your approach, so asking them reads as filler:

•	“What if the list is empty?” — just state your assumption and move on (return null), don’t ask.
•	“What’s the max depth/size?” — only matters if you’re about to justify recursion vs. iteration, which you should already be doing on your own reasoning, not asking permission for.

A clean way to open: state your understanding in one sentence, then ask only the questions that would change your code. For example: “I’ll flatten this in place, treating it as a multilevel list where children get spliced in between a node and its original next — should I preserve prev pointers and clear child references on the way, or is only next checked?” That single question covers two of the contract-defining ones at once and shows you’ve already thought through the shape of the problem.
Constraints: Constraints:
• The number of Nodes will not exceed 1000.
• 1 <= Node.val <= 105
Brute force code and its trade off: /*
// Definition for a Node.
class Node {
public int val;
public Node prev;
public Node next;
public Node child;

public Node() {}

public Node(int _val,Node _prev,Node _next,Node _child) {
val = _val;
prev = _prev;
next = _next;
child = _child;
}
};
/
class Solution {
public Node flatten(Node head) {
if (head == null) return head;
// pseudo head to ensure the prev pointer is never none
Node pseudoHead = new Node(0, null, head, null);

flattenDFS(pseudoHead, head);

// detach the pseudo head from the real head
pseudoHead.next.prev = null;
return pseudoHead.next;
}
/ return the tail of the flatten list */
public Node flattenDFS(Node prev, Node curr) {
if (curr == null) return prev;
curr.prev = prev;
prev.next = curr;

// the curr.next would be tempered in the recursive function
Node tempNext = curr.next;

Node tail = flattenDFS(curr, curr.child);
curr.child = null;

return flattenDFS(tail, tempNext);
}
}
Intuition: Intuition
Following the intuition of the above DFS preorder traversal approach, here we demonstrate how one can implement the solution via iteration.The key is to use the data structure called stack, which is a container that follows the principle of LIFO (last in, first out). The element that enters the stack at last would come out first, similar with the scenario of a packed elevator.
The stack data structure helps us to construct the iteration sequence as the one created by recursion. The stack here mimics the behavior of the function call stack, so that we could obtain the same result without resorting to recursion.
Edge cases / base cases: Here are the edge cases worth checking, roughly in order of how often they trip people up:

Structural edge cases

•	head == null — return null immediately, don’t even enter the loop.
•	Single node, no child, no next — loop body does nothing, returns immediately.
•	Head itself has a child but no next — make sure the splice still works when curr.next was already null before you push it (you’d be pushing null onto the stack; the pop logic must treat that correctly or skip pushing nulls entirely).
•	Last node in a child branch has its own child (nested all the way down with no siblings at any level) — pure depth, stack still does the right thing, but it’s worth tracing to confirm you don’t accidentally pop too early.

Stack/pointer edge cases

•	A node has a child and next == null. In your iterative code, you only push curr.next if (curr.next != null). If you skip that guard and push null anyway, you’d later pop null and incorrectly attach it, breaking the list. Worth testing explicitly.
•	Multiple consecutive nodes each have children (chain of children at every node in a row) — stack depth grows by one each time without any pops in between, good test for “is my stack actually LIFO-correct.”
•	A child branch itself ends in a node whose next is non-null at the original level but that node also has a child — checks that you dive into child before resuming next, consistently.

Pointer correctness (often forgotten)

•	After flattening, every node’s prev pointer must be updated too, not just next. Easy to forget when focused on the next chain — test by walking backwards from the tail.
•	child pointers must be set to null on every node that had one, even after flattening. If you skip clearing this, the list “looks” flattened when printed forward but still has dangling child references that could break subsequent operations (e.g. a checker that asserts child == null everywhere).

Quick test list to run by hand or in code

1.	null head
2.	single node
3.	flat list, no children at all
4.	head has a child, head has no next
5.	deepest node has a child whose first node also immediately has a child (3+ levels deep)
6.	two siblings in the same row both have children
7.	child list has more than one node before its own nested child appears

If you want, I can add a “scenario picker” to the playground so you can flip between a few of these edge cases interactively instead of just the one example.
Algorithm: Recursion
Optimisation : Iterative DFS
Rationale: Algorithm
• First of all, we create a stack and then we push the head node to the stack. In addition, we create a variable called prev which would help us to track the precedent node at each step during the iteration.
• Then we enter a loop to iterate the stack until the stack becomes empty.
• Within the loop, at each step, we first pop out a node (named curr) from the stack. Then we establish the links between prev and curr. Then in the following steps, we take care of the nodes pointed by the curr.next and curr.child pointers respectively, and strictly in this order.
    ◦ First, if the curr.next does exist (i.e. there exists a right subtree), we then push the node into the stack for the next iteration.
    ◦ Secondly, if the curr.child does exist (i.e. there exists a left subtree), we then push the node into the stack. In addition, unlike the child.next pointer, we need to clean up the curr.child pointer since it should not be present in the final result.
• And voila. Lastly, we also employ the pseudoHead node to render the algorithm more elegant, as we discussed in the previous approach.
Code: /*
// Definition for a Node.
class Node {
public int val;
public Node prev;
public Node next;
public Node child;

public Node() {}

public Node(int _val,Node _prev,Node _next,Node _child) {
val = _val;
prev = _prev;
next = _next;
child = _child;
}
};
*/
class Solution {
public Node flatten(Node head) {
if (head == null) return head;

Node pseudoHead = new Node(0, null, head, null);
Node curr, prev = pseudoHead;

Deque<Node> stack = new ArrayDeque<>();
stack.push(head);

while (!stack.isEmpty()) {
curr = stack.pop();
prev.next = curr;
curr.prev = prev;

if (curr.next != null) stack.push(curr.next);
if (curr.child != null) {
stack.push(curr.child);
// don't forget to remove all child pointers.
curr.child = null;
}
prev = curr;
}
// detach the pseudo node from the result
pseudoHead.next.prev = null;
return pseudoHead.next;
}
}
Complexity: Complexity
• Time Complexity: O(N). The iterative solution has the same time complexity as the recursive.
• Space Complexity: O(N). Again, the iterative solution has the same space complexity as the recursive one.
follow up questions: 

1.	“Can you do this with O(1) extra space instead of using a stack?” — yes, there’s a Morris-traversal-style trick: instead of pushing next, you walk to the tail of the child branch (since you don’t have a stack to remember where to resume) and attach the saved next there directly. No stack, but you pay with an extra traversal to find each child’s tail.
2.	“What if instead of prev/next/child, this were an N-ary tree and you needed a flattened preorder list?” — same exact pattern, just generalized: instead of one child, you’d have a list of children, and you push them onto the stack in reverse order so they pop in the correct left-to-right sequence.
3.	“What’s the time and space complexity?” — O(n) time since every node is visited once; space is O(d) for the stack (d = max nesting depth) in the iterative version, or O(n) in the absolute worst case if every node has a child one level deeper than the last (a fully degenerate chain).
4.	“Can you do it recursively instead?” — you’d already have this from earlier, good chance to mention the call stack mirrors the explicit stack exactly.
5.	“How would you unflatten it back to the original multilevel structure?” — trickier, since you’ve destroyed the information about where each child sequence started and ended; you’d need to have recorded that during flattening (e.g. markers or a separate map) since it’s not recoverable from the flat list alone.

Worth asking back, if the interview allows it:

•	“Is the O(1) space version something you’d want me to also implement, or is the stack-based one sufficient for this round?” — clarifies how deep they want you to go before you start optimizing further.
•	“Would you like me to write a couple of test cases to verify edge cases, or is the trace I did sufficient?” — shows you’re thinking about verification, not just submission.
Visualisation: https://claude.ai/share/39bc2654-332e-40b3-aff7-73f6ecf68ee6
Claude link: https://claude.ai/share/39bc2654-332e-40b3-aff7-73f6ecf68ee6
Leetcode editorial : https://leetcode.com/problems/flatten-a-multilevel-doubly-linked-list/editorial/#approach-2-dfs-by-iteration

© 2026 Vidya Srinivasa Kesarla. All rights reserved.