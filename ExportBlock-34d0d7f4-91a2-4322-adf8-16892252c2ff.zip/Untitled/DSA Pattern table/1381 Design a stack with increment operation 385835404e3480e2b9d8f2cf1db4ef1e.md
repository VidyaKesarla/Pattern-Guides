# 1381. Design a stack with increment operation

Difficulty: Medium
Input Data Structure: Array
Pattern trigger(recognition) / constraints hint / : Sounds like you’re asking what tips you off that a problem like this calls for the lazy-propagation pattern. A few signals to watch for:
Problem-statement signals
• A bulk/range update (“increment the bottom k”, “add to all elements in range L..R”) paired with point reads that happen one at a time (here: pop() only ever reads the top).
• The update is “cheap to describe, expensive to apply” — increment(k, val) is one instruction but naively touches k cells.
• Reads and writes are asymmetric in frequency or shape — many small updates, few/structured reads (or vice versa). That asymmetry is what makes deferring worthwhile.
• The structure has a fixed traversal order (stack = LIFO, array = left-to-right) — so you know exactly which direction “debt” needs to propagate, and can push it just one step at a time instead of resolving the whole range.
Code-level signals (when reviewing existing code)
• A loop inside a “simple-sounding” operation (increment‘s for loop) that’s doing eager work proportional to a range size.
• That range is bounded by something monotonic (top of stack, array length) — meaning a “frontier” exists where you could stash a pending value instead of broadcasting it.
The general recognition heuristic Ask: “Does this update need to be visible immediately everywhere, or only the next time someone reads it?” If it’s the latter, you can almost always trade an O(k) write for an O(1) write + a little extra work folded into the next read — that’s the difference-array/lazy-propagation/segment-tree-lazy-tag family in a nutshell.
If you meant something different by “pattern trigger or signal” — like a coding-pattern name (e.g. “is this Sliding Window / Two Pointer / etc.”), or something about a specific tool/system — let me know and I’ll redirect.
Constraints: Constraints:
• 1 <= maxSize, x, k <= 1000
• 0 <= val <= 100
• At most 1000 calls will be made to each method of increment, push and pop each separately.
Intuition: In the previous approach, the increment operation modified the bottom k elements directly, which can become inefficient for large stacks or frequent increments. To improve this, we can use lazy propagation, a technique where updates are delayed until absolutely necessary.
Instead of immediately updating all affected elements during an increment, we store the increment value and apply it only when needed. This is useful when dealing with a range of elements but without the need for immediate updates.
We introduce an additional array, incrementArray, that tracks the increment values. Each index i in this array holds the cumulative value by which the elements [0, i] in the stack will be incremented.
• push():
The push operation remains the same as before. No changes are needed in the incrementArray because pushing doesn't involve any increment adjustments.
• pop():
When popping an element, we return the value at the top of the stack, including any increments that apply to it. This is where lazy propagation is used.
First, we retrieve the value at topIndex and add the corresponding increment from incrementArray. Since this top position is being removed, the increment for it needs to be passed down to the next element below. We do this by adding the increment at topIndex to incrementArray[topIndex-1], preserving the necessary increments for future pops.
Then, we decrement topIndex to remove the current top element.
• increment():
Instead of directly modifying the bottom k elements, we simply update the value at index k-1 in incrementArray. If the stack size is less than k, we update the increment at topIndex instead. This avoids unnecessary modifications and applies the increments only when the affected elements are accessed.
Algorithm: Linkedlist, array
Optimisation : Array using lazy propagation
Why this is better? Optimisation details: All three solve the same LeetCode problem (Design a Stack with Increment), but they differ in how increment() is implemented — that’s the whole story.
Visual: what increment(k, val) does
Stack (bottom→top): [1, 2, 3, 4]
increment(3, 100) → add 100 to the bottom 3 elements
Result:             [101, 102, 103, 4]
The challenge: the “bottom” elements are the oldest pushed, but stacks only let you touch the top efficiently.
Version 1: Plain array, eager increment
• push/pop: O(1) — just move topIndex.
• increment(k, val): O(k) — loops through the first k slots and adds val to each, right when you call it.
increment(3,100):
[1,2,3,4]
 ↑ ↑ ↑      <- touched immediately
[101,102,103,4]
Simple, correct, easy to read. Weakness: if you call increment a lot with large k, it’s slow.
Version 2: LinkedList
Same algorithm as Version 1, just swaps the array for a LinkedList + ListIterator.
• push/pop: O(1) (addLast/removeLast on a doubly linked list are O(1)).
• increment: still O(k) — identical cost to Version 1, just walked via an iterator instead of an index.
Verdict: strictly worse than Version 1. No new capability is gained — you pay extra memory (node pointers) and pointer-chasing overhead for the same asymptotic complexity. The only “advantage” is if maxSize were unknown/unbounded, but here it’s fixed up front, so an array is the natural fit. This version mainly shows “you can do it with a LinkedList,” not “you should.”
Version 3: Array + lazy propagation (the clever one)
Instead of updating k elements immediately, it stores the increment as a single pending value at index k-1, and only “pays” for it when elements are popped.
push 1,2,3,4:       stack=[1,2,3,4]  inc=[0,0,0,0]
increment(5,100):   inc=[0,0,0,100]      ← O(1)! just one write


pop(): top=4, +inc[3]=100 → returns 104
       push the pending +100 down to inc[2] (now 100), clear inc[3]
       stack: top index 2


pop(): top=3, +inc[2]=100 → returns 103
       push +100 down to inc[1], clear inc[2]
...
• push: O(1)
• pop: O(1) — does a tiny constant amount of extra work (propagate one increment down)
• increment: O(1) — just one array write
Verdict: best. This is the asymptotically optimal solution. The trick (a form of lazy propagation, similar in spirit to difference arrays) recognizes that you don’t need to “apply” the increment until the value is actually about to leave the stack — and since pop already visits that element, you can piggyback the work there for free.
Side-by-side
pushpopincrementextra spaceV1 (array, eager)O(1)O(1)O(k)noneV2 (LinkedList)O(1)O(1)O(k)node overheadV3 (array, lazy)O(1)O(1)O(1)one extra array
Practical takeaway: use Version 3 if increment is called often or with large k — it’s a genuine algorithmic improvement, not just a different data structure. Version 1 is fine for clarity/teaching. Version 2 doesn’t buy you anything over Version 1 and adds overhead — skip it unless the assignment specifically wants a LinkedList demo.
Code: class CustomStack {

// Array to store stack elements
private int[] stackArray;

// Array to store increments for lazy propagation
private int[] incrementArray;

// Current top index of the stack
private int topIndex;

public CustomStack(int maxSize) {
stackArray = new int[maxSize];
incrementArray = new int[maxSize];
topIndex = -1;
}

public void push(int x) {
if (topIndex < stackArray.length - 1) {
stackArray[++topIndex] = x;
}
}

public int pop() {
if (topIndex < 0) {
return -1;
}

// Calculate the actual value with increment
int result = stackArray[topIndex] + incrementArray[topIndex];

// Propagate the increment to the element below
if (topIndex > 0) {
incrementArray[topIndex - 1] += incrementArray[topIndex];
}

// Reset the increment for this position
incrementArray[topIndex] = 0;

topIndex--;
return result;
}

public void increment(int k, int val) {
if (topIndex >= 0) {
// Apply increment to the topmost element of the range
int incrementIndex = Math.min(topIndex, k - 1);
incrementArray[incrementIndex] += val;
}
}
}
Dry run: /**
* Dry Run Trace: CustomStack(3)
* * Initial: stackArray=[0,0,0], inc=[0,0,0], top=-1
* 1. push(1): stack=[1,0,0], top=0
* 2. push(2): stack=[1,2,0], top=1
* 3. push(3): stack=[1,2,3], top=2
* 4. increment(2, 10):
* - index = min(2, 2-1) = 1
* - inc[1] += 10 => inc=[0,10,0]
* 5. pop():
* - result = stack[2] + inc[2] = 3 + 0 = 3
* - propagate: inc[1] += inc[2] (10+0=10)
* - inc[2] = 0
* - top = 1
* - Returns 3
* * Complexity:
* - push: O(1)
* - pop: O(1) - Lazy propagation happens here
* - increment: O(1) - Constant time update via indexing
*/

Complexity: Complexity Analysis
• Time complexity: O(1) for all operations
The push, pop, and increment methods perform only constant time operations (comparisons and array operations).
• Space complexity: O(maxSize)
The stackArray and the incrementArray arrays both have a size of maxSize. Thus, the overall space complexity of the algorithm is O(2⋅maxSize)=O(maxSize)
follow up questions: On the algorithm
Why does pop() sometimes write 2 cells?
Because the pending delta is stored at the top index, but it logically applies to every index below it too. When you pop the top element:
1. You read arr[top] + inc[top] — that’s the true value, 1 write to clear inc[top].
2. But the elements below still need that delta applied once top is gone. So before clearing, you shift it down: inc[top-1] += inc[top]. That’s the 2nd write.
If top == 0 (popping the last element), there’s nothing below to shift into, so it’s just 1 write. That’s why the demo sometimes shows “wrote 2 cells” and sometimes “wrote 1.”
Can increment() and pop() both be O(1) with zero propagation writes?
Not quite — there’s a real lower bound here. Each element eventually needs to know its true value when it’s popped, and that information has to travel from wherever the increment was recorded down to that element somehow. The lazy version makes that “somehow” cheap (amortized O(1) per pop, since each pop does at most 1 extra write), but not free.
You could shift the propagation cost differently — e.g., do nothing at pop time and instead keep a running “global offset” plus per-call records, then binary-search at pop — but that trades O(1) pop for O(log n) pop. The version in the visualization picks the best amortized split: O(1) for both operations, with the propagation cost spread out as one extra write per pop instead of batched at increment time.
Relationship to difference arrays / Fenwick trees?
Same family of idea, different shape:
• A difference array stores diff[i] = a[i] - a[i-1]. A range update add(l, r, val) becomes two O(1) writes: diff[l] += val, diff[r+1] -= val. You only “resolve” the array back to real values with a prefix sum when you need to read it. The lazy stack is a degenerate, one-sided version of this: since stack ranges always start at index 0, you only need the “right edge” write (inc[k-1] += val), and resolution happens incrementally via pop instead of a batch prefix-sum pass.
• A Fenwick tree (BIT) generalizes this further to support arbitrary range updates + range queries in O(log n) each, without needing the “always starts at 0” or “only read in LIFO order” constraints. The stack problem doesn’t need that generality — it gets away with O(1) because it only ever updates prefixes and only ever reads the most-recently-pushed element first.
So: difference array → lazy stack → Fenwick tree is roughly “less general but free” → “exploits LIFO structure” → “fully general but log-cost.”
On the code
Testing equivalence
Run the same randomized operation sequence against all three and assert identical observable behavior at every step:
Random rng = new Random(seed);
CustomStackV1 a = new CustomStackV1(maxSize);
CustomStackV2 b = new CustomStackV2(maxSize);
CustomStackV3 c = new CustomStackV3(maxSize);


for (int step = 0; step < 10000; step++) {
    int op = rng.nextInt(3);
    if (op == 0) {
        int x = rng.nextInt(200) - 100;
        a.push(x); b.push(x); c.push(x);
    } else if (op == 1) {
        assertEquals(a.pop(), b.pop());
        assertEquals(b.pop_alreadyCalled_skip, c.pop()); // align calls carefully
    } else {
        int k = rng.nextInt(maxSize) + 1;
        int val = rng.nextInt(200) - 100;
        a.increment(k, val); b.increment(k, val); c.increment(k, val);
    }
}
Two things matter more than the happy path:
• Pop ordering — make sure each version’s pop() is called exactly once per step and compared, not called 3 separate times (since pop is stateful/destructive).
• Boundary-heavy fuzzing — bias the random k toward 1, topIndex+1, and maxSize, since that’s where off-by-one bugs in the lazy version like to hide.
Edge cases for kInputLeetCode’s guaranteeWhat each impl does without a guardk = 0Not in the problem’s constraints (k ≥ 1)V1/V2: loop runs 0 times, no-op, safe. V3: min(top, -1) → negative index → array-index-out-of-bounds crash.k negativeNot guaranteedSame as above — V1/V2 degrade gracefully (loop just doesn’t run), V3 breaks.k > maxSize / k > current sizeExplicitly allowed — “increment the bottom k elements, or all if k exceeds size”All three handle this correctly: V1/V2 clamp via min(k, topIndex+1); V3 clamps via min(topIndex, k-1).
So they’re not equivalent at the unstated edges — V3 is the most fragile one because it does index arithmetic (k - 1) instead of just bounding a loop. Worth adding if (k <= 0) return; as a guard if you productionize it.
Adding decrement()
Trivial for V1/V2 — it’s just increment(k, -val), same cost.
For V3, also just call lazyIncrement(state, k, -val) — the lazy-propagation math doesn’t care about sign, since it’s just addition. No new logic needed in any version; decrement is increment with a negated value, full stop.
Visualisation: https://claude.ai/share/5decb8c1-73f9-4af4-92cf-d8df6249668a
Claude link: https://claude.ai/share/5decb8c1-73f9-4af4-92cf-d8df6249668a

© 2026 Vidya Srinivasa Kesarla. All rights reserved.