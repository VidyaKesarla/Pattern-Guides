# Find K closest elements (1)

Difficulty: Medium
Input Data Structure: Array
Constraints: 
• 1 <= k <= arr.length
• 1 <= arr.length <= 104
• arr is sorted in ascending order.
• -104 <= arr[i], x <= 104
Algorithm: Sliding window, Sort using comparator
Optimisation : Binary search to find left bound, Two Pointers
Why this is better? Optimisation details: or LeetCode 658 (Find K Closest Elements), the last approach in the editorial (Binary Search for the starting index) wins because it exploits a hidden constraint: the $k$ closest elements must form a contiguous subarray because the input array is already sorted.
Instead of hunting for individual numbers, it switches the objective to finding the optimal starting index of a fixed-size window of length $k$.
🏎️ Why the Last Approach Wins
The binary search for the window's starting index runs in $O(\log(N - K) + K)$ time.
Instead of searching through elements, it binary-searches the possible starting positions $[0 \dots N-K]$. At any mid index, it compares the left boundary element (arr[mid]) against the element just outside the right boundary (arr[mid + k]) relative to $x$:Plaintext

       |←------- Window of Size K -------→|
   [ arr[mid],  ...,  ...,  ...,  ...,   arr[mid+k-1] ]   arr[mid+k]
       ↑                                                      ↑
  Left edge                                              Outside right edge

• If x - arr[mid] > arr[mid + k] - x, the element on the right is closer to $x$ than the element on the left. The entire window needs to shift right (left = mid + 1).
• Otherwise, the left element is closer or tied, so the window stays left (right = mid).
By making this a single binary search, it eliminates structural pointer increments entirely, leaving only an $O(k)$ operation at the end to pull the slice.
⚖️ Brute Force & Alternative Trade-offs
Earlier approaches try to solve the problem by treating the elements individually or shrinking boundaries linearly. Here is how they stack up against the winner:
1. Custom Sorting (Brute Force)
• How it works: Sort the entire array based on absolute difference $|arr[i] - x|$. Take the first $k$ elements and sort them again chronologically.
• Trade-off: $O(N \log N)$ time. It completely throws away the fact that the input array is already sorted. It does a massive amount of redundant work sorting elements that are nowhere near $x$.
2. Max-Heap / Priority Queue
• How it works: Maintain a max-heap of size $k$ to keep track of the closest elements seen so far.
• Trade-off: $O(N \log K)$ time. It's better than brute force sorting if $k$ is small, but it still forces you to iterate through all $N$ elements and pay a logging penalty for heap push/pop operations.
3. Two Pointers / Linear Shrinking
• How it works: Start with two pointers at the absolute edges of the array (left = 0, right = N - 1). Compare the elements at both ends and drop the one further away from $x$ until the window shrinks to size $k$.
• Trade-off: $O(N - K)$ time. While intuitive and avoiding sorting overhead, it still requires scaling linearly through the array. If $N = 1,000,000$ and $K = 2$, it takes nearly a million comparisons to shrink the bounds down, whereas the binary search approach settles the window bounds in roughly $\approx 20$steps.
Dry run: /*
💡 HOW THE BINARY SEARCH WINDOW APPROACH WORKS (DRY RUN)

Problem: Find the 'k' closest elements to 'x' in a sorted array.
Insight: Since the array is sorted, the 'k' closest elements MUST form a
contiguous subarray of size k.
Instead of searching for individual numbers, we binary search for the
optimal STARTING INDEX of this window of size k.

------------------------------------------------------------------------
📝 EXAMPLE DRY RUN
------------------------------------------------------------------------
Input: arr = [1, 2, 3, 4, 5, 6, 7], k = 4, x = 5

Initial Bounds for the Starting Index:
The window has size k=4, so the last possible starting index is:
high = arr.length - k = 7 - 4 = 3

So, our search space for the starting index is: low = 0, high = 3.
We are comparing the left element of the window (arr[mid]) with the
element immediately following the window (arr[mid + k]).

--- 🔄 ITERATION 1 ---
low = 0, high = 3
mid = (0 + 3) / 2 = 1

Current Window starting at index 1: [2, 3, 4, 5]
- Left element (arr[mid]):     arr[1] = 2
- Next right element (arr[mid + k]): arr[1 + 4] = arr[5] = 6

Compare distances to x (5):
- Distance to left element:  |5 - 2| = 3
- Distance to right element: |6 - 5| = 1

Logic: The right element (6) is closer to x than the left element (2).
This means our window is too far left. We need to shift it right.
Action: low = mid + 1 = 2

--- 🔄 ITERATION 2 ---
low = 2, high = 3
mid = (2 + 3) / 2 = 2

Current Window starting at index 2: [3, 4, 5, 6]
- Left element (arr[mid]):     arr[2] = 3
- Next right element (arr[mid + k]): arr[2 + 4] = arr[6] = 7

Compare distances to x (5):
- Distance to left element:  |5 - 3| = 2
- Distance to right element: |7 - 5| = 2

Logic: It's a tie! The problem states that if distances are equal,
the smaller number (left side) wins. So the left element (3) is
preferred over the right element (7). The window shouldn't move right.
Action: high = mid = 2

--- 🛑 TERMINATION ---
low = 2, high = 2 -> Loop terminates because low == high.

Optimal Starting Index found: 2
The resulting window of size k=4 starts at index 2:
arr[2] through arr[5] -> [3, 4, 5, 6]

------------------------------------------------------------------------
⏱️ COMPLEXITY:
Time:  O(log(N - K) + K) -> O(log(N - K)) to find the index + O(K) to build the result.
Space: O(1) extra space.
*/
Complexity: 
• Time complexity: O(log(N−k)+k).
Although finding the bounds only takes O(log(N−k)) time from the binary search, it still costs us O(k) to build the final output.
Both the Java and Python implementations require O(k) time to build the result. However, it is worth noting that if the input array were given as a list instead of an array of integers, then the Java implementation could use the ArrayList.subList() method to build the result in O(1) time. If this were the case, the Java solution would have an (extremely fast) overall time complexity of O(log(N−k)).
• Space complexity: O(1).
Again, we use a constant amount of space for our pointers, and space used for the output does not count towards the space complexity.

© 2026 Vidya Srinivasa Kesarla. All rights reserved.