# 53. Maximum Subarray

Difficulty: Medium
Input Data Structure: Array
Pattern trigger(recognition) / constraints hint / : Used whenever you need the best value continuous slice of an array under a sum based objective.
Constraints: Constraints:
• 1 <= nums.length <= 105
• -104 <= nums[i] <= 104
Intuition: https://leetcode.com/problems/maximum-subarray/editorial/?envType=company&envId=apple&favoriteSlug=apple-all#approach-2-dynamic-programming-kadanes-algorithm
Algorithm: optimised brute force
Optimisation : Kadane's algorithm
Code: class Solution {
public int maxSubArray(int[] nums) {
// Initialize our variables using the first element.
int currentSubarray = nums[0];
int maxSubarray = nums[0];

// Start with the 2nd element since we already used the first one.
for (int i = 1; i < nums.length; i++) {
int num = nums[i];
// If current_subarray is negative, throw it away. Otherwise, keep adding to it.
currentSubarray = Math.max(num, currentSubarray + num);
maxSubarray = Math.max(maxSubarray, currentSubarray);
}

return maxSubarray;
}
}
Dry run: Let’s dry-run this with an example array: nums = [-2, 1, -3, 4, -1, 2, 1, -5, 4]
This is Kadane’s Algorithm for the Maximum Subarray problem.
Initialization:
• currentSubarray = nums[0] = -2
• maxSubarray = nums[0] = -2
Loop (starting i=1):inumcurrentSubarray + nummax(num, curr+num) → currentSubarraymaxSubarray11-2+1 = -1max(1, -1) = 1max(-2,1) = 12-31+(-3) = -2max(-3, -2) = -2max(1,-2) = 134-2+4 = 2max(4, 2) = 4max(1,4) = 44-14+(-1) = 3max(-1, 3) = 3max(4,3) = 4523+2 = 5max(2, 5) = 5max(4,5) = 5615+1 = 6max(1, 6) = 6max(5,6) = 67-56+(-5) = 1max(-5, 1) = 1max(6,1) = 6841+4 = 5max(4, 5) = 5max(6,5) = 6
Return: maxSubarray = 6
Why 6? The subarray [4, -1, 2, 1] sums to 6 — that’s the maximum.
Logic in plain words:
• At each step, ask: “Is it better to extend the previous subarray by adding num, or start fresh at num?”
• If currentSubarray (running sum) is negative, it’s dragging you down — better to drop it and start over from the current number.
• Otherwise, keep extending.
• Track the best sum seen so far in maxSubarray.
Complexity: Time O(n), Space O(1) — single pass, constant extra memory.
Complexity: Complexity Analysis
• Time complexity: O(N), where N is the length of nums.
We iterate through every element of nums exactly once.
• Space complexity: O(1)
No matter how long the input is, we are only ever using 2 variables: currentSubarrayand maxSubarray.

© 2026 Vidya Srinivasa Kesarla. All rights reserved.