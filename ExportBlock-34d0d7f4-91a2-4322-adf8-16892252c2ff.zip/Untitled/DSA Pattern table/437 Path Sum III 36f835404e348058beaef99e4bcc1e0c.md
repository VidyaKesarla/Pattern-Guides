# 437. Path Sum III

Difficulty: Medium
Input Data Structure: Array
Constraints: Constraints:
• The number of nodes in the tree is in the range [0, 1000].
• -109 <= Node.val <= 109
• -1000 <= targetSum <= 1000
Algorithm: Recursion
Optimisation : Prefix sum
Why this is better? Optimisation details: Intuition
Now let's reuse the same algorithm and the same code for the case of the binary tree.There is just one thing that is particular for the binary tree. There are two ways to go forward - to the left and to the right. To keep parent->child direction, we shouldn't blend prefix sums from the left and right subtrees in one hashmap.
Algorithm
• Let's initialize tree paths counter count = 0, and the hashmap h "prefix sum -> how many times was it seen so far".
• One could parse the tree using https://leetcode.com/articles/sum-root-to-leaf-numbers/: node -> left -> right: preorder(node: TreeNode, curr_sum: int) -> None. This function takes two arguments: a tree node and a prefix sum before that node. To start the recursion chain, one should call preorder(root, 0).
    ◦ The first thing is to update the current prefix sum by adding the value of the current node: curr_sum += node.val.
    ◦ Now one could update the counter. One should consider two situations.
In situation 1, the tree path with the target sum starts from the root. That means the current prefix sum is equal to the target sum curr_sum == k, so one should increase the counter by 1: count += 1.
In situation 2, the tree path with the target sum starts somewhere downwards. That means we should add to the counter the number of times we have seen the prefix sum curr_sum - target so far: count += h[curr_sum - target].
The logic is simple: the current prefix sum is curr_sum, and several elements before the prefix sum was curr_sum - target. All the elements in between sum up to curr_sum - (curr_sum - target) = target.
    ◦ Now it's time to update the hashmap: h[curr_sum] += 1.
    ◦ Let's parse left and right subtrees: preorder(node.left, curr_sum), preorder(node.right, curr_sum).
    ◦ Now the current subtree is processed. It's time to remove the current prefix sum from the hashmap, in order not to blend the parallel subtrees: h[curr_sum] -= 1.
• Now the preorder traversal is done, and the counter is updated. Return it.
Code: https://leetcode.com/problems/path-sum-iii/editorial/
Complexity: Complexity Analysis
• Time complexity: O(N), where N is a number of nodes. During preorder traversal, each node is visited once.
• Space complexity: up to O(N) to keep the hashmap of prefix sums, where N is a number of nodes.

© 2026 Vidya Srinivasa Kesarla. All rights reserved.