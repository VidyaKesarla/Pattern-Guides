# Kth largest element in an array

Difficulty: Medium
Input Data Structure: Array
Constraints: Constraints:
• 1 <= k <= nums.length <= 105
• -104 <= nums[i] <= 104
Algorithm: Heap
Optimisation : Min heap
Why this is better? Optimisation details: import java.util.PriorityQueue;

//

// Note : -
// - Modify the function or parameters if needed.
// - Signatures function may vary, adjust parameters if required.

class Solution {
public int kthLargestElementInAnArray(int[] nums, int k) {
//brute force would be to sort it in descending order and return the element at index k-1 = > O(nlogn) cost of sorting Space: O(n)

//a min heap would be an optimal solution for this why so?
// maintain a min heap of size exactly k elements
//if the heap size < k push freely
//if the heap size = k only push if val > heap[0]
//after this i have to pop the minimum out

//after all the n elements are processed, the heap holds k largest values seen so far. the smallest among them heap[0] is the kth largest

//why min heap and not maxheap?
// a maxheap would need the full array to extract the kth element
// a min heap of size k lets us evict the weakest contender instantly keeping only the kth strongest at any time

//dry run :
//nums = [3,2,1,5,6,4] k = 2
//heap []

//val = 3 -> size = 0 < k = 2 -> push - > heap[3]
//val = 2 -> size = 1 < k=2 -> push -> heap[2,3] min heap 2 is on the top
//val = 1 -> size = 2 == k=2 -> push only if val is greater than the top most element on heap= > skip. heap [2,3]
//val = 5 -> size = 2 == k = 2 5 > heap[0] (2) push + pop => heap [3,5]
//val = 6 -> size =2 == k = 2, 6 > heap[0] 3 push + pop = > heap [5,6]
//val 4 -> size = 2 == k =2, 4 > heap[0] = 5, skip heap [5,6]

//heap[0] = 5 -> return 5

//here we are just seeing the usefulness of the heap because it is giving us the 2 largest seen so far.
//its minimum top is by definition the 2nd largest overall

//complexity: O(nlogk) = > we are processing n elements, and each push or pop costs me O(logk)
//when k << n this is far faster than o(nlogn)
//space = O(logk)

//brute force trade off hereis that tc : o(nlogn) this takes o(nlogk)
//sc: o(n) bf, heap = o(k)


//brute force space scales with the input size, heap space scales with k . when k is small the heap uses a tiny fraction of what brute force needs

//min heap approach fo te k largest eleen in the array:
//takes o(nlogk) time complexity:
//you process each of the n elements once, for every element you do a heap push or pop both are o(logk) because the heap never grows beyond the size k . so its n*logk total
///space: o(logk) heap holds at the most k elements at any time. thats all the extra memory which is used, no copy of the input

PriorityQueue<Integer> pq = new PriorityQueue<>();

for(int i = 0;i<k;i++){
pq.add(nums[i]);
}

for(int i =k;i<nums.length;i++){
if(pq.peek() < nums[i]){
pq.remove();
pq.add(nums[i]);
}
}
return pq.peek();
}
}

© 2026 Vidya Srinivasa Kesarla. All rights reserved.