# 931. Minimum Falling Path Sum

Difficulty: Medium
Input Data Structure: Matrix
Constraints: 
• n == matrix.length == matrix[i].length
• 1 <= n <= 100
• -100 <= matrix[i][j] <= 100
Algorithm: Recursion
Optimisation : Bottom up DP - Tabulation
Why this is better? Optimisation details: Algorithm
Bottom-up Dynamic Programming follows an iterative approach to solving the problem. We have to start by finding the minimum falling path for the smallest possible matrix i.e the matrix having a single cell and one by one move towards the rest of the cells in the matrix.
1. To compute the minimum falling path for a certain cell (row, col), we must have pre-computed values for the minimum falling path for cells (row + 1, col - 1), (row + 1, col) and (row + 1, col + 1). For this, we will iterate from (n−1)th row to 0th row and from 0th column to (n−1)th column.Note: The order of iterating the columns does not matter in this case. Even if we iterate from (n−1)th to 0th column, the results would be the same.
2. Build a 2D matrix dp and compute the minimum falling path of current row and col as,

   dp[row][col] = min(dp[row + 1][col - 1],
                      dp[row + 1][col],
                      dp[row + 1][col + 1]) + value of current (row, col) in matrix
Note: We must handle the edge cases, for example, if the col value is 0 or n - 1.
3. Once we have the value of the minimum falling path from every cell, we must get the result from the start cell. The start cell can be any cell on the first row. Thus, we will iterate over all the cells in the first row, and return the minimum value.
Rationale: Intuition:    The problem asks us to find the minimum path sum from the top row to the bottom row,     where we can only move to adjacent columns in the next row (directly below, diagonally left,     or diagonally right). This exhibits optimal substructure: the minimum path sum to reach     matrix[row][col] depends entirely on the minimum paths of its reachable neighbors in the next row.        By starting from the bottom row and working our way up, we can iteratively build the optimal     solutions for smaller subproblems.     ---    Brute Force Trade-off:    - Brute Force Approach: Explore all possible paths using recursion. From every cell, we have       up to 3 choices. For an N x N matrix, this results in a Time Complexity of O(3^N).    - Trade-off: The brute force approach recalculates the minimum path for the same cells       repeatedly (overlapping subproblems). By using Dynamic Programming (Tabulation), we trade       O(N) extra space to drastically reduce the time complexity from exponential O(3^N) to polynomial O(N^2).
Code: https://leetcode.com/problems/minimum-falling-path-sum/submissions/2021149874/
Dry run:  Dry Run:    Input Matrix:    [2, 1, 3]    [6, 5, 4]    [7, 8, 9]    DP Table Initialization (Size 4x4 filled with 0s):    [0, 0, 0, 0]    [0, 0, 0, 0]    [0, 0, 0, 0]    [0, 0, 0, 0]    Step 1: Row = 2 (Bottom Row of Matrix)    - col = 0: min(dp[3][0], dp[3][1]) + 7 -> min(0, 0) + 7 = 7    - col = 1: min(dp[3][1], min(dp[3][2], dp[3][0])) + 8 -> min(0, min(0,0)) + 8 = 8    - col = 2: min(dp[3][2], dp[3][1]) + 9 -> min(0, 0) + 9 = 9    DP state: row 2 becomes [7, 8, 9, 0]    Step 2: Row = 1 (Middle Row of Matrix)    - col = 0: min(dp[2][0], dp[2][1]) + 6 -> min(7, 8) + 6 = 13    - col = 1: min(dp[2][1], min(dp[2][2], dp[2][0])) + 5 -> min(8, min(9,7)) + 5 = 12    - col = 2: min(dp[2][2], dp[2][1]) + 4 -> min(9, 8) + 4 = 12    DP state: row 1 becomes [13, 12, 12, 0]    Step 3: Row = 0 (Top Row of Matrix)    - col = 0: min(dp[1][0], dp[1][1]) + 2 -> min(13, 12) + 2 = 14    - col = 1: min(dp[1][1], min(dp[1][2], dp[1][0])) + 1 -> min(12, min(12,13)) + 1 = 13    - col = 2: min(dp[1][2], dp[1][1]) + 3 -> min(12, 12) + 3 = 15    DP state: row 0 becomes [14, 13, 15, 0]    Final Answer Extraction:    Scan through dp[0] -> min(14, 13, 15) = 13.    Output: 13
Complexity: Complexity Analysis:    - Time Complexity (TC): O(N^2) where N is the number of rows/columns. We iterate     through every       cell in the matrix exactly once, performing O(1) operations per cell.    - Space Complexity (SC): O(N^2) to store the DP table of size (N+1) x (N+1).       *(Note: This can be optimized to O(N) by only keeping track of the previous row, or       O(1) if 
Visualisation: https://g.co/gemini/share/a1709c07abe1

© 2026 Vidya Srinivasa Kesarla. All rights reserved.