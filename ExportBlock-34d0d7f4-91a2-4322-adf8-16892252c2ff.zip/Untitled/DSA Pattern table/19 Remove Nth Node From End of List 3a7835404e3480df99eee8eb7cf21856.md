# 19. Remove Nth Node From End of List

Difficulty: Medium
Constraints: Constraints:
• The number of nodes in the list is sz.
• 1 <= sz <= 30
• 0 <= Node.val <= 100
• 1 <= n <= sz
Optimisation : One pass optimisation
Code: class Solution {
public ListNode removeNthFromEnd(ListNode head, int n) {
ListNode dummy = new ListNode(0);
dummy.next = head;
ListNode first = dummy;
ListNode second = dummy;
// Advances first pointer so that the gap between first and second is n nodes apart
for (int i = 1; i <= n + 1; i++) {
first = first.next;
}
// Move first to the end, maintaining the gap
while (first != null) {
first = first.next;
second = second.next;
}
second.next = second.next.next;
return dummy.next;
}
}
Complexity: Complexity Analysis
• Time complexity : O(L).
The algorithm makes one traversal of the list of L nodes. Therefore time complexity is O(L).
• Space complexity : O(1).
We only used constant extra space.

© 2026 Vidya Srinivasa Kesarla. All rights reserved.