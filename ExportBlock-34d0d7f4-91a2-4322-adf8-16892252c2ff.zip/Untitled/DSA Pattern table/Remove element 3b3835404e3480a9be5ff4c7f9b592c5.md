# Remove element

Difficulty: Easy
Input Data Structure: Array
Pattern trigger(recognition) / constraints hint / : “Remove“
Signal / Paraphrase hint: Then return the number of elements in nums which are not equal to val.
Consider the number of elements in nums which are not equal to val be k, to get accepted, you need to do the following things:
• Change the array nums such that the first k elements of nums contain the elements which are not equal to val. The remaining elements of nums are not important as well as the size of nums.
Constraints: Constraints:
• 0 <= nums.length <= 100
• 0 <= nums[i] <= 50
• 0 <= val <= 100
Intuition: https://leetcode.com/problems/remove-element/editorial/#approach-1-two-pointers

Approach 1: Two Pointers
Intuition
Since this question is asking us to remove all elements of the given value in-place, we have to handle it with O(1) extra space. How to solve it? We can keep two pointers i and j, where i is the slow-runner while j is the fast-runner.
Algorithm
When nums[j] equals to the given value, skip this element by incrementing j. As long as nums[j]=val, we copy nums[j] to nums[i] and increment both indexes at the same time. Repeat the process until j reaches the end of the array and the new length is i.
This solution is very similar to the solution to https://leetcode.com/articles/remove-duplicates-from-sorted-array/.
Algorithm: Brute force
Optimisation : Two Pointers
Code: class Solution {
func removeElement(_ nums: inout [Int], _ val: Int) -> Int {
var i = 0
for j in 0..<nums.count {
if nums[j] != val {
nums[i] = nums[j]
i = i + 1
}
}
return i
}
}

Complexity: Complexity analysis
• Time complexity : O(n).
Assume the array has a total of n elements, both i and j traverse at most 2n steps.
• Space complexity : O(1).

© 2026 Vidya Srinivasa Kesarla. All rights reserved.