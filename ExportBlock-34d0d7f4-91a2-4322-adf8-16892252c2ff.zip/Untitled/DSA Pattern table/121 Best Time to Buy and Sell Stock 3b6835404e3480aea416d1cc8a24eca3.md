# 121. Best Time to Buy and Sell Stock

Difficulty: Easy
Input Data Structure: Array
Pattern trigger(recognition) / constraints hint / : “maximize your profit”
Signal / Paraphrase hint: “maximize your profit”
Constraints: 
• 1 <= prices.length <= 105
• 0 <= prices[i] <= 104
Brute force code and its trade off: public class Solution {
public int maxProfit(int prices[]) {
int maxprofit = 0;
for (int i = 0; i < prices.length - 1; i++) {
for (int j = i + 1; j < prices.length; j++) {
int profit = prices[j] - prices[i];
if (profit > maxprofit) maxprofit = profit;
}
}
return maxprofit;
}
}
Intuition: The points of interest are the peaks and valleys in the given graph. We need to find the largest price following each valley, which difference could be the max profit.We can maintain two variables - minprice and maxprofit corresponding to the smallest valley and maximum profit (maximum difference between selling price and minprice) obtained so far respectively.
Algorithm: Brute force
Optimisation : One pass optimisation
Why this is better? Optimisation details: Brute force causes: 
Complexity Analysis
- Time complexity: O(n2). Loop runs 2n(n−1) times.
- Space complexity: O(1). Only two variables - maxprofit and profit are used.
Code: public class Solution {
public int maxProfit(int prices[]) {
int minprice = Integer.MAX_VALUE;
int maxprofit = 0;
for (int i = 0; i < prices.length; i++) {
if (prices[i] < minprice) minprice = prices[i];
else if (prices[i] - minprice > maxprofit) maxprofit = prices[i] -
minprice;
}
return maxprofit;
}
}
Complexity: Complexity Analysis
• Time complexity: O(n). Only a single pass is needed.
• Space complexity: O(1). Only two variables are used.

© 2026 Vidya Srinivasa Kesarla. All rights reserved.

© 2026 Vidya Srinivasa Kesarla. All rights reserved.