# 713. Subarray Product Less Than K

Difficulty: Medium
Input Data Structure: Array
Constraints: 
• 1 <= nums.length <= 3 * 104
• 1 <= nums[i] <= 1000
• 0 <= k <= 106
Optimisation : Sliding window, Two Pointers
Why this is better? Optimisation details: https://leetcode.com/problems/subarray-product-less-than-k/editorial/
Complexity: //tc: o(n)//sc: o(1) The algorithm uses a constant amount of extra space for variables like totalCount, product, left, and right. These variables do not depend on the size of the input array. Therefore, the space complexity is considered constant, denoted as O(1).

© 2026 Vidya Srinivasa Kesarla. All rights reserved.