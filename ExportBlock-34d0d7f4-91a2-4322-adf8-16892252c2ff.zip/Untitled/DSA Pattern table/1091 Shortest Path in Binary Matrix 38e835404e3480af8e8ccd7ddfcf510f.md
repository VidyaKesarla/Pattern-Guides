# 1091. Shortest Path in Binary Matrix

Difficulty: Difficult
Input Data Structure: 2D Array
Pattern trigger(recognition) / constraints hint / : Is it a GRID problem?                    ✅
Am I finding SHORTEST path/distance?     ✅
Each step has EQUAL cost (weight)?       ✅  ← key BFS signal
Can I move in multiple directions?       ✅

Signal / Paraphrase hint: Need shortest path in unweighted graph/grid?
↓
→ BFS (not DFS — DFS finds A path, not THE shortest)

Need shortest path with weighted edges?
→ Dijkstra

Need to explore ALL paths / count paths?
→ DFS / backtracking

Need shortest path with negative weights?
→ Bellman-Ford

Clarifying questions: 1.	Can the start or end cell itself be 1? → return -1 immediately
	2.	Is the grid always square (n×n)? → yes per problem
	3.	Can n = 1? → yes, grid[0][0] = 0 → return 1
	4.	Are we guaranteed a binary matrix (only 0s and 1s)?
Constraints: Constraints:
• n == grid.length
• n == grid[i].length
• 1 <= n <= 100
• grid[i][j] is 0 or 1
Intuition: Approach 1: Breadth-first Search (BFS), Overwriting Input
Intuition
This section is aimed at readers who aren't yet at a level that they can immediately recognize this as being a BFS problem. If you don't require this level of guidance, feel free to skip forward to the algorithm or code section.
If you're faced with a problem like this and aren't sure where to go with it, then a good first step is to make an example and solve it on a whiteboard or paper. Here's the example we'll work through here.
The next step is to think about whether there is a better way of visualizing the input. In this case, we're told 0's represent "open" cells, and 1's represent "blocked" cells. An intuitive way of visualizing this, therefore, is to color in the "blocked" cells.
Edge cases / base cases: grid[0][0] == 1  → return -1  (can't even start)
grid[n-1][n-1] == 1  → return -1  (can't finish)
n == 1 && grid[0][0] == 0  → return 1  (already at destination)

Algorithm: BFS
Optimisation : BFS
Code: class Solution {

static private final int[][] dirs = {{-1,-1},{-1,0},{-1,1},{0,-1},{0,1},{1,-1},{1,0},{1,1}};


public int shortestPathBinaryMatrix(int[][] grid) {
if(grid[0][0] != 0 || grid[grid.length - 1][grid[0].length - 1] != 0){
return -1;
}

//set up bfs

Queue<int[]> queue = new ArrayDeque<>();
grid[0][0] = 1;
queue.add(new int[] {0,0});

while(!queue.isEmpty()){

int [] curr = queue.poll();
int row = curr[0];
int col = curr[1];

int distance = grid[row][col];

if(row == grid.length - 1 && col == grid[0].length - 1){
return distance;
}

for(int[] neighbor: getNeighbors(row, col, grid)){
int neighborRow = neighbor[0];
int neighborCol = neighbor[1];
queue.add(new int[] {neighborRow, neighborCol});
grid[neighborRow][neighborCol] = distance + 1;
}
}
return -1;
}

private List<int[]> getNeighbors(int row, int col, int[][] grid){
List<int[]> neighbors = new ArrayList<>();

for(int i = 0;i<dirs.length;i++){
int newRow = row + dirs[i][0];
int newCol = col + dirs[i][1];
if(newRow <0 || newCol <0 || newRow >= grid.length || newCol >= grid[0].length || grid[newRow][newCol] != 0){
continue;
}
neighbors.add(new int[] {newRow, newCol});
}
return neighbors;
}


}
Dry run: === DRY RUN ===

Grid:          n=3
[0, 0, 0]      grid[0][0]=0, grid[2][2]=0 → no early return
[1, 1, 0]      Queue: [{0,0,1}]   mark grid[0][0]=1
[1, 1, 0]

-------------------------------------------------------
ITERATION 1 — Poll {row=0, col=0, dist=1}

(-1,-1) OOB        skip
(-1, 0) OOB        skip
(-1,+1) OOB        skip
( 0,-1) OOB        skip
( 0,+1) (0,1)=0  ✅ enqueue {0,1,2}  mark grid[0][1]=1
(+1,-1) OOB        skip
(+1, 0) (1,0)=1   blocked
(+1,+1) (1,1)=1   blocked

Queue: [{0,1,2}]

-------------------------------------------------------
ITERATION 2 — Poll {row=0, col=1, dist=2}

(-1, 0) OOB        skip
(-1, 1) OOB        skip
(-1, 2) OOB        skip
( 0, 0) visited    skip
( 0, 2) (0,2)=0  ✅ enqueue {0,2,3}  mark grid[0][2]=1
( 1, 0) (1,0)=1   blocked
( 1, 1) (1,1)=1   blocked
( 1, 2) (1,2)=0  ✅ enqueue {1,2,3}  mark grid[1][2]=1

Queue: [{0,2,3}, {1,2,3}]

-------------------------------------------------------
ITERATION 3 — Poll {row=0, col=2, dist=3}

(-1,*) OOB         skip
( 0,1) visited     skip
( 0,3) OOB         skip
( 1,1) blocked     skip
( 1,2) visited     skip
( 1,3) OOB         skip

Nothing enqueued.
Queue: [{1,2,3}]

-------------------------------------------------------
ITERATION 4 — Poll {row=1, col=2, dist=3}

(0,1) visited      skip
(0,2) visited      skip
(0,3) OOB          skip
(1,1) blocked      skip
(1,3) OOB          skip
(2,1) blocked      skip
(2,2) nr==n-1 && nc==n-1  🎯 return dist+1 = 4
(2,3) OOB          skip

-------------------------------------------------------
PATH:   (0,0)→(0,1)→(0,2)→(1,2)→(2,2)
ANSWER: 4
*/
Complexity: Complexity Analysis
Let N be the number of cells in the grid.
• Time complexity : O(N).
Each cell was guaranteed to be enqueued at most once. This is because a condition for a cell to be enqueued was that it had a zero in the grid, and when enqueuing, we also permanently changed the cell's grid value to be non-zero.
The outer loop ran as long as there were still cells in the queue, dequeuing one each time. Therefore, it ran at most N times, giving a time complexity of O(N).
The inner loop iterated over the unvisited neighbors of the cell that was dequeued by the outer loop. There were at most 8 neighbors. Identifying the unvisited neighbors is an O(1) operation because we treat the 8 as a constant.
Therefore, we have a time complexity of O(N).
• Space complexity : O(N).
The only additional space we used was the queue. We determined above that at most, we enqueued N cells. Therefore, an upper bound on the worst-case space complexity is O(N).
Given that BFS will have nodes of at most two unique distances on the queue at any one time, it would be reasonable to wonder if the worst-case space complexity is actually lower. But actually, it turns out that there are cases with massive grids where the number of cells at a single distance is proportional to N. So even with cells of a single distance on the queue, in the worst case, the space needed is O(N).
follow up questions: 1. What if you can only move in 4 directions (not 8)? // Just swap the dirs array int[][] dirs = {{-1,0},{1,0},{0,-1},{0,1}}; // Everything else stays identical 2. What if the grid has weighted cells (cost to enter each cell)? BFS breaks — cells no longer have equal cost → Switch to Dijkstra's algorithm → Queue<int[]> becomes PriorityQueue sorted by cost PriorityQueue<int[]> pq = new PriorityQueue<>((a,b) -> a[2] - b[2]); // {row, col, totalCost} 3. What if you can eliminate at most k obstacles? State changes — (row, col) alone is no longer enough → Track (row, col, obstaclesUsed) in the queue → Visited becomes boolean[n][n][k+1] // Queue stores {row, col, dist, obstaclesUsed} // LeetCode 1293 — Shortest Path with Obstacle Elimination 4. What if there are multiple sources (start from all 0s simultaneously)?
→ Multi-source BFS
→ Enqueue ALL starting cells before the loop begins
// LeetCode 542 — 01 Matrix (distance to nearest 0)
for (int r = 0; r < n; r++)
    for (int c = 0; c < n; c++)
        if (grid[r][c] == 0) queue.offer(new int[]{r, c, 0});


5. What if you need to return the actual path, not just the length?
→ Track parent of each cell
→ Backtrack from end to start after BFS completes
int[][] parent = new int[n * n][2]; // parent[r*n+c] = {parentR, parentC}


// After reaching destination, backtrack:
List<int[]> path = new ArrayList<>();
int[] cur = {n-1, n-1};
while (cur[0] != 0 || cur[1] != 0) {
    path.add(cur);
    cur = parent[cur[0] * n + cur[1]];
}
Collections.reverse(path);

6. What if the grid changes dynamically (cells open/close)?
Static BFS won't work
→ Look into D* Lite or A* with replanning
→ Out of typical LC scope but common in robotics/game dev
7. Can you solve it faster than O(n^2)
No — you must visit every cell in the worst case
O(n²) is optimal for this problem
BFS already achieves the lower bound
Reusable template: // ✅ Reusable BFS template for grid shortest-path problems
int bfsGrid(int[][] grid, int startR, int startC, int endR, int endC) {
int m = grid.length, n = grid[0].length;
int[][] dirs = {{-1,0},{1,0},{0,-1},{0,1}}; // 4-dir; add diagonals for 8-dir
boolean[][] visited = new boolean[m][n];

Queue<int[]> queue = new LinkedList<>();
queue.offer(new int[]{startR, startC});
visited[startR][startC] = true;
int steps = 0;

while (!queue.isEmpty()) {
int size = queue.size();         // ← process level by level
steps++;

for (int i = 0; i < size; i++) {
int[] curr = queue.poll();
if (curr[0] == endR && curr[1] == endC) return steps;

for (int[] dir : dirs) {
int nr = curr[0] + dir[0];
int nc = curr[1] + dir[1];

if (nr < 0 || nc < 0 || nr >= m || nc >= n) continue;
if (visited[nr][nc]) continue;
if (!isValid(grid, nr, nc)) continue; // your condition here

visited[nr][nc] = true;
queue.offer(new int[]{nr, nc});
}
}
}
return -1;
}

© 2026 Vidya Srinivasa Kesarla. All rights reserved.