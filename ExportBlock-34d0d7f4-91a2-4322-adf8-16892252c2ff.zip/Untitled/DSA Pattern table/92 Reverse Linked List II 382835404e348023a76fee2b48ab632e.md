# 92. Reverse Linked List II

Difficulty: Medium
Input Data Structure: Array
Constraints: Constraints:
• The number of nodes in the list is n.
• 1 <= n <= 500
• -500 <= Node.val <= 500
• 1 <= left <= right <= n
Intuition: In the previous approach, we looked at an algorithm for reversing a portion of the given linked list such that the underlying structure doesn't change. We only modified the values of the nodes for achieving the reversal. However, it may so happen that you cannot change the data available in the nodes. In that scenario, we have to modify the links themselves to achieve the reversal.
Essentially, starting from the node at position m and all the way up to n, we reverse the next pointers for all the nodes in between. Let's look at the algorithm for achieving this.
Algorithm: Recursion
Optimisation : Iterative link reversal
Code: /**
* Definition for singly-linked list.
* public class ListNode {
*     int val;
*     ListNode next;
*     ListNode() {}
*     ListNode(int val) { this.val = val; }
*     ListNode(int val, ListNode next) { this.val = val; this.next = next; }
* }
*/
class Solution {
public ListNode reverseBetween(ListNode head, int left, int right) {
ListNode dummy = new ListNode(0, head);
ListNode before = dummy;

for(int i =1;i<left;i++){
before = before.next;
}

ListNode prev = before;
ListNode curr = before.next;

for(int i =left;i<=right;i++){
ListNode next = curr.next;
curr.next = prev;
prev = curr;
curr = next;
}
before.next.next = curr;
before.next = prev;

return dummy.next;
}
}

Dry run: /*
🚀 DETAILED DRY RUN / WALKTHROUGH
Input: head = [1,2,3,4,5], left = 2, right = 4

1. INITIAL SETUP & FINDING THE PRE-REVERSAL NODE
List: dummy(0) -> 1 -> 2 -> 3 -> 4 -> 5
before = dummy

First Loop: Move 'before' to the node just before position 'left'.
for (int i = 1; i < left; i++) -> runs once (i = 1)
before = before.next -> before now points to node 1

Setup Reversal Pointers:
prev = before      -> prev = node 1
curr = before.next -> curr = node 2 (start of our sublist)

2. THE REVERSAL LOOP (i = 2 to 4)
This reverses pointers in place and shifts 'prev' and 'curr' forward.

i = 2:
next = curr.next -> next = node 3
curr.next = prev -> node 2.next = node 1
prev = curr      -> prev = node 2
curr = next      -> curr = node 3
State: 1 <- 2, with curr at 3 and prev at 2

i = 3:
next = curr.next -> next = node 4
curr.next = prev -> node 3.next = node 2
prev = curr      -> prev = node 3
curr = next      -> curr = node 4
State: 1 <- 2 <- 3, with curr at 4 and prev at 3

i = 4:
next = curr.next -> next = node 5
curr.next = prev -> node 4.next = node 3
prev = curr      -> prev = node 4
curr = next      -> curr = node 5
State: 1 <- 2 <- 3 <- 4, with curr at 5 and prev at 4

Loop ends because i = 5 exceeds right (4).

3. RECONNECTING THE PIECES
At this exact moment:
- before = node 1 (its .next still points to node 2)
- prev   = node 4 (the new head of the reversed sublist)
- curr   = node 5 (the remaining unreversed part of the list)

before.next.next = curr; // node(2).next = node(5)
💡 KEY INSIGHT: Because we haven't reassigned before.next yet, it still
refers to node 2 (the original start, which is now the tail of our
reversed block). This line seamlessly bridges the reversed tail to
the rest of the list (node 5).

before.next = prev;      // node(1).next = node(4)
💡 This connects the prefix of the list to the new head of the
reversed section (node 4).

4. FINAL RESULT
List Structure: dummy -> 1 -> 4 -> 3 -> 2 -> 5
return dummy.next yields: 1 -> 4 -> 3 -> 2 -> 5 ✅

⚠️ ORDER MATTERS: You must do before.next.next = curr BEFORE before.next = prev.
Swapping them overwrites before.next, breaking your reference to node 2.
*/

Complexity: 
• Time Complexity: O(N) considering the list consists of N nodes. We process each of the nodes at most once (we don't process the nodes after the nth node from the beginning.
• Space Complexity: O(1) since we simply adjust some pointers in the original linked list and only use O(1) additional memory for achieving the final result.
follow up questions: Here are a few excellent follow-up questions to test your depth, prepare for follow-ups that interviewers actually ask, or try as a next step:
### 1. The Interviewer's Edge-Case Twist
> "How does your sublist reversal code handle edge cases where left = 1? What changes if right is equal to the length of the list?"
>
### 2. The Space Complexity Trade-off
> "We solved this iteratively in O(1) space. If you were forced to solve the sublist reversal recursively, what would the code structure look like, and what happens to the space complexity?"
>
### 3. Escalating to the Next Pattern: Group Reversal
> "Now that we know how to reverse a single sublist between left and right, how would you modify this logic to reverse the linked list in groups of k? (e.g., LeetCode 25: Reverse Nodes in k-Group)"
>
### 4. Downstream Pattern Applications
> "Why is reversing a linked list crucial for solving LeetCode 143 (Reorder List) or checking if a singly linked list is a Palindrome in O(1) auxiliary space?"
>
Which one of these directions would you like to explore next?

Visualisation: https://leetcode.com/problems/reverse-linked-list-ii/editorial/#approach-2-iterative-link-reversal
Claude link: https://leetcode.com/problems/reverse-linked-list-ii/editorial/#approach-2-iterative-link-reversal

© 2026 Vidya Srinivasa Kesarla. All rights reserved.