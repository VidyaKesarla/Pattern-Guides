# 76. Minimum Window Substring

Difficulty: Medium
Input Data Structure: String
Pattern trigger(recognition) / constraints hint / :  minimum window substring
Signal / Paraphrase hint:  minimum window substring
Constraints: Constraints:
• m == s.length
• n == t.length
• 1 <= m, n <= 105
• s and t consist of uppercase and lowercase English letters.
Intuition: Approach: Sliding Window (two pointers) with character frequency maps
*
* Idea:
*   - Expand the window using right until it contains all characters
*     of t with required frequency (formed == required).
*   - Once valid, shrink from left as much as possible while still
*     valid, recording the smallest window seen so far.
*   - formed only increments/decrements on exact frequency-match
*     transitions, so duplicate chars in t (e.g. t = "AAB") are
*     handled correctly without extra bookkeeping.
Algorithm: Brute force
Optimisation : Sliding window
Code: class Solution {
public String minWindow(String s, String t) {
//edge case
if(s.length() == 0 || t.length() == 0 || s == null || t == null || s.length() < t.length()){
return "";
}
HashMap<Character, Integer> need = new HashMap<>();
for(char c: t.toCharArray()){
need.put(c, need.getOrDefault(c, 0) + 1);
}
int left = 0;
int bestLeft = 0;
int bestLen = Integer.MAX_VALUE;
int formed = 0;
int required = need.size();

HashMap<Character, Integer> window = new HashMap<>();
for(int right = 0;right<s.length();right++){
char c = s.charAt(right);
window.put(c, window.getOrDefault(c, 0) + 1);
if(need.containsKey(c) && need.get(c).intValue() == window.get(c).intValue()){
formed++;
}

while(formed == required){

if(right - left + 1 < bestLen){
bestLen = right - left + 1;
bestLeft = left;
}

char leftChar = s.charAt(left);
window.put(leftChar, window.get(leftChar) - 1);

if(need.containsKey(leftChar) && window.get(leftChar).intValue() < need.get(leftChar).intValue()){
formed--;
}

left++;
}
}
return bestLen == Integer.MAX_VALUE ? "" : s.substring(bestLeft, bestLeft + bestLen);
}



}

Dry run: Dry run: s = "ADOBECODEBANC", t = "ABC"
*   need = {A:1, B:1, C:1}, required = 3
*
*   right=0  (A) window={A:1}                 formed=1
*   right=3  (B) window={A:1,B:1}              formed=2
*   right=5  (C) window={A:1,B:1,C:1}          formed=3 -> shrink
*        shrink: left 0->1 (drop A)            best="ADOBEC" len=6
*   right=10 (A) window regains A               formed=3 -> shrink
*        shrink: left 1->6 (drop D,O,B,E,C)     best unchanged, len=6
*   right=12 (C) window regains C               formed=3 -> shrink
*        shrink: left 6->10 (drop O,D,E,B)      best="BANC" len=4  <-- final answer
*
*   Output: "BANC"
*
*
Complexity: Time Complexity:  O(|s| + |t|)
*   - Building need map: O(|t|)
*   - right and left pointers each traverse s at most once
*     (amortized/two-pointer argument) -> O(|s|)
*
* Space Complexity: O(|s| + |t|) worst case (two HashMaps),
*   but effectively O(1) / O(charset size) if the character set is
*   fixed/bounded (e.g. ASCII), since map sizes are bounded by the
*   alphabet, not by string length.

© 2026 Vidya Srinivasa Kesarla. All rights reserved.