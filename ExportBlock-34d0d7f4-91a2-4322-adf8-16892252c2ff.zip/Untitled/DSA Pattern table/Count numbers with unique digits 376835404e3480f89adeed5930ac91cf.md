# Count numbers with unique digits

Difficulty: Medium
Input Data Structure: Integer
Constraints: 0 ≤ n ≤ 8
Brute force code and its trade off: class Solution {
public int countNumbersWithUniqueDigits(int n) {
// Upper bound is 10^n
int limit = (int) Math.pow(10, n);
int count = 0;

// Check every single number in the range
for (int i = 0; i < limit; i++) {
if (hasUniqueDigits(i)) {
count++;
}
}

return count;
}

// Helper function to check if a number has unique digits
private boolean hasUniqueDigits(int num) {
boolean[] visited = new boolean[10]; // To track digits 0-9

// Base case for 0
if (num == 0) return true;

while (num > 0) {
int digit = num % 10;
if (visited[digit]) {
return false; // Found a duplicate digit
}
visited[digit] = true;
num /= 10;
}

return true;
}
}


Complexity Analysis
 Time Complexity: \mathcal{O}(10^n \times \log_{10}(10^n)) \rightarrow \mathcal{O}(n \cdot 10^n). For n = 8, the loop runs 100,000,000 times, and checking each number takes up to 8 operations. This easily triggers a TLE.
 Space Complexity: \mathcal{O}(1) because the boolean array size is fixed at 10.

Intuition:   THE CORE INTUITION (Slot-Filling Concept):
Suppose we want to find the number of unique-digit numbers of length 3: [] [] [__]

1. Slot 1 (Most Significant Digit): Can be 1-9 (9 choices). It cannot be 0, otherwise
it's a 2-digit number.
2. Slot 2: Can be 0-9, but cannot repeat the digit used in Slot 1 (10 - 1 = 9 choices).
3. Slot 3: Cannot repeat the digits used in Slots 1 and 2 (10 - 2 = 8 choices).

Total unique combinations for exactly 3 digits = 9 * 9 * 8 = 648.

Since we need all numbers x < 10^n, the answer is simply the sum of unique
numbers of length 1, length 2, ..., up to length n.
Algorithm: Backtracking, Iterative brute force
Optimisation : Bottom-Up Iterative DP Style, Combinatorics, Permutations
Why this is better? Optimisation details: APPROACH: Combinatorics / Permutations (Bottom-Up Iterative DP Style)

Instead of generating all numbers and checking for duplicates (which takes O(10^n) time),
we use the Fundamental Counting Principle to build valid numbers slot-by-slot
and aggregate them length by length.
Rationale:  VARIABLE BREAKDOWN:
- totalUniqueCount: The running grand total. Initialized to 10 to cover the
base case of all single-digit numbers (0 through 9).
- currentLengthChoices: The number of unique permutations possible only for the
exact digit length being computed. Starts at 9 (for Slot 1).
- availableDigits: The number of unused digits left for the next slot. Starts
at 9 (since 1 digit is already used by Slot 1).
Code: class Solution {
public int countNumbersWithUniqueDigits(int n) {
if (n == 0) {
return 1; // 10^0 = 1. Range is 0 <= x < 1. Only '0' is valid.
}

int totalUniqueCount = 10;
int currentLengthChoices = 9;
int availableDigits = 9;

for (int i = 2; i <= n; i++) {
currentLengthChoices *= availableDigits;
totalUniqueCount += currentLengthChoices;
availableDigits--;
}

return totalUniqueCount;
}
}
Dry run:   DRY RUN SIMULATION FOR n = 3 (Target Range: 0 <= x < 1000)

Before Loop:
totalUniqueCount = 10 (Counts: 0, 1, 2... 9)
currentLengthChoices = 9
availableDigits = 9

Iteration 1 (i = 2, computing 2-digit numbers):
currentLengthChoices *= availableDigits  ->  9 * 9 = 81  (81 unique 2-digit numbers)
totalUniqueCount += currentLengthChoices ->  10 + 81 = 91
availableDigits--                        ->  9 drops to 8

Iteration 2 (i = 3, computing 3-digit numbers):
currentLengthChoices *= availableDigits  ->  81 * 8 = 648 (648 unique 3-digit numbers)
totalUniqueCount += currentLengthChoices ->  91 + 648 = 739
availableDigits--                        ->  8 drops to 7

Result: 739
Complexity: COMPLEXITY ANALYSIS:
- Time Complexity: O(n). Since the constraints specify 0 <= n <= 8, the loop
runs at most 7 times, making this O(1) in practice.
- Space Complexity: O(1) as we only use a few tracking variables.

© 2026 Vidya Srinivasa Kesarla. All rights reserved.