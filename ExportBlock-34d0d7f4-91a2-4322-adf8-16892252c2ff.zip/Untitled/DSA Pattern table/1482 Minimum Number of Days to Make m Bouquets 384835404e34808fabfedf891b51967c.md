# 1482. Minimum Number of Days to Make m Bouquets

Difficulty: Medium
Input Data Structure: Array, Integer
Pattern trigger(recognition) / constraints hint / : Expected tc: O(logn)
Data or answer space is sorted or monotonoic linear search scan feels slow.
Shrink search space each step in O(logn)
single element that appears only once.

Signal / Paraphrase hint: 1. You’re asked to optimize a number, not find an element Phrases like “minimum days/capacity/speed/size such that…” or “maximum value such that…”. You’re searching over the space of possible answers, not over the input array.
2. There’s a monotonic feasibility check If a candidate answer x works, does every value > x (or < x, depending on direction) also work? Here: if you can make mbouquets by day x, you can also make them by any day > x (more flowers have bloomed, never fewer). That monotonic “yes/yes/yes/no/no/no” boundary is the real trigger — binary search just finds where it flips.
3. You can write a canDo(x) → bool (or count) function independently If you can isolate a helper like getNumberOfBouquets(bloomDay, mid, k) that answers “is x good enough?” in roughly linear time, and that helper’s result only moves in one direction as x increases — that’s the tell. The outer binary search is just calling this helper at O(log range) points instead of brute-forcing every x.
4. The answer space is large/continuous but the check is cheap Brute force would be: try every possible day from min(bloomDay) to max(bloomDay), run the O(n)check each time → O(n * range). Binary search cuts range to log(range). Whenever you see “try every possible X and check feasibility,” ask if feasibility is monotonic — if so, binary search it.
Quick mental checklist:
• Minimizing/maximizing a quantity → ✅ candidate
• A natural “can I achieve X?” predicate exists → ✅ candidate
• That predicate is monotonic in X → ✅ confirmed, binary search the answer
Constraints: Constraints:
• bloomDay.length == n
• 1 <= n <= 105
• 1 <= bloomDay[i] <= 109
• 1 <= m <= 106
• 1 <= k <= n
Intuition: Approach: Binary Search
Intuition
In this problem, we need to return the number of days required to make a certain number of bouquets, or return -1 if it's not possible to make that many. The flowers for a bouquet must be consecutive in the garden and fully bloomed.
The naive approach would be to iterate through each day, starting from day 1, and check if we can make m bouquets on that day. This method is inefficient since it requires iterating over all possible days and all N flowers for each day.
To optimize the solution, we observe a crucial property: once a flower blooms, it remains bloomed. This means that the number of bloomed flowers stays the same or increases as the days progress. The same goes for the number of bouquets that can possibly be made.
This observation leads us to consider using a binary search algorithm. One clue that binary search can be applied is that we are searching for a specific value that satisfies a condition (the earliest day). Another clue is that the condition exhibits an "ordered property" – if the condition is satisfied on a particular day, it will also be satisfied on all of the following days.
The observation that the number of bloomed flowers stays the same or increases as the days progress allows us to define a search space between 1 and the maximum value in the bloomDay array. For each midpoint day in the search space, we calculate the number of bouquets that can be made on that day by counting the consecutive bloomed flowers.
If the number of bouquets we can make on the midpoint day is greater than or equal to the number required by the problem (m), then we can potentially find an earlier day that satisfies the requirement. Since we want to return the minimum number of days we need to wait, we update the search space to the left half to see if we can reduce our wait time. Conversely, if the number of bouquets is less than m, we update the search space to the right half to continue our search for a day that we can make the required number of bouquets.
By repeatedly narrowing down the search space through binary search, we can determine whether or not we can make the required number of bouquets.
Algorithm: Brute force
Optimisation : Binary search
Code: class Solution {
public int minDays(int[] bloomDay, int m, int k) {
int start = 0;
int end = 0;
for(int day: bloomDay){
end = Math.max(end, day);
}
int minDays = -1;

while(start <= end) {
int mid = (start + end)/2;
if(getNumberOfBouquets(bloomDay, mid, k) >= m){
minDays = mid;
end = mid - 1;
} else {
start = mid + 1;
}
}
return minDays;
}

public int getNumberOfBouquets(int[] bloomDay, int mid, int k) {
int count = 0;
int numOfBouquets = 0;

for(int i =0;i<bloomDay.length;i++){
if(bloomDay[i] <= mid){
count++;
} else {
count = 0;
}

if(count == k){
numOfBouquets++;
count = 0;
}
}
return numOfBouquets;

}


}
Dry run: Here’s a trace using bloomDay = [1,10,3,10,2], m = 3, k = 1 (need 3 bouquets, each made of 1 adjacent flower).
Setup: start = 0, end = 10 (max bloom day), minDays = -1
Iteration 1: mid = 5
• Walk the array checking which flowers bloom by day 5, counting runs of k=1 adjacent bloomed flowers:
    ◦ i=0: 1≤5 → count=1 → equals k → bouquet #1, reset count
    ◦ i=1: 10>5 → reset count=0
    ◦ i=2: 3≤5 → count=1 → bouquet #2, reset
    ◦ i=3: 10>5 → reset
    ◦ i=4: 2≤5 → count=1 → bouquet #3, reset
• Total bouquets = 3 ≥ m(3) → feasible. Set minDays = 5, shrink end = 4 (try for fewer days)
Iteration 2: start=0, end=4 → mid = 2
• i=0: 1≤2 → bouquet #1
• i=1: 10>2 → reset
• i=2: 3>2 → reset (3 doesn’t bloom by day 2)
• i=3: 10>2 → reset
• i=4: 2≤2 → bouquet #2
• Total = 2 < m(3) → not feasible. Move start = 3
Iteration 3: start=3, end=4 → mid = 3
• i=0: 1≤3 → bouquet #1
• i=1: 10>3 → reset
• i=2: 3≤3 → bouquet #2
• i=3: 10>3 → reset
• i=4: 2≤3 → bouquet #3
• Total = 3 ≥ 3 → feasible. Set minDays = 3, shrink end = 2
Loop ends: start=3 > end=2
Result: minDays = 3 ✓ (correct — by day 3, flowers at indices 0,2,4 have bloomed, giving exactly 3 single-flower bouquets)
Key behavior to note: the count == k check resets count to 0 immediately after forming a bouquet rather than letting it keep accumulating, so each flower is used in at most one bouquet — consecutive bloomed flowers get grouped into non-overlapping chunks of size k. The binary search converges to the minimum mid where this is still ≥ m.
Complexity: Complexity Analysis
Here, N is the number of flowers and D is the highest value in the array bloomDay.
• Time complexity: O(NlogD).
The search space is from 1 to D and for each of the chosen values of mid in the binary search we will iterate over the N flowers. Therefore the time complexity is equal to O(NlogD).
• Space complexity: O(1)
No extra space is required apart from a few variables and hence the space complexity is constant.
follow up questions: Here are likely follow-ups for this problem (binary search on answer):
Complexity & correctness
• What’s the time/space complexity? (O(n log(max(bloomDay))), O(1) space)
• Why does binary search work here — what makes getNumberOfBouquets monotonic in mid?
• What if m * k > bloomDay.length? (Should return -1 immediately — does this code handle it?)
Edge cases to test
• All flowers bloom on the same day
• k = 1 (every bloomed flower is its own bouquet)
• m * k == bloomDay.length exactly (every flower must be used)
• Single flower array
Code-level
• Why end = mid - 1 / start = mid + 1 instead of end = mid / start = mid? (Avoids infinite loop, since mid is already recorded.)
• Could you replace start <= end with start < end and drop minDays? (Yes — classic “find boundary” pattern, but you’d return start instead.)
• Is count = 0 reset after count == k correct, or could it miss overlapping windows? (Reset is correct — bouquets need disjoint adjacent flowers, not overlapping.)
Variants
• How would you solve it if bouquets could use non-adjacent flowers?
• How would the answer change if you wanted the maximum number of bouquets by a fixed day instead of minimum days for a fixed bouquet count?
Want me to walk through any of these, or add a second test case (like one that returns -1) to the visualizer?
Visualisation: https://claude.ai/share/24dffd35-73d3-43c1-a974-91dde51a0406
Claude link: https://claude.ai/share/24dffd35-73d3-43c1-a974-91dde51a0406

© 2026 Vidya Srinivasa Kesarla. All rights reserved.