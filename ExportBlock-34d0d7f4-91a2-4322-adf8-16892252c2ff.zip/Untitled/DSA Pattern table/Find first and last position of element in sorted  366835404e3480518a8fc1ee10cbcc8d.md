# Find first and last position of element in sorted array

Difficulty: Medium
Input Data Structure: Array

© 2026 Vidya Srinivasa Kesarla. All rights reserved.