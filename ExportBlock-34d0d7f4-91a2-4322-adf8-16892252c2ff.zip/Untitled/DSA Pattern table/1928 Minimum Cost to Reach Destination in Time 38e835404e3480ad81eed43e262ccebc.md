# 1928. Minimum Cost to Reach Destination in Time

Difficulty: Difficult
Input Data Structure: 2D Array
Constraints: Constraints:
• 1 <= maxTime <= 1000
• n == passingFees.length
• 2 <= n <= 1000
• n - 1 <= edges.length <= 1000
• 0 <= xi, yi <= n - 1
• 1 <= timei <= 1000
• 1 <= passingFees[j] <= 1000 
• The graph may contain multiple edges between two nodes.
• The graph does not contain self loops.
Optimisation : Bellmanford
Code: //belmmanford

class Solution {
public int minCost(int maxTime, int[][] edges, int[] passingFees) {
int n = passingFees.length;
int INF = Integer.MAX_VALUE / 2;

// dp[t][city] = min cost to reach city in exactly t minutes
int[][] dp = new int[maxTime + 1][n];
for (int[] row : dp) Arrays.fill(row, INF);
dp[0][0] = passingFees[0];

for (int t = 1; t <= maxTime; t++) {
for (int[] edge : edges) {
int u = edge[0], v = edge[1], time = edge[2];
// Traverse edge u -> v
if (time <= t && dp[t - time][u] != INF)
dp[t][v] = Math.min(dp[t][v], dp[t - time][u] + passingFees[v]);
// Traverse edge v -> u (bidirectional)
if (time <= t && dp[t - time][v] != INF)
dp[t][u] = Math.min(dp[t][u], dp[t - time][v] + passingFees[u]);
}
}

int ans = INF;
for (int t = 1; t <= maxTime; t++)
ans = Math.min(ans, dp[t][n - 1]);

return ans == INF ? -1 : ans;
}
}

© 2026 Vidya Srinivasa Kesarla. All rights reserved.