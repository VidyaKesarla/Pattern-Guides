# 11. Container with most water

Difficulty: Medium
Input Data Structure: Array
Pattern trigger(recognition) / constraints hint / : | "container", "trapping rain water", "max area" | Converging pointers, greedy shrink |
Signal / Paraphrase hint: | "container", "trapping rain water", "max area" | Converging pointers, greedy shrink |
Constraints: Constraints:
• n == height.length
• 2 <= n <= 105
• 0 <= height[i] <= 104
Brute force code and its trade off: // 1. Brute Force (Why it fails)We would check every possible pair of lines.Time Complexity: $O(n^2)$.Problem: For $n = 10^5$, this results in $10^{10}$ operations, leading to Time Limit Exceeded (TLE).
// If you keep the shorter pointer and move the taller one, the height of your container can never increase (it's limited by that original short pointer), but your width will definitely decrease. Thus, the area would only ever get smaller.
// The only way to find a bigger area is to abandon the shorter wall and hope to find a taller one.
Intuition: The goal is to find two lines that form a container with the most water. Since **Area = (Width) * (Minimum Height)**, and width decreases as we move pointers inward, we must prioritize keeping the taller lines.# Approach1. **Initialize**: `left` at 0, `right` at the last index.2. **Calculate**: Determine the current area using the shorter of the two heights.3. **Move**: Move the pointer that points to the **shorter** line.4. **Result**: Return the maximum area recorded.
Algorithm: Brute force
Optimisation : Two Pointers
Rationale: | A. Opposite/Converging | left++ or right-- based on comparison | "sorted", "pair sum", "palindrome", "container" | O(n) |
Code: public class Solution {
public int maxArea(int[] height) {
int maxarea = 0;
int left = 0;
int right = height.length - 1;
while (left < right) {
int width = right - left;
maxarea = Math.max(
maxarea,
Math.min(height[left], height[right]) * width
);
if (height[left] <= height[right]) {
left++;
} else {
right--;
}
}
return maxarea;
}
}
Complexity: Complexity Analysis
• Time complexity: O(n). Single pass.
• Space complexity: O(1). Constant space is used.
follow up questions: Here's a good progression to test whether the intuition really landed:
Conceptual (test understanding)
1. Why is it safe to discard the shorter bar's position and never revisit it? (Prove no better answer is lost.)
2. What breaks if you move the taller pointer instead? Trace a counterexample.
3. Why doesn't this problem need the array to be sorted, unlike the two-sum-on-sorted-array pattern?
4. What's the worst case for number of comparisons, and why is it exactly n−1, not n²?
5. If two bars are equal height at the current left/right, does it matter which one you move? Why or why not?
Variants to try next (same pattern family)
6. Trapping Rain Water — same bars, but now compute total trapped water across the whole skyline, not just the best single container. What extra state do you need to track that this problem didn't require?
7. Largest Rectangle in Histogram — looks similar (bars, area) but needs a monotonic stack, not two pointers. Why doesn't two pointers work here?
8. What if you could remove exactly one bar before choosing left/right — does greedy two pointers still work, or do you need a different approach?
9. What if heights can be negative (representing depth below ground)? Does the "move the shorter side" logic still hold?
Interview-style probing
10. Can you get O(1) space and return the actual pair of indices, not just the max area?
11. How would you modify this to return all pairs that achieve the maximum area (not just one)?
12. If asked to solve this with a brute-force first, then optimize — what's the exact sentence you'd say to justify jumping to two pointers?
Want me to walk through the Trapping Rain Water variant next (question 6) — it's the natural next problem and a common follow-up in interviews?
Visualisation: https://claude.ai/share/8dfef5df-ae4c-4c0c-911a-1aa36f323a9f
Reusable template: public boolean twoSumSorted(int[] arr, int target) {
int left = 0, right = arr.length - 1;
while (left < right) {
int sum = arr[left] + arr[right];
if (sum == target) {
return true; // or record indices/pair
} else if (sum < target) {
left++;   // need a bigger sum
} else {
right--;  // need a smaller sum
}
}
return false;
}

© 2026 Vidya Srinivasa Kesarla. All rights reserved.