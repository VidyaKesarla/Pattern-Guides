# 974. Subarray Sums Divisible by K

Difficulty: Medium
Constraints: 
• 1 <= nums.length <= 3 * 104
• -104 <= nums[i] <= 104
• 2 <= k <= 104
Why this is better? Optimisation details: https://leetcode.com/problems/subarray-sums-divisible-by-k/editorial
Rationale: 
1. Initialize an integer prefixMod = 0 to store the remainder when the sum of the elements of a array till the current index when divided by k, and the answer variable result = 0 to store the number of subarrays divisible by k.
2. Initialize an array, modGroups[k] where modGroup[R] stores the number of subarrays encountered with the sum of elements having a remainder R when divided by k. Set modGroups[0] = 1.
3. Iterate over all the elements of num.
    ◦ For each index i, compute the prefix modulo as prefixMod = (prefixMod + num[i] % k + k) % k. We take modulo twice in (prefixMod + num[i] % k + k) % k to remove negative numbers since num[i] can be a negative number and the sum prefixMod + nums[i] % k can turn out to be negative. To remove the negative number we add k to make it positive and then takes its modulo again with k.
    ◦ Add the number of subarrays encountered till now that have the same remainder to the result: result = result + modGroups[prefixMod].
    ◦ In the end, we include the remainder of the subarray in the modGroups, i.e., modGroups[prefixMod] = modGroups[prefixMod] + 1 for future matches.
4. Return result.
Complexity: ApproachCurrent:Hash Table/Prefix SumSuggested:Hash Table/Prefix Sum
Visualisation: https://leetcode.com/problems/subarray-sums-divisible-by-k/editorial

© 2026 Vidya Srinivasa Kesarla. All rights reserved.