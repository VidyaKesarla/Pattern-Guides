# 129. Sum Root to Leaf Numbers

Difficulty: Medium
Input Data Structure: Array
Algorithm: iterative preorder traversal
Optimisation : morris preorder traversal
Rationale: We discussed already iterative and recursive preorder traversals, which both have great time complexity though use up to O(H) to keep the stack. We could trade in performance to save space.
The idea of Morris preorder traversal is simple: to use no space but to traverse the tree.How that could be even possible? At each node one has to decide where to go: to the left or to the right, traverse the left subtree, or traverse the right subtree. How one could know that the left subtree is already done if no additional memory is allowed?
The idea of https://leetcode.com/link/?target=https%3A%2F%2Fwww.sciencedirect.com%2Fscience%2Farticle%2Fpii%2F0020019079900681 algorithm is to set the temporary link between the node and its
https://leetcode.com/articles/delete-node-in-a-bst/: predecessor.right = root. So one starts from the node, computes its predecessor, and verifies if the link is present.
• There is no link? Set it and go to the left subtree.
• There is a link? Break it and go to the right subtree.
There is one small issue to deal with what if there is no left child, i.e. there is no left subtree? Then go straight to the right subtree.

© 2026 Vidya Srinivasa Kesarla. All rights reserved.