# 1011. Capacity To Ship Packages Within D Days (1)

Difficulty: Medium
Input Data Structure: Array
Optimisation : Binary search
Why this is better? Optimisation details: /*
### 🧠 Intuition: Dynamic Programming vs. Binary Search on Answer

This problem features the classic "Minimize the Maximum Capacity" pattern, perfectly matching
the core logic of "Split Array Largest Sum". We are trying to find the minimum possible ship
capacity that allows us to ship all packages within a given number of days.

---

### 📊 Algorithmic Trade-offs & Approaches

1. Brute Force (Backtracking / Recursion)
- Intuition: Try every possible combination of grouping consecutive packages into 'days' groups
and find the configuration that minimizes the maximum weight allocated to any single day.
- Trade-off: Excessively slow due to overlapping subproblems. It explores an exponential
combination tree, resulting in an O((N-1)C(Days-1)) time complexity, causing immediate TLE.

2. Dynamic Programming (DP)
- Intuition: Break the problem down sequentially. Let DP[i][j] represent the minimum ship
capacity needed to ship the first 'i' packages within 'j' days. To solve DP[i][j], we check
all possible partition splits for the last day's load and take the minimum of the maximums.
- Trade-off: Deterministic but handles constraints linearly over multi-variable subproblems.
It demands extra memory to preserve states (O(N * Days) space) and takes O(N^2 * Days) time.

3. Binary Search (The Optimized Approach)
- Intuition: Instead of attempting to locate where to break the shipments day by day, we guess
the target maximum boat capacity (C).

The absolute absolute minimum capacity cannot be lower than the heaviest package (maxLoad),
otherwise, that single package could never be loaded. The absolute maximum capacity needed is
the sum of all package weights combined (totalLoad), which would let us ship everything in 1 day.

Since this search space is strictly sorted [maxLoad ... totalLoad], and the feasibility behaves
monotonically (if a capacity of C is enough to finish within the deadline, any capacity C+1 will
also safely work), we can binary search for the answer! For every mid capacity, we use a greedy
scan to see if we can ship everything in <= days.

---

### ⚙️ Complexity Comparison

| Approach          | Time Complexity                    | Space Complexity | Pros / Cons                                  |
| :---------------- | :--------------------------------- | :--------------- | :------------------------------------------- |
| Brute Force       | O((N-1)C(Days-1))                  | O(N)             | TLE for standard interview constraints.      |
| DP                | O(N^2 * Days)                      | O(N * Days)      | Safe, but structurally slow and memory-heavy.|
| Binary Search     | O(N * log(totalLoad - maxLoad))    | O(1)             | Blazing fast, ultra memory-efficient.        |

---

### 🏃‍♂️ Step-by-Step Dry Run of Binary Search

Let's trace the binary search logic using weights = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10] and days = 5.

1. Initialization
- totalLoad = 1 + 2 + ... + 10 = 55
- maxLoad = max(1, 2, ..., 10) = 10
- Initial search range: l = 10, r = 55

2. Search Loops

* Iteration 1
- mid = 10 + (55 - 10)/2 = 32
- Check feasible(weights, 32, 5):
- Day 1: [1,2,3,4,5,6,7] -> sum = 28 (8 exceeds 32)
- Day 2: [8,9,10] -> sum = 27
- Total daysNeeded = 2.
- Result: Since 2 <= 5, capacity 32 is feasible. Narrow down search to left half: r = 32.

* Iteration 2
- mid = 10 + (32 - 10)/2 = 21
- Check feasible(weights, 21, 5):
- Day 1: [1,2,3,4,5,6] -> sum = 21
- Day 2: [7,8] -> sum = 15
- Day 3: [9,10] -> sum = 19
- Total daysNeeded = 3.
- Result: Since 3 <= 5, capacity 21 is feasible. Narrow down search to left half: r = 21.

* Iteration 3
- mid = 10 + (21 - 10)/2 = 15
- Check feasible(weights, 15, 5):
- Day 1: [1,2,3,4,5] -> sum = 15
- Day 2: [6,7] -> sum = 13
- Day 3: [8,9] -> sum = 17 (Exceeds 15! Split!) -> Day 3: [8], Day 4: [9], Day 5: [10]
- Total daysNeeded = 5.
- Result: Since 5 <= 5, capacity 15 is feasible. Narrow down search to left half: r = 15.

* Iteration 4
- mid = 10 + (15 - 10)/2 = 12
- Check feasible(weights, 12, 5):
- Day 1: [1,2,3,4] -> sum = 10
- Day 2: [5,6] -> sum = 11
- Day 3: [7,8] -> sum = 15 > 12 -> Split! Day 3: [7], Day 4: [8], Day 5: [9], Day 6: [10]
- Total daysNeeded = 6.
- Result: Since 6 > 5, capacity 12 is too small. Shift search to right half: l = 13.

... (Binary search continues narrowing down the bounds between 13 and 15) ...

3. Termination
The loop terminates when l == r, converging precisely at the optimal minimum capacity: 15.
*/
Rationale: 
1. Initialize two integer variables, totalLoad and maxLoad. totalLoad stores the sum of all the elements of weights and maxLoad stores the largest element of weights.
2. Create a method feasible which takes weights, c, days as the parameters and returns true if we can ship all the packages with c capacity.
3. Perform a binary search over the range maxLoad to totalLoad.
    ◦ Create two variables, l and r, to represent the beginning and end of the range. Set l = maxLoad and r = totalLoad. We can always ship all the weights within days days with r capacity.
4. Then, while l < r:
    ◦ Find the midpoint of the range (l, r) in the variable mid = (l + r) / 2.
    ◦ Call feasible(weights, mid, days) to see if we can ship all the weights in daysdays while using mid as the ship's capacity.
    ◦ If we can ship the packages with mid as the ship's capacity in less than or equal to days days, we move to the lower half of the range by setting r = mid.
    ◦ Otherwise, if we cannot ship the packages with m capacity in the required days, we move to the upper half of the range by setting l = mid + 1.
Dry run: Let's trace the binary search logic using weights = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10] and days = 5.

1. Initialization
- totalLoad = 1 + 2 + ... + 10 = 55
- maxLoad = max(1, 2, ..., 10) = 10
- Initial search range: l = 10, r = 55

2. Search Loops

* Iteration 1
- mid = 10 + (55 - 10)/2 = 32
- Check feasible(weights, 32, 5):
- Day 1: [1,2,3,4,5,6,7] -> sum = 28 (8 exceeds 32)
- Day 2: [8,9,10] -> sum = 27
- Total daysNeeded = 2.
- Result: Since 2 <= 5, capacity 32 is feasible. Narrow down search to left half: r = 32.

* Iteration 2
- mid = 10 + (32 - 10)/2 = 21
- Check feasible(weights, 21, 5):
- Day 1: [1,2,3,4,5,6] -> sum = 21
- Day 2: [7,8] -> sum = 15
- Day 3: [9,10] -> sum = 19
- Total daysNeeded = 3.
- Result: Since 3 <= 5, capacity 21 is feasible. Narrow down search to left half: r = 21.

* Iteration 3
- mid = 10 + (21 - 10)/2 = 15
- Check feasible(weights, 15, 5):
- Day 1: [1,2,3,4,5] -> sum = 15
- Day 2: [6,7] -> sum = 13
- Day 3: [8,9] -> sum = 17 (Exceeds 15! Split!) -> Day 3: [8], Day 4: [9], Day 5: [10]
- Total daysNeeded = 5.
- Result: Since 5 <= 5, capacity 15 is feasible. Narrow down search to left half: r = 15.

* Iteration 4
- mid = 10 + (15 - 10)/2 = 12
- Check feasible(weights, 12, 5):
- Day 1: [1,2,3,4] -> sum = 10
- Day 2: [5,6] -> sum = 11
- Day 3: [7,8] -> sum = 15 > 12 -> Split! Day 3: [7], Day 4: [8], Day 5: [9], Day 6: [10]
- Total daysNeeded = 6.
- Result: Since 6 > 5, capacity 12 is too small. Shift search to right half: l = 13.

... (Binary search continues narrowing down the bounds between 13 and 15) ...

3. Termination
The loop terminates when l == r, converging precisely at the optimal minimum capacity: 15.

© 2026 Vidya Srinivasa Kesarla. All rights reserved.