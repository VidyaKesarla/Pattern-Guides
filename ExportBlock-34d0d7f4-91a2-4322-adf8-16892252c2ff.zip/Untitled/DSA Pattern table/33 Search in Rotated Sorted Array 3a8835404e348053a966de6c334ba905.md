# 33. Search in Rotated Sorted Array

Intuition: https://leetcode.com/problems/search-in-rotated-sorted-array/editorial/?envType=company&envId=apple&favoriteSlug=apple-all#approach-3-one-binary-search
Optimisation : One binary search
Code: class Solution {
public int search(int[] nums, int target) {
int n = nums.length;
int left = 0;
int right = n - 1;

while(left<=right){
int mid = left + (right - left)/2;
if(nums[mid] == target){
return mid;
} else if (nums[mid]>=nums[left]){
if(target < nums[mid] && target >= nums[left]){
right = mid -1;
} else {
left = mid + 1;
}
} else {
if(target<=nums[right] && target > nums[mid]){
left = mid + 1;
} else {
right = mid -1;
}

}
}
return -1;
}
}
//tc: O(logn)
//sc: O(1)

// https://claude.ai/share/c702dc2d-cbdc-4b41-abd0-fd35265e1f11

**Code**

**Testcase**

Testcase

**Test Result**

# [**33. Search in Rotated Sorted Array**](https://leetcode.com/problems/search-in-rotated-sorted-array/)

**Code**

**Testcase**

Testcase

**Test Result**

# [**33. Search in Rotated Sorted Array**](https://leetcode.com/problems/search-in-rotated-sorted-array/)

**Code**

**Testcase**

Testcase

**Test Result**

# [**33. Search in Rotated Sorted Array**](https://leetcode.com/problems/search-in-rotated-sorted-array/)

© 2026 Vidya Srinivasa Kesarla. All rights reserved.