# 120. Triangle

Difficulty: Medium
Input Data Structure: 2D Array
Pattern trigger(recognition) / constraints hint / : “minimum path sum from top to bottom.”
Signal / Paraphrase hint: minimum path sum from top to bottom.

2D DP ⇒ becuase movement / paths on a grid
Constraints: Constraints:
• 1 <= triangle.length <= 200
• triangle[0].length == 1
• triangle[i].length == triangle[i - 1].length + 1
• -104 <= triangle[i][j] <= 104
Intuition: https://leetcode.com/problems/triangle/editorial/#approach-1-dynamic-programming-bottom-up-in-place
Optimisation : Bottom up DP - Tabulation
Rationale: https://leetcode.com/problems/triangle/editorial/#approach-1-dynamic-programming-bottom-up-in-place
Code: class Solution {
public int minimumTotal(List<List<Integer>> triangle) {
for(int row = 1;row<triangle.size();row++){
for(int col = 0;col<=row;col++){
int smallest = Integer.MAX_VALUE;
if(col > 0){
smallest = triangle.get(row - 1).get(col - 1);
}
if(col < row){
smallest = Math.min(smallest, triangle.get(row - 1).get(col));
}
int path = smallest + triangle.get(row).get(col);
triangle.get(row).set(col, path);
}
}
return Collections.min(triangle.get(triangle.size() - 1));
}
}

Complexity: Complexity Analysis
Let n be the number of rows in the triangle.
• Time Complexity: O(n2).
A triangle with n rows and n columns contains 2n(n+1)=2n2+n cells. Recall that in big O notaton, we ignore the less significant terms. This gives us O(2n2+n)=O(n2) cells. For each cell, we are performing a constant number of operatons, therefore giving us a total time complexity of O(n2).
• Space Complexity: O(1).
As we're overwriting the input, we don't need any collections to store our calculations.
Reusable template: public int solve(String a, String b) {
int n = a.length(), m = b.length();
int[][] dp = new int[n + 1][m + 1];
for (int i = 1; i <= n; i++) {
for (int j = 1; j <= m; j++) {
if (a.charAt(i - 1) == b.charAt(j - 1)) {
dp[i][j] = dp[i - 1][j - 1] + 1;
} else {
dp[i][j] = Math.max(dp[i - 1][j], dp[i][j - 1]);
}
}
}
return dp[n][m];
}

© 2026 Vidya Srinivasa Kesarla. All rights reserved.