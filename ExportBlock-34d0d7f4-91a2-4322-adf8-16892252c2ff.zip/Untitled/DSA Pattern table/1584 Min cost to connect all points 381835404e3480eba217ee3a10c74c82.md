# 1584. Min cost to connect all points

Difficulty: Medium
Input Data Structure: 2D Array
Pattern trigger(recognition) / constraints hint / : * PATTERN : Prim's MST (Greedy) — dense graph, no PQ needed
* 
Signal / Paraphrase hint: SIGNAL  : "min cost to connect ALL points" → spanning tree + Manhattan dist
Constraints: Constraints:
• 1 <= points.length <= 1000
• -106 <= xi, yi <= 106
• All pairs (xi, yi) are distinct.
Brute force code and its trade off: https://claude.ai/share/d49284ba-dd2d-4e6b-8d01-3e8312a4c48e

class Solution {
public int minCostConnectPoints(int[][] points) {

// ── GUARD CLAUSE ──────────────────────────────
// If no points exist, no edges needed
if (points == null || points.length == 0) return 0;

int size = points.length;

// ── MIN-HEAP ──────────────────────────────────
// PriorityQueue sorted by edge cost (cheapest first)
// (x,y) -> x.cost - y.cost ensures min-heap ordering:
//   negative → x comes first (x is cheaper)
//   positive → y comes first (y is cheaper)
PriorityQueue<Edge> pq = new PriorityQueue<>((x, y) -> x.cost - y.cost);

// ── UNION-FIND ────────────────────────────────
// Tracks which points are already connected
// Prevents cycles when adding edges
UnionFind uf = new UnionFind(size);

// ── GENERATE ALL EDGES ────────────────────────
// j starts at i+1 to avoid duplicate edges
// Edge(0,1) and Edge(1,0) are the same — skip duplicates
for (int i = 0; i < size; i++) {
int[] coordinate1 = points[i];
for (int j = i + 1; j < size; j++) {
int[] coordinate2 = points[j];

// Manhattan distance between two points
// |x1-x2| + |y1-y2|
int cost = Math.abs(coordinate1[0] - coordinate2[0]) +
Math.abs(coordinate1[1] - coordinate2[1]);

// Add edge to min-heap
pq.add(new Edge(i, j, cost));
}
}

int result = 0;
int count = size - 1; // MST always needs exactly n-1 edges

// ── KRUSKAL'S MAIN LOOP ───────────────────────
// Stop when we've added n-1 edges OR no edges left
while (!pq.isEmpty() && count > 0) {

// Always get the cheapest remaining edge
Edge edge = pq.poll();

// Check if adding this edge would form a cycle
// If both points share same root → already connected → skip
if (!uf.connected(edge.point1, edge.point2)) {

// Safe to add — merge the two components
uf.union(edge.point1, edge.point2);

// Accumulate total MST cost
result += edge.cost;

// One fewer edge needed
count--;
}
// If connected → silently skip (would create cycle)
}

return result; // Minimum cost to connect all points
}

// ── EDGE CLASS ────────────────────────────────────
// Represents a weighted connection between two point indices
class Edge {
int point1; // Index of first point
int point2; // Index of second point
int cost;   // Manhattan distance between them

Edge(int point1, int point2, int cost) {
this.point1 = point1;
this.point2 = point2;
this.cost = cost;
}
}

// ── UNION-FIND CLASS ──────────────────────────────
class UnionFind {
int[] root; // root[i] = parent of node i
int[] rank; // rank[i] = height of tree rooted at i

public UnionFind(int size) {
root = new int[size];
rank = new int[size];
for (int i = 0; i < size; i++) {
root[i] = i; // each node is its own root
rank[i] = 1; // each tree starts at height 1
}
}

// Find root of x with PATH COMPRESSION
// Flattens tree so future finds are faster
public int find(int x) {
if (x == root[x]) return x;          // found root
return root[x] = find(root[x]);       // compress path
}

// Merge two groups with UNION BY RANK
// Always attach smaller tree under taller tree
// Keeps tree balanced → faster find()
public void union(int x, int y) {
int rootX = find(x);
int rootY = find(y);
if (rootX != rootY) {
if (rank[rootX] > rank[rootY])
root[rootY] = rootX;      // x's tree is taller
else if (rank[rootX] < rank[rootY])
root[rootX] = rootY;      // y's tree is taller
else {
root[rootY] = rootX;      // equal height
rank[rootX]++;            // tree grew taller
}
}
}

// True if x and y share the same root (same component)
public boolean connected(int x, int y) {
return find(x) == find(y);
}
}
}

Intuition: https://leetcode.com/problems/min-cost-to-connect-all-points/editorial/#approach-2-prims-algorithm
Algorithm: Kruskal
Optimisation : Prim
Code: class Solution {
public int minCostConnectPoints(int[][] points) {
int n = points.length;
int mstCost = 0;
int edgesUsed = 0;

// Track nodes which are visited.
boolean[] inMST = new boolean[n];

int[] minDist = new int[n];
minDist[0] = 0;

for (int i = 1; i < n; ++i) {
minDist[i] = Integer.MAX_VALUE;
}

while (edgesUsed < n) {
int currMinEdge = Integer.MAX_VALUE;
int currNode = -1;

// Pick least weight node which is not in MST.
for (int node = 0; node < n; ++node) {
if (!inMST[node] && currMinEdge > minDist[node]) {
currMinEdge = minDist[node];
currNode = node;
}
}

mstCost += currMinEdge;
edgesUsed++;
inMST[currNode] = true;

// Update adjacent nodes of current node.
for (int nextNode = 0; nextNode < n; ++nextNode) {
int weight = Math.abs(points[currNode][0] - points[nextNode][0]) +
Math.abs(points[currNode][1] - points[nextNode][1]);

if (!inMST[nextNode] && minDist[nextNode] > weight) {
minDist[nextNode] = weight;
}
}
}

return mstCost;
}
}
Dry run: DRY RUN : points = [[0,0],[2,2],[3,10],[5,2],[7,0]]
*           index  :    0      1      2      3      4
*
* Initial : minDist = [0, ∞, ∞, ∞, ∞]   inMST = [F,F,F,F,F]
*
* Iter 0 → pick node 0 (cost 0)  mstCost = 0
*   relax: node1 |0-2|+|0-2|=4  node2 |0-3|+|0-10|=13
*          node3 |0-5|+|0-2|=7  node4 |0-7|+|0-0| =7
*   minDist = [0, 4, 13, 7, 7]   inMST = [T,F,F,F,F]
*
* Iter 1 → pick node 1 (cost 4)  mstCost = 4
*   relax: node2 |2-3|+|2-10|=9 (<13) → 9
*          node3 |2-5|+|2-2| =3 (< 7) → 3
*          node4 |2-7|+|2-0| =7 (= 7) → no change
*   minDist = [0, 4, 9, 3, 7]    inMST = [T,T,F,F,F]
*
* Iter 2 → pick node 3 (cost 3)  mstCost = 7
*   relax: node2 |5-3|+|2-10|=10 (> 9) → no change
*          node4 |5-7|+|2-0| = 4 (< 7) → 4
*   minDist = [0, 4, 9, 3, 4]    inMST = [T,T,F,T,F]
*
* Iter 3 → pick node 4 (cost 4)  mstCost = 11
*   relax: node2 |7-3|+|0-10|=14 (> 9) → no change
*   minDist = [0, 4, 9, 3, 4]    inMST = [T,T,F,T,T]
*
* Iter 4 → pick node 2 (cost 9)  mstCost = 20
*   no unvisited neighbors
*
* RESULT  : 20
  • 
Complexity: Complexity

•	Time: O(n²) — outer loop picks n nodes, inner loop scans all n nodes twice (find min + relax). No priority queue needed since all edges exist (dense graph).
•	Space: O(n) — just inMST[] and minDist[].
•	Why not Kruskal’s here? It needs to sort all n² edges first → O(n² log n), worse for dense graphs.

Key insight vs Dijkstra: Prim’s minDist[next] stores the raw edge weight to the nearest tree node — not cumulative path cost. That’s the only real difference.
Visualisation: https://claude.ai/share/49c9eafd-92d1-4bcc-b208-2cc2abd893ba
Claude link: https://claude.ai/share/49c9eafd-92d1-4bcc-b208-2cc2abd893ba
Similar questions: Here are the classic problems that share the same Prim’s / MST pattern:

Direct MST (same trigger words)

•	1584. Min Cost to Connect All Points ← this one
•	1135. Connecting Cities With Minimum Cost — same idea, explicit edges given instead of coordinates
•	1168. Optimize Water Distribution in a Village — add a virtual node 0 as the “well”, then MST

Kruskal’s variant (sort edges first)

•	1584 can also be solved with Kruskal + Union-Find
•	1489. Find Critical and Pseudo-Critical Edges in MST — forces you to understand both algorithms deeply

Prim’s disguised as something else

•	743. Network Delay Time — looks like MST but it’s Dijkstra; good contrast problem to sharpen the distinction
•	778. Swim in Rising Water — minimax path, solved with modified Dijkstra or binary search + BFS

The trigger to recognise:

|Phrase in problem                      |Likely pattern                    |
|---------------------------------------|----------------------------------|
|“min cost to connect all”          |Prim’s / Kruskal’s                |
|“min cost path from A to B”            |Dijkstra                          |
|“connect components” + Union-Find hints|Kruskal’s                         |
|“minimum bottleneck”               |Modified Dijkstra or binary search|

The single most useful follow-up to do right now is 1135 — it’s the same algorithm but with an adjacency list instead of coordinates, which solidifies that Prim’s is about the structure, not the Manhattan distance formula.

© 2026 Vidya Srinivasa Kesarla. All rights reserved.