# 327. Count of Range Sum
Given an integer array nums and two integers lower and upper, return the number of range sums that lie in [lower, upper] inclusive.
Range sum S(i, j) is defined as the sum of the elements in nums between indices i and j inclusive, where i <= j. (1)

Difficulty: Difficult
Input Data Structure: Array
Constraints: 
• 1 <= nums.length <= 105
• -231 <= nums[i] <= 231 - 1
• -105 <= lower <= upper <= 105
• The answer is guaranteed to fit in a 32-bit integer.
Algorithm: NestedLoop, Prefix sum
Optimisation : Merge sort, Prefix sum
Rationale: https://claude.ai/share/4dea93c4-78d4-4346-a095-5444c2616c51
Code: https://leetcode.com/problems/count-of-range-sum/
Complexity: TC: Onlogn
SC: O(n)

© 2026 Vidya Srinivasa Kesarla. All rights reserved.