# Magnetic Force Between Two Balls (1)

Difficulty: Medium
Input Data Structure: Array
Constraints: 
• n == position.length
• 2 <= n <= 105
• 1 <= position[i] <= 109
• All integers in position are distinct.
• 2 <= m <= position.length
Algorithm: NestedLoop
Optimisation : Binary search
Why this is better? Optimisation details:  * -------------------------------------------------------
* BRUTE FORCE APPROACH:
* Try every combination of m baskets out of n baskets,
* compute the minimum gap for each, return the maximum.
*
*   for every combination of m positions:
*       minGap = minimum distance between consecutive chosen positions
*       answer = max(answer, minGap)
*
* Problem: Combinations = C(n, m) which is exponential.
* For n=50, m=25 -> over a trillion combinations.
* Time: O(C(n,m) * m) — completely impractical.
*
* -------------------------------------------------------
* WHY BINARY SEARCH WORKS — KEY OBSERVATION:
* If we CAN place m balls with minimum gap = d,
* then we can DEFINITELY place them with minimum gap = d-1 too.
* If we CANNOT place with gap = d, we CANNOT with d+1 either.
*
* This gives a clean monotonic yes/no pattern:
*   gap:     1   2   3   4   5   6   7  ...  99
*   answer: [YES YES YES YES  NO  NO  NO ...  NO]
*                          ^
*                    last YES = our answer
*
* Whenever you see this pattern -> Binary search on the answer.
*
* -------------------------------------------------------
* WHY THE GREEDY CHECK WORKS:
* For a given gap x, we ask: "Can we place m balls with every pair at least x apart?"
* Greedy strategy: Always place the next ball at the earliest valid position.
*
* Why is greedy correct?
* Placing earlier never blocks future placements, it only creates more room to the right.
*
* Example: positions = [1, 4, 7, 10], x=3, m=3
*   Greedy:  place at 1 -> 4 -> 7  (3 balls placed) OK
*   Delayed: skip 4, place at 1 -> 7 -> can't reach 3rd ball  FAIL
Rationale: Algorithm
1. Create a helper function called canPlaceBalls which takes in the gap x, positions array position, and the number of balls m as parameters.
    ◦ Initialize, prevBallPos to position[0], ballsPlaced count to 1.
    ◦ Iterate on all positions from index i = 0 till position.size() - 1 or if we placed all m balls:
        ▪ Place the ball at the current position position[i] if it maintains a gap of xwith the previous ball.
        ▪ Update prevBallPos to position[i].
        ▪ Increment ballsPlaced count by 1.
    ◦ Return if ballsPlaced is equal to m.
2. Initialize answer to 0, denoting maximum minimum magnetic force, and n to position array's size.
3. Sort the position array.
4. Initilize the initial search space for the gap:
    ◦ low to 1.
    ◦ high to ceil(position[n - 1] / (m - 1)).
5. Start a while loop until the search space is exhausted, i.e. till low <= high, at each iteration:
    ◦ Calculate the mid = low + (high - low) / 2.
    ◦ If we can place all the balls at a gap of mid, then update answer = mid, and discard the left half search space, left = mid + 1.
    ◦ Otherwise, discard the right half search space, right = mid - 1.
Dry run: DRY RUN: position = [1, 2, 3, 4, 5, 100], m = 3
* After sort: [1, 2, 3, 4, 5, 100]
* low=1, high=ceil(100/2)=50, ans=0
*
* Iter 1: mid=25 -> canPlace: only 100 clears gap of 25 from 1
*         ballsPlaced=2 != 3 -> false -> high=24
*
* Iter 2: mid=12 -> canPlace: same, only 100 clears gap of 12 from 1
*         ballsPlaced=2 != 3 -> false -> high=11
*
* Iter 3: mid=6  -> canPlace: positions 2-5 all within 4 of pos 1
*         ballsPlaced=2 != 3 -> false -> high=5
*
* Iter 4: mid=3  -> canPlace:
*         pos=2,  gap=1  < 3  skip
*         pos=3,  gap=2  < 3  skip
*         pos=4,  gap=3 >= 3  place (count=2, prev=4)
*         pos=5,  gap=1  < 3  skip
*         pos=100 gap=96 >= 3  place (count=3 == m) -> true
*         ans=3, low=4
*
* Iter 5: mid=4  -> canPlace:
*         pos=2,  gap=1  < 4  skip
*         pos=3,  gap=2  < 4  skip
*         pos=4,  gap=3  < 4  skip
*         pos=5,  gap=4 >= 4  place (count=2, prev=5)
*         pos=100 gap=95 >= 4  place (count=3 == m) -> true
*         ans=4, low=5
*
* Iter 6: mid=5  -> canPlace:
*         pos=2,3,4,5 all within 4 of pos 1 -> skip all
*         pos=100 gap=99 >= 5  place (count=2) -> false
*         high=4
*
* low=5 > high=4, loop ends.
* Answer = 4 (balls placed at 1, 5, 100)
Complexity: COMPLEXITY:
*
* Time:
*   Sorting          -> O(n log n)
*   Binary search    -> O(log(max_gap)) iterations, max_gap ~ 10^9 so ~30 iters
*   Each canPlace    -> O(n)
*   Total            -> O(n log n + n log(max_gap)) ~ O(n log n)
*
* Space:
*   O(1) — no extra data structures, sorting is in-place.
*
* -----—

© 2026 Vidya Srinivasa Kesarla. All rights reserved.