# 328. Odd Even Linked List

Difficulty: Medium
Input Data Structure: LinkedList
Rationale: https://leetcode.com/problems/odd-even-linked-list/editorial/

© 2026 Vidya Srinivasa Kesarla. All rights reserved.