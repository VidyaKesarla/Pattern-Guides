# 82. Remove Duplicates from Sorted List II (1)

Difficulty: Medium
Input Data Structure: LinkedList
Constraints: 
• The number of nodes in the list is in the range [0, 300].
• -100 <= Node.val <= 100
• The list is guaranteed to be sorted in ascending order.
Algorithm: Sentinel
Rationale: https://leetcode.com/problems/remove-duplicates-from-sorted-list-ii/editorial/
Code: https://leetcode.com/problems/remove-duplicates-from-sorted-list-ii/
Visualisation: https://leetcode.com/problems/remove-duplicates-from-sorted-list-ii/editorial/

© 2026 Vidya Srinivasa Kesarla. All rights reserved.