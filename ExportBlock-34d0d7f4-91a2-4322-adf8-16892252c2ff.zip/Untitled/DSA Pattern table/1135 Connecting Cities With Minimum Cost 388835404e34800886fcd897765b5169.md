# 1135. Connecting Cities With Minimum Cost

Difficulty: Medium
Input Data Structure: 2D Array, Integer
Constraints: Constraints:
• 1 <= n <= 104
• 1 <= connections.length <= 104
• connections[i].length == 3
• 1 <= xi, yi <= n
• xi != yi
• 0 <= costi <= 105
Intuition: https://leetcode.com/problems/connecting-cities-with-minimum-cost/editorial/#approach-1-minimum-spanning-tree-using-kruskals-algorithm
Optimisation : Disjoint set, Kruskal's algorithm, Union find
Code: class DisjointSet {
private int[] weights;
private int[] parents;

public void Union(int a, int b){
int rootA = Find(a);
int rootB = Find(b);

//if both a and b have same root that is they both belong to the same set, hence we dont have to take union.
if(rootA == rootB)
return;

if(this.weights[rootA] > this.weights[rootB]){
this.parents[rootB] = rootA;
this.weights[rootA] += this.weights[rootB];
} else {
this.parents[rootA] = rootB;
this.weights[rootB] += this.weights[rootA];
}
}

public int Find(int a){
//traverse all way to the top root going through parent nodes
while(a != this.parents[a]){
//path compression => a's grandparent is now a's parent
this.parents[a] = this.parents[parents[a]];
a = this.parents[a];
}
return a;
}

public boolean isInSameGroup(int a, int b){
//return true if both a and b belong to the same set otherwise return false
return Find(a) == Find(b);
}

public DisjointSet(int N){
this.parents = new int[N+1];
this.weights = new int[N+1];
//initialise weight for each node to be 1
for(int i =1;i<=N;i++){
this.parents[i] = i;
this.weights[i] = i;
}
}
}

class Solution {
public int minimumCost(int n, int[][] connections) {
DisjointSet disjointSet = new DisjointSet(n);
//sort connections based on their weights in increasing order
Arrays.sort(connections, (a,b) -> a[2] - b[2]);
//keep track of total edges added in MSt
int total = 0;
//keep track of total cost of adding all those edges
int cost = 0;

for(int i =0;i<connections.length;i++){
int a = connections[i][0];
int b = connections[i][1];

//do not add edge from a to b if it is already connected
if(disjointSet.isInSameGroup(a, b))
continue;
//if a and b are not connected take union
disjointSet.Union(a, b);
//increment cost
cost += connections[i][2];
//increment no of edges added in MST
total++;
}


if(total == n - 1){
return cost;
} else {
return -1;
}
}
}
Dry run: https://claude.ai/share/5494e831-738c-47e2-a034-b0a171040cd0
Complexity: Complexity Analysis
• Time complexity: Assuming N to be the total number of nodes (cities) and M to be the total number of edges (connections). Sorting all the M connections will take O(M⋅logM). Performing union find each time will take log∗N (Iterated logarithm). Hence for M edges, it's O(M⋅log∗N) which is practically O(M) as the value of iterated logarithm, log∗N never exceeds 5.
• Space complexity: O(N), space required by parents and weights
Visualisation: https://claude.ai/share/5494e831-738c-47e2-a034-b0a171040cd0
Claude link: https://claude.ai/share/5494e831-738c-47e2-a034-b0a171040cd0
Reusable template: import java.util.*;

public class KruskalMST {

// ---------- Union-Find (Disjoint Set Union) ----------
static int[] parent, rank_;

static void init(int n) {
parent = new int[n + 1];
rank_ = new int[n + 1];
for (int i = 1; i <= n; i++) parent[i] = i;
}

static int find(int x) {
if (parent[x] != x) parent[x] = find(parent[x]); // path compression
return parent[x];
}

// returns true if union happened (i.e., x and y were in different sets)
static boolean union(int x, int y) {
int rx = find(x), ry = find(y);
if (rx == ry) return false; // already connected -> would form a cycle
if (rank_[rx] < rank_[ry]) { int t = rx; rx = ry; ry = t; }
parent[ry] = rx;
if (rank_[rx] == rank_[ry]) rank_[rx]++;
return true;
}

// ---------- Kruskal's Algorithm ----------
public static int minimumCost(int n, int[][] connections) {
if (connections.length < n - 1) return -1; // not enough edges to connect n nodes

Arrays.sort(connections, (a, b) -> a[2] - b[2]); // sort by cost ascending

init(n);
int totalCost = 0;
int edgesUsed = 0;

for (int[] edge : connections) {
int x = edge[0], y = edge[1], cost = edge[2];
if (union(x, y)) {
totalCost += cost;
edgesUsed++;
if (edgesUsed == n - 1) break; // spanning tree complete, early exit
}
}

return edgesUsed == n - 1 ? totalCost : -1;
}

// ---------- Demo ----------
public static void main(String[] args) {
int n = 3;
int[][] connections = {{1, 2, 5}, {1, 3, 6}, {2, 3, 1}};
System.out.println(minimumCost(n, connections)); // expected: 6
}
}

© 2026 Vidya Srinivasa Kesarla. All rights reserved.