# 901. Online Stock Span (1)

Difficulty: Medium
Input Data Structure: Array
Constraints: onstraints:
• 1 <= price <= 105
• At most 104 calls will be made to next.
Optimisation : monotonic stack
Why this is better? Optimisation details: https://leetcode.com/problems/online-stock-span/editorial/
Rationale: In this approach, we maintain a stack. Initially, we push a -1 onto the stack to mark the end.
We start with the leftmost bar and keep pushing the current bar's index onto the stack until we get two successive numbers in descending order, i.e. until we get heights[i]<heights[i−1]. Now, we start popping the numbers from the stack until we hit a number stack[j] on the stack such that heights[stack[j]]≤heights[i].
Every time we pop, we find out the area of rectangle formed using the current element as the height of the rectangle and the difference between the the current element's index pointed to in the original array and the element stack[top−1]−1 as the width
i.e. if we pop an element stack[top] and i is the current index to which we are pointing in the original array, the current area of the rectangle will be considered as:
(i−stack[top−1]−1)×heights[stack[top]].
Further, if we reach the end of the array, we pop all the elements of the stack and at every pop, this time we use the following equation to find the area:
(heights.length−stack[top−1]−1)×heights[stack[top]], where stack[top] refers to the element just popped. Thus, we can get the area of the of the largest rectangle by comparing the new area found everytime.
The following example will clarify the process further:
[6, 7, 5, 2, 4, 5, 9, 3]
Code: https://leetcode.com/problems/online-stock-span/editorial/
Complexity: Complexity Analysis
Given n as the number of calls to next,
• Time complexity of each call to next: O(1)
Even though there is a while loop in next, that while loop can only run n times total across the entire algorithm. Each element can only be popped off the stack once, and there are up to n elements.
This is called amortized analysis - if you average out the time it takes for next to run across n calls, it works out to be O(1). If one call to next takes a long time because the while loop runs many times, then the other calls to next won't take as long because their while loops can't run as long.
• Space complexity: O(n)
In the worst case scenario for space (when all the stock prices are decreasing), the while loop will never run, which means the stack grows to a size of n.

© 2026 Vidya Srinivasa Kesarla. All rights reserved.